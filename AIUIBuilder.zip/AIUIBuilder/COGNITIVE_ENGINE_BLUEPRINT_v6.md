# COGNITIVE ENGINE — BLUEPRINT v6.0
## From Adaptive Runtime to Self-Improving Reasoning System

**Date:** 2026-06-29
**Status:** Analysis + Implementation Plan (no code changes)
**Based on:** 50 source files, session dumps, ChatGPT's v2 analysis, and 2025-2026 research on concept formation, self-evaluation, internal simulation, causal credit assignment, and executive scheduling.

---

## PART 0: THE CORE DIAGNOSIS

ChatGPT's key insight: **"Nothing you've added guarantees the engine actually becomes smarter. It can learn. But it doesn't yet know whether it improved."**

The engine has feedback loops (reasoning → memory → prediction error → attention → operator selection → reasoning), but no **objective function** saying "Version B solved this better than Version A." Without that, the StrategyArchive eventually fills with noise.

The 5 remaining layers address this:

| Layer | What It Does | Research Grounding |
|-------|-------------|-------------------|
| 1. Concept Formation | Discovers reusable abstractions from specific experiences | Schema learning (Springer 2025), Discovery Engine (arXiv 2025) |
| 2. Self-Evaluation | Objectively scores reasoning quality | LLM-as-judge (Evidently 2025), Process Reward Models (arXiv 2025) |
| 3. Internal Simulation | Simulates hypotheses before committing | SiRA (arXiv 2026), Global Workspace Theory (Shanahan 2005) |
| 4. Causal Credit Assignment | Tracks which operator caused improvement | MACCA (arXiv 2026), PCM (Neural Networks 2023) |
| 5. Dynamic Executive Scheduler | Chooses operators based on current bottleneck | Meta-learning (Nature 2025), RLDE-AFL (arXiv 2025) |

---

## PART 1: WHAT THE CODEBASE ALREADY HAS

### Layer 1: Concept Formation — 🟡 Partial
- `SemanticMemory` stores nodes with types: concept, principle, fact, claim, problem, solution
- `consolidate()` creates "consolidated" nodes from high-activation memories
- `autoCreateEdges()` connects related beliefs via edges
- `patternComplete()` reconstructs full patterns from partial cues
- **MISSING:** No abstraction extraction — never discovers "Distributed local interactions produce global behavior" from specific examples

### Layer 2: Self-Evaluation — 🟡 Partial
- `BeliefAudit` checks for prompt echoes, circular reasoning, empty output
- `MetacognitiveMonitor.detectContradictions()` finds conflicts
- `computeCalibratedConfidence()` multi-signal confidence
- **MISSING:** No objective scoring of correctness, completeness, consistency, novelty, efficiency

### Layer 3: Internal Simulation — 🟡 Partial
- `runPredict()` generates testable predictions from beliefs
- `runRepair()` fixes broken beliefs
- `runHypothesize()` combines solved chunks into hypothesis
- **MISSING:** No simulate→compare→select loop; predictions aren't actually tested against simulated outcomes

### Layer 4: Causal Credit Assignment — 🟡 Partial
- `OperatorOutcome` tracks per-operator results
- `UnifiedStrategyArchive.recordOutcome()` stores success rates
- `sessionOutcomes` records full operator sequence
- **MISSING:** Archive stores "operator X succeeded" but not "operator X caused improvement of Y%"

### Layer 5: Dynamic Executive Scheduler — 🟡 Partial
- Phase state machine: ORIENT → DECOMPOSE → SOLVE → PREDICT → CURIOSITY → HYPOTHESIZE → VERIFY → INTEGRATE
- `MetacognitiveMonitor.decideNext()` can override phases
- `cognitiveEnergy` limits recursion
- **MISSING:** Still predefined phases; doesn't ask "What limits progress now?" each iteration

---

## PART 2: IMPLEMENTATION PLAN

### PHASE K: Concept Formation / Abstraction Engine ⭐⭐⭐⭐⭐

**The biggest missing capability.** After solving multiple problems, the engine should discover reusable abstractions.

**Research grounding:**
- Springer (2025): "Structural knowledge: from brain to AI" — schemas emerge from statistical regularity extraction across experiences; HPC encodes new experiences and extracts commonalities
- Discovery Engine (arXiv 2025): LLM-driven distillation of publications into structured "knowledge artifacts"; template framework with self-consistent refinement loop
- Active Inference (arXiv 2025): Dynamic knowledge graphs where thinking discovers new patterns, reasoning establishes logical connections, experiments validate relationships

**What to build:**

```
1. After 3+ sessions, run ABSTRACT operator:
   Input: last N session outcomes + their reasoning paths
   LLM prompt: "Look at these 3 solved problems. What pattern do they share?
     Problem 1: How neurons work → decomposed into components → each component simulated
     Problem 2: How CPUs work → decomposed into components → each component simulated  
     Problem 3: How ant colonies work → decomposed into components → each component simulated
     What abstraction captures what's common?"
   Output: "Many small units with local interactions produce global behavior"

2. Store abstraction as SemanticNode with type = "abstraction":
   - content = the abstract pattern
   - importance = 0.95 (abstractions are highly valuable)
   - edges to all the specific experiences that generated it

3. In future sessions, check if current problem matches any abstraction:
   - If yes: inject abstraction into working memory
   - "This looks like a 'distributed emergence' problem. 
     Previous approach: decompose into local units, simulate interactions, observe global behavior."

4. Implement concept hierarchy:
   - Specific: "neurons fire together"
   - Intermediate: "local interaction produces global behavior"  
   - Abstract: "distributed emergence"
   Each level can be used for different reasoning purposes
```

**Files to modify:** `CognitiveEngine.kt` (add ABSTRACT operator), `MemorySystems.kt` (add abstraction type)
**Estimated effort:** 3 hours

---

### PHASE L: Objective Self-Evaluation ⭐⭐⭐⭐⭐

**The engine needs to know if it actually improved, not just believe it did.**

**Research grounding:**
- LLM-as-judge (Evidently 2025): Multi-criteria evaluation with rubrics (correctness, completeness, consistency, novelty, efficiency)
- Process Reward Models (arXiv 2025): Step-level evaluation of reasoning traces
- Nature HLE benchmark (2026): Structured evaluation with extracted answers and confidence

**What to build:**

```
1. After INTEGRATE, run SELF_EVALUATE operator:
   Input: query + final answer + reasoning trace + solved chunks
   LLM prompt: "Evaluate this reasoning session on 5 dimensions (0-10 each):
     - CORRECTNESS: Is the final answer factually accurate?
     - COMPLETENESS: Does it address all aspects of the question?
     - CONSISTENCY: Are there contradictions in the reasoning?
     - NOVELTY: Did the reasoning discover non-obvious insights?
     - EFFICIENCY: Was the reasoning path efficient (few unnecessary steps)?"
   Output: JSON with scores for each dimension + overall score

2. Store evaluation as SemanticNode with type = "evaluation":
   - content = scores + reasoning
   - edges to the session's beliefs
   
3. Compare with past evaluations:
   - "This session scored 7.2/10. Previous similar sessions averaged 6.8/10."
   - "Improvement: +0.4 (driven by better completeness)"
   
4. Use evaluation to update StrategyArchive:
   - If evaluation.score > previous average → reinforce the operator sequence
   - If evaluation.score < previous average → penalize the operator sequence
   - This prevents the archive from filling with noise

5. Add evaluation to the observatory:
   "SELF-EVALUATION: Correctness 8/10, Completeness 7/10, Consistency 9/10, 
    Novelty 6/10, Efficiency 7/10. Overall: 7.4/10"
```

**Files to modify:** `CognitiveEngine.kt` (add SELF_EVALUATE operator), `ReasoningOperators.kt` (add evaluation prompt)
**Estimated effort:** 2.5 hours

---

### PHASE M: Internal Simulation Workspace ⭐⭐⭐⭐

**The engine should simulate hypotheses before committing to them.**

**Research grounding:**
- SiRA (arXiv 2026): Simulative reasoning through world model achieves 124% higher completion than reactive policy
- Nature (2025): Computational basis of hierarchical and counterfactual information processing
- Shanahan (2005): Cognitive architecture combining internal simulation with global workspace
- ScienceOpen (2026): World models as internal representations for planning, counterfactual reasoning, and imagination

**What to build:**

```
1. Enhance PREDICT to generate multiple competing hypotheses:
   Current: generate 2-3 predictions
   New: generate 2-3 HYPOTHESES, each with predicted consequences

2. Add SIMULATE operator (between PREDICT and VERIFY):
   For each hypothesis:
   a. Simulate: "If hypothesis A is true, what would we expect to observe?"
   b. Generate simulated observations
   c. Compare hypotheses: "Which hypothesis best explains what we know?"
   d. Select the most promising hypothesis

3. Implement counterfactual reasoning:
   "What if I had used FIRST_PRINCIPLES instead of DECOMPOSE?"
   - Query StrategyArchive for both paths
   - Compare expected outcomes
   - Select the better path

4. Add simulation workspace to observatory:
   "SIMULATION: Hypothesis A (conf 0.7) vs Hypothesis B (conf 0.5)
    Simulated: A predicts X, B predicts Y
    Selected: A (higher predicted consistency)"
```

**Files to modify:** `CognitiveEngine.kt` (enhance PREDICT, add SIMULATE), `ReasoningOperators.kt` (add simulation prompt)
**Estimated effort:** 3 hours

---

### PHASE N: Causal Credit Assignment ⭐⭐⭐

**The engine should know WHICH operator caused improvement, not just that the session succeeded.**

**Research grounding:**
- MACCA (arXiv 2026): Causal credit assignment using Dynamic Bayesian Network
- PCM (Neural Networks 2023): Predictive contribution measurement — prediction error inversely proportional to relevance
- LLM-Guided Credit Assignment (arXiv 2025): LLM generates dense, agent-specific rewards

**What to build:**

```
1. Track CONFIDENCE DELTA per operator:
   Before operator: confidence of relevant beliefs = X
   After operator: confidence of relevant beliefs = Y
   Contribution = Y - X

2. Store contribution in OperatorOutcome:
   data class OperatorOutcome(
       ...
       val confidenceBefore: Float,  // confidence before this operator
       val confidenceAfter: Float,   // confidence after this operator
       val contribution: Float       // delta = after - before
   )

3. At session end, compute per-operator contributions:
   ORIENT: +0.05 (set up the problem)
   DECOMPOSE: +0.00 (no direct confidence change)
   SOLVE_CHUNK: +0.15, +0.12, +0.10, +0.08 (each chunk added knowledge)
   PREDICT: +0.05 (generated testable predictions)
   VERIFY: +0.20 (confirmed hypothesis)
   INTEGRATE: +0.00 (synthesized, no new confidence)

4. Use contributions to update StrategyArchive:
   - High-contribution operators get reinforced
   - Low-contribution operators get penalized
   - This is much better than just "session succeeded/failed"

5. Add to observatory:
   "CREDIT: VERIFY contributed +0.20, SOLVE_CHUNK contributed +0.45 total,
    PREDICT contributed +0.05. Most valuable: SOLVE_CHUNK"
```

**Files to modify:** `CognitiveEngine.kt` (track confidence deltas), `MemorySystems.kt` (OperatorOutcome enhancement)
**Estimated effort:** 2 hours

---

### PHASE O: Dynamic Executive Scheduler ⭐⭐⭐

**The engine should ask "What limits progress now?" each iteration, not follow predefined phases.**

**Research grounding:**
- Nature (2025): Meta-network learns which predictions to make and what loss function to use
- RLDE-AFL (arXiv 2025): RL-based adaptive operator selection
- ScienceDirect (2025): Meta-learning enables "learning how to learn"

**What to build:**

```
1. Replace phase state machine with dynamic bottleneck detection:
   Each iteration, ask:
   - "Is the problem understood?" (if not → ORIENT)
   - "Is the problem too big?" (if yes → DECOMPOSE)
   - "Are there unsolved chunks?" (if yes → SOLVE_CHUNK)
   - "Do we have enough knowledge?" (if no → CURIOSITY)
   - "Can we predict outcomes?" (if yes → PREDICT)
   - "Do we have a testable hypothesis?" (if yes → VERIFY)
   - "Can we integrate?" (if yes → INTEGRATE)

2. Use StrategyArchive to bias selection:
   "For physics problems, FIRST_PRINCIPLES → ANALOGIZE → VERIFY worked best"
   - Weight each operator by its historical contribution for this problem type
   - Select operator with highest weighted score

3. Implement adaptive energy costs:
   Current: fixed costs per operator
   New: costs based on historical effectiveness
   - If VERIFY consistently contributes +0.20 for this problem type → cost = 10 (worth it)
   - If CURIOSITY consistently contributes +0.02 → cost = 15 (not worth it)

4. Add bottleneck logging:
   "BOTTLENECK: Problem not fully understood → ORIENT
    BOTTLENECK: 3 unsolved chunks → SOLVE_CHUNK
    BOTTLENECK: No testable hypothesis → PREDICT"
```

**Files to modify:** `CognitiveEngine.kt` (replace phase state machine), `MetacognitiveMonitor.kt` (add bottleneck detection)
**Estimated effort:** 2.5 hours

---

## PART 3: IMPLEMENTATION ORDER

| Priority | Phase | What | Impact | Hours |
|----------|-------|------|--------|-------|
| **1** | **L: Self-Evaluation** | Objective scoring of reasoning quality | Prevents archive noise | 2.5 |
| **2** | **K: Concept Formation** | Extract reusable abstractions | Closest to human-like learning | 3 |
| **3** | **N: Credit Assignment** | Track which operator caused improvement | Better meta-learning | 2 |
| **4** | **M: Internal Simulation** | Simulate hypotheses before committing | Scientific reasoning | 3 |
| **5** | **O: Dynamic Scheduler** | Bottleneck-driven operator selection | True adaptivity | 2.5 |

**Total: 13 hours**

**Minimum viable (L + K): 5.5 hours** — Self-evaluation prevents archive noise; concept formation enables abstraction reuse.

---

## PART 4: THE COMPLETE COGNITIVE ARCHITECTURE

After all phases (v1-v6), the engine operates as:

```
┌─────────────────────────────────────────────────────────────────┐
│                    SELF-IMPROVING COGNITIVE RUNTIME               │
│                                                                   │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────────┐ │
│  │   Memory      │   │  Attention   │   │   Meta-Learning      │ │
│  │  (Activation  │◄─►│  (FocusField │◄─►│  (Strategy Archive   │ │
│  │   Network +   │   │   Dynamics)  │   │   + Credit Assignment│ │
│  │   Abstractions│   │              │   │   + Self-Evaluation) │ │
│  └───────┬──────┘   └──────┬───────┘   └──────────┬───────────┘ │
│          │                 │                        │             │
│  ┌───────▼─────────────────▼────────────────────────▼──────────┐ │
│  │              DYNAMIC EXECUTIVE SCHEDULER                      │ │
│  │  Asks "What limits progress now?" each iteration              │ │
│  │  Uses StrategyArchive + Credit Assignment to select operators │ │
│  │  5-7 core operators, adaptively scheduled                     │ │
│  └───────┬─────────────────┬────────────────────────┬──────────┘ │
│          │                 │                        │             │
│  ┌───────▼──────┐   ┌─────▼──────┐   ┌───────────▼──────────┐  │
│  │   LLM         │   │ Simulator  │   │   Evaluator          │  │
│  │  (Generator)  │   │  (Predict  │   │  (Self-Evaluation    │  │
│  │               │   │   Compare  │   │   Correctness        │  │
│  │               │   │   Select)  │   │   Completeness       │  │
│  │               │   │            │   │   Consistency)       │  │
│  └───────────────┘   └────────────┘   └──────────────────────┘  │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │              COGNITIVE ENERGY + PREDICTION ERROR              │ │
│  │  Depletes per operation │ Restores on surprise                │ │
│  │  PE drives attention │ PE gates memory updating               │ │
│  └──────────────────────────────────────────────────────────────┘ │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │              CONCEPT FORMATION ENGINE                         │ │
│  │  After N sessions → extract reusable abstractions             │ │
│  │  "Distributed emergence" │ "Feedback loops" │ "Phase transitions"│
│  │  Abstractions become reusable reasoning patterns              │ │
│  └──────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

---

## PART 5: THE CORE INVARIANT (Final)

> "Intelligence isn't the number of cognitive components. It's a closed loop where experience changes future behavior because the system can measure what actually worked."

The engine now has:
- **Feedback loops** (reasoning → memory → PE → attention → operator selection)
- **Self-evaluation** (objective scoring prevents archive noise)
- **Concept formation** (abstractions from specific experiences)
- **Causal credit** (which operator caused improvement)
- **Internal simulation** (hypotheses tested before commitment)
- **Dynamic scheduling** (bottleneck-driven operator selection)

**This is the transition from "sophisticated architecture" to "genuinely self-improving reasoning system."**

---

*Blueprint v6.0 — Analysis + Implementation Plan*
*Total estimated effort: 13 hours for full implementation*
*Minimum viable (L + K): 5.5 hours*
