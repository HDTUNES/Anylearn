# AIUIBuilder — Architectural Blueprint: ACT-R Cognitive Operating System

> Core Invariant: A recursive AI system should not remember conversations. It should remember goals, beliefs, attention activation, confidence, and the dependency structure connecting them.

---

## 1. The Tripartite Separation of Cognition
Standard recursive LLM loops collapse into amnesia or prompt bloat because they store raw chat transcript history. AIUIBuilder’s SOTA refiner separates long-term cognition into three distinct computational primitives:

1. **Knowledge (Belief Graph):** What is believed, why it is believed, causal edges (`supports`, `contradicts`, `depends_on`), and probabilistic confidence.
2. **Attention (Activation System):** What matters right now based on recency, importance, reuse, and PageRank structural centrality.
3. **Objectives (Goal Tree):** Hierarchical task decomposition (`HTN`) tracking active exploration branches and bounded question entropy.

---

## 2. Mathematical Formalism: Activation & PageRank Centrality

### A. Base-Level Activation (ACT-R Curve)
Every node $i$ in the SQLite belief graph carries:
```json
{
  "id": "n014",
  "claim": "Copper heatspreaders viable for cell cooling",
  "importance": 0.85,
  "confidence": 0.92,
  "created_iter": 12,
  "last_touch_iter": 45,
  "touch_count": 8,
  "descendant_count": 14
}
```
Activation decays continuously across iteration cycles (indexed by iteration counter $t$, not wall-clock time):
$$A_i(t) = \text{importance}_i \times \text{decay\_rate}^{(t - \text{last\_touch\_iter}_i)}$$

### B. Structural Immortality (Graph Centrality)
To prevent foundational axioms (e.g. *"Energy must be conserved"*) from decaying when unreferenced for thousands of iterations, total working-set priority is protected by graph topology:
$$\text{RetrievalScore}_i(t) = A_i(t) + \left(\lambda \times \ln(1 + \text{descendant\_count}_i)\right)$$
A foundational node supporting hundreds of downstream dependent claims becomes immortal.

---

## 3. Edge-Triggered Recall vs. Cosine Similarity RAG
* **Why Embedding RAG Fails:** Cosine similarity retrieves by lexical coincidence (`word overlap`), dragging discarded dead ends back into active working memory.
* **Edge-Triggered Recall:** Paged-out archived nodes in on-device SQLite cost zero prompt tokens. They return to active working memory *only* when a newly generated claim explicitly emits a directed graph edge pointing to their ID (`contradicts("n014")`, `depends_on("n014")`).

---

## 4. Mobile Implementation Priority Order (Android Kotlin)

To ship this iteratively on 4GB mobile hardware without recursion collapse:

1. **Objectives Goal Tree:** HTN branch tracking & open-question budgeting (Invariant: must close exactly 1 question, open at most 1 new question per round).
2. **Belief Graph with Edges:** On-device SQLite table storing node claims and directed causal edges.
3. **Activation & Centrality Scoring:** Computing continuous continuous retrieval scores per node.
4. **Top-K Working Set Assembly:** Strictly slicing top ~400 tokens of highest-scoring nodes for prompt prefill (keeping RAM and context flat forever).
5. **Continuous Confidence Tracking:** Updating belief probability derived from verifier validation.
6. **Consolidation / Sleep Pass:** Periodically clustering evicted low-activation nodes into 1 compressed abstract Meta-Node.
7. **Empirical Verifier Gate:** Local graph consistency checks ($O(1)$ cycles) + empirical web checks for novel falsifiable claims.
8. **Optional Embedding Dedup:** Write-time similarity check to catch restatements before insertion.