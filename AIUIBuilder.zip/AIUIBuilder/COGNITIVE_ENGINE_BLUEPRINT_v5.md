# COGNITIVE ENGINE — BLUEPRINT v5.0
## From Architecture to Adaptive Runtime: The Self-Evolving Cognitive System

**Date:** 2026-06-29
**Status:** Analysis + Implementation Plan
**Based on:** Source code (49 files), session dumps, ChatGPT's v2 analysis, and 2025-2026 research on meta-learning, prediction error, and adaptive cognitive architectures.

---

## PART 0: WHAT THE CODEBASE ALREADY HAS (Mapped to ChatGPT's 10 Points)

| # | ChatGPT's Point | Status | What Exists | What's Missing |
|---|----------------|--------|-------------|----------------|
| 1 | Hand-designed architecture | 🟡 Partial | `UnifiedStrategyArchive` with `recordOutcome()`, `selectForGoal()` | Engine doesn't USE the archive to change operator sequencing |
| 2 | Meta-learning missing | 🟡 Partial | `StrategyArm.successRate`, `ProceduralSkill.successCount/failureCount` | No learning of "physics → first principles + analogy" patterns |
| 3 | Prediction error as attention | 🟡 Partial | `surprise` field on every `OperatorResult` | Surprise doesn't drive attention — only energy restoration |
| 4 | World model shallow | 🟡 Partial | `runPredict()`, `runRepair()` operators | No SIMULATE operator; no iterative predict→check→repair loop |
| 5 | Episodic memory | 🟡 Partial | `EpisodicTrace` with goal/operator/output/surprise/success | Doesn't store full reasoning path; can't recall "I solved something similar" |
| 6 | Confidence calibration | ❌ Weak | LLM self-reports confidence | Not computed from multi-signal evidence |
| 7 | FocusField | 🟡 Partial | `activation`, `inhibitUnrelated()`, `getFocusNode()` | Missing `attention`, `inhibition` as separate node fields |
| 8 | Too many operators | 🟡 OK | 6 operators (ORIENT, DECOMPOSE, SOLVE, VERIFY, INTEGRATE, CURIOSITY) | Could consolidate; need adaptive scheduling |
| 9 | Long-term evolution | 🟡 Partial | `UnifiedStrategyArchive.recordOutcome()` | Archive exists but engine doesn't learn from it |
| 10 | Dynamics vs state | 🟡 Partial | Spreading activation, decay, inhibition | Cycle not closed — dynamics don't feed back into decisions |

**Key insight:** The infrastructure for self-evolution already exists (`UnifiedStrategyArchive`, `EpisodicMemory`, `ProceduralMemory`, `surprise` field). What's missing is **wiring them together** so the engine actually learns from experience.

---

## PART 1: THE 5 REMAINING GAPS (Prioritized by Impact)

### GAP 1: Meta-Learning — The Engine Should Learn Which Strategies Work ⭐⭐⭐⭐⭐

**What ChatGPT said:**
> "The architecture itself should eventually learn which operator to call, how many decomposition steps to use, whether analogy helps, when verification is worth the cost."

**What already exists:**
```kotlin
// UnifiedStrategyArchive already tracks success rates per operator
UnifiedStrategyArchive.recordOutcome(operatorArmId, lastResult.confidence > 0.7f)
UnifiedStrategyArchive.selectForGoal(goalWords)  // returns suggested strategies
```

**What's missing:** The engine calls `selectForGoal()` only at session start (for initial operator choice). It never uses the archive to:
- Choose the NEXT operator based on what worked before
- Adjust energy costs based on operator effectiveness
- Skip operators that consistently fail for this problem type

**Research grounding:**
- Nature (2025): "Discovering state-of-the-art RL algorithms" — meta-network learns which predictions to make and what loss function to use
- RLDE-AFL (arXiv:2503.18061): RL-based adaptive operator selection using population features
- ScienceDirect (2025): "Meta-learning enables agents to estimate task difficulty and order learning phases for improved generalization"

**Implementation plan:**
```
1. Add OperatorOutcome data class to track per-session results:
   data class OperatorOutcome(
       operator: String,
       problemType: String,  // extracted from query
       confidence: Float,
       surprise: Float,
       success: Boolean,
       tokensUsed: Int
   )

2. At session end, record outcomes to UnifiedStrategyArchive:
   - Problem type: extract from ORIENT's topic field
   - Operator sequence: what was called
   - Outcome: confidence, surprise, success

3. At operator selection time, query the archive:
   - "For physics problems, which operator sequence had highest success?"
   - Bias the phase state machine toward successful patterns

4. Implement adaptive energy costs:
   - If an operator consistently produces high surprise for this problem type → lower cost
   - If an operator consistently produces low confidence → higher cost
```

**Estimated effort: 3 hours**

---

### GAP 2: Prediction Error as Attention Driver ⭐⭐⭐⭐⭐

**What ChatGPT said:**
> "Brains pay enormous attention to things that violated expectations. That drives learning."

**What already exists:**
```kotlin
// Every OperatorResult has a surprise field
data class OperatorResult(val surprise: Float)
// Energy restoration uses surprise
if (lastResult.surprise > 0.5f) cognitiveEnergy += 10f
// Curiosity triggers on surprise
if (lastResult.surprise > 0.4f) → generate alternatives
```

**What's missing:** Surprise doesn't:
- Increase the activation of the surprising node
- Trigger reconsolidation of related memories
- Update the strategy archive with "this was unexpected"
- Drive the engine to spend MORE time on surprising findings

**Research grounding:**
- Pearce-Hall (1980): Unsigned prediction errors enhance attention and learning rate
- bioRxiv (2025): "Strong mnemonic prediction errors increase cognitive control" — frontal theta, posterior alpha, pupil size
- ScienceDirect (2025): "Prediction errors disrupt hippocampal representations and update memories" — small PE → edit existing memory; large PE → form new memory
- Rouhani & Niv (2019): Unsigned RPEs boost memory regardless of sign

**Implementation plan:**
```
1. When an operator produces high surprise (PE > 0.4):
   a. Activate the node with extra strength: activateNode(id, surprise * 2)
   b. Trigger reconsolidation of related memories
   c. Increase learning rate for this operator (store in StrategyArchive)

2. Implement PE-gated memory updating:
   - Small PE (0.2-0.4): edit existing memory (reconsolidate)
   - Large PE (> 0.4): form new memory (addNode)
   - This matches the hippocampal LC mechanism (ScienceDirect 2025)

3. Add PE to the activation score:
   retrievalScore = base * (1 + surprise) instead of just base
   This makes surprising memories more retrievable

4. Log prediction errors in the observatory:
   "PREDICTION ERROR: 0.67 (high) — node 'Solved: ion channels' activated strongly"
```

**Estimated effort: 2 hours**

---

### GAP 3: Episodic Memory with Reasoning Paths ⭐⭐⭐⭐

**What ChatGPT said:**
> "Store: Problem → Reasoning path → Mistake → Fix → Outcome. Later the engine can recall 'I've solved something similar before.'"

**What already exists:**
```kotlin
data class EpisodicTrace(
    val goal: String,
    val operator: String,
    val output: String,
    val surprise: Float,
    val success: Boolean
)
fun replaySimilar(goal: String, n: Int = 3): List<EpisodicTrace>
```

**What's missing:**
- `replaySimilar()` is never called in the main reasoning loop
- The trace doesn't store the full reasoning path (just one operator's output)
- No "I made this mistake before" detection

**Implementation plan:**
```
1. Enhance EpisodicTrace to store the full session:
   data class EpisodicTrace(
       ...
       val operatorSequence: List<String>,  // full path
       val mistakes: List<String>,           // what went wrong
       val corrections: List<String>,        // how it was fixed
       val finalConfidence: Float
   )

2. At session start, call replaySimilar() and inject into working memory:
   "Last time you solved a similar problem, you used: ORIENT → DECOMPOSE → 
    SOLVE_CHUNK × 3 → VERIFY → INTEGRATE. Confidence: 0.82."

3. Add mistake detection:
   - If an operator produces low confidence (< 0.4) AND the next operator
     is different → record as a "mistake → correction" pair
   - Store in EpisodicTrace for future reference

4. At operator selection, check episodic memory:
   "Have I solved something similar before? What operator sequence worked?"
```

**Estimated effort: 2.5 hours**

---

### GAP 4: Multi-Signal Confidence Calibration ⭐⭐⭐

**What ChatGPT said:**
> "Compute confidence from: agreement between operators, retrieval quality, contradiction count, prediction success, verification outcome."

**What already exists:**
```kotlin
// LLM self-reports confidence
val confidence = when (structured["confidence"]) {
    "high" -> 0.9f; "medium" -> 0.7f; "low" -> 0.5f; else -> 0.7f
}
// Contradiction detection reduces confidence
contradictions.forEach { cId -> SemanticMemory.getNode(cId)?.let { it.confidence *= 0.8f } }
```

**What's missing:** Confidence is only from LLM self-report + contradiction penalty.

**Implementation plan:**
```
1. Add computeConfidence() function:
   fun computeConfidence(
       llmConfidence: Float,         // from LLM self-report
       retrievalQuality: Float,       // how relevant was retrieved memory
       contradictionCount: Int,       // how many contradictions found
       predictionSuccess: Int,        // how many predictions were confirmed
       verificationOutcome: Boolean?, // was it verified?
       operatorAgreement: Float       // do multiple operators agree?
   ): Float {
       var conf = llmConfidence * 0.3f  // LLM gets 30% weight
       conf += retrievalQuality * 0.2f  // retrieval quality gets 20%
       conf -= contradictionCount * 0.1f  // contradictions penalize
       conf += predictionSuccess * 0.15f  // confirmed predictions boost
       if (verificationOutcome == true) conf += 0.15f  // verification boosts
       conf += operatorAgreement * 0.1f  // operator agreement boosts
       return conf.coerceIn(0.05f, 0.95f)
   }

2. Apply after each operator:
   val calibratedConfidence = computeConfidence(
       llmConfidence = lastResult.confidence,
       retrievalQuality = WorkingMemory.loadFactor(),
       contradictionCount = contradictions.size,
       predictionSuccess = confirmedPredictions,
       verificationOutcome = lastVerification,
       operatorAgreement = operatorAgreementScore
   )
```

**Estimated effort: 2 hours**

---

### GAP 5: FocusField — Full Cortical Dynamics ⭐⭐⭐

**What ChatGPT said:**
> "Every node would have: activation, attention, inhibition, curiosity, prediction. Attention moves. Activation spreads. Inhibition suppresses. Prediction prepares future activation."

**What already exists:**
```kotlin
data class SemanticNode(
    var activation: Float = 0.5f,  // ✅ exists
    var importance: Float,          // ✅ exists (proxy for attention)
    var confidence: Float,          // ✅ exists
    // attention ❌ missing
    // inhibition ❌ missing
    // curiosity ❌ missing
    // prediction ❌ missing
)
```

**Implementation plan:**
```
1. Add FocusField fields to SemanticNode:
   var attention: Float = 0f      // how much attention is allocated
   var inhibition: Float = 0f     // how much this node suppresses others
   var curiosity: Float = 0f      // how much this node "wants" to be explored
   var prediction: Float = 0f     // predicted activation in next step

2. Implement FocusField dynamics:
   - attention = activation * relevance * (1 - inhibition)
   - inhibition = sum of suppression from competing nodes
   - curiosity = (1 - confidence) * novelty * relevance
   - prediction = activation * (1 + spreading_from_neighbors)

3. Focus selection: node with highest attention wins
   - This replaces getFocusNode() with a richer mechanism

4. Implement attention movement:
   - When focus shifts, previous focus loses attention
   - New focus gains attention proportional to its surprise
   - Log: "Attention moved from X to Y (surprise: 0.67)"
```

**Estimated effort: 2.5 hours**

---

## PART 2: THE META-LEARNING ARCHITECTURE

The key insight from ChatGPT's analysis is that the engine should **learn from experience**. Here's how:

### The Operator Outcome Tracker

```
Session 1: "How to make a brain neuron on hardware?"
  ORIENT → topic: hardware, confusion: medium
  DECOMPOSE → 4 chunks
  SOLVE_CHUNK × 4 → avg confidence: 0.72
  PREDICT → 2 predictions
  CURIOSITY → 1 alternative
  HYPOTHESIZE → hypothesis confidence: 0.65
  VERIFY → verdict: SUPPORTED
  INTEGRATE → final confidence: 0.78
  
  Record to StrategyArchive:
  {
    problemType: "hardware",
    operatorSequence: ["ORIENT", "DECOMPOSE", "SOLVE_CHUNK×4", "PREDICT", "CURIOSITY", "HYPOTHESIZE", "VERIFY", "INTEGRATE"],
    finalConfidence: 0.78,
    success: true,
    totalTokens: 2400,
    surprise: 0.42
  }

Session 50: "How does quantum entanglement work?"
  StrategyArchive.query("physics") → 
    "For physics: FIRST_PRINCIPLES → ANALOGIZE → SOLVE_CHUNK × 2 → VERIFY worked best (avg conf: 0.85)"
  
  Engine biases toward this sequence instead of default ORIENT → DECOMPOSE
```

### The Learning Loop

```
Experience (session)
    ↓
Record outcomes (operator, confidence, surprise, success)
    ↓
Store in UnifiedStrategyArchive
    ↓
Next session: query archive for similar problems
    ↓
Bias operator selection toward successful patterns
    ↓
If new pattern works better → update archive
    ↓
Engine gradually optimizes itself
```

---

## PART 3: IMPLEMENTATION ROADMAP

### Phase F: Meta-Learning Wiring (3 hours)
**Impact: Highest | This makes the engine learn from experience**

| Step | What | Files | Time |
|------|------|-------|------|
| F1 | Add OperatorOutcome data class | CognitiveEngine.kt | 15min |
| F2 | Record outcomes at session end | CognitiveEngine.kt | 30min |
| F3 | Query archive at operator selection | CognitiveEngine.kt | 45min |
| F4 | Implement adaptive energy costs | CognitiveEngine.kt | 30min |
| F5 | Add problem type extraction from ORIENT | CognitiveEngine.kt | 30min |
| F6 | Wire episodic replaySimilar() into session start | CognitiveEngine.kt | 30min |

### Phase G: Prediction Error Dynamics (2 hours)
**Impact: High | This makes surprise drive learning**

| Step | What | Files | Time |
|------|------|-------|------|
| G1 | PE-gated node activation (surprise → extra activation) | CognitiveEngine.kt | 30min |
| G2 | PE-gated memory updating (small PE → edit, large PE → new) | CognitiveEngine.kt | 30min |
| G3 | Add PE to retrieval score | MemorySystems.kt | 30min |
| G4 | Log PE in observatory | LiveObservatoryUi.kt | 30min |

### Phase H: Multi-Signal Confidence (2 hours)
**Impact: Medium | This makes confidence trustworthy**

| Step | What | Files | Time |
|------|------|-------|------|
| H1 | Add computeConfidence() function | CognitiveEngine.kt | 45min |
| H2 | Wire into operator result processing | CognitiveEngine.kt | 30min |
| H3 | Add confidence breakdown to observatory | LiveObservatoryUi.kt | 30min |
| H4 | Store calibrated confidence in SemanticNode | CognitiveEngine.kt | 15min |

### Phase I: FocusField Dynamics (2.5 hours)
**Impact: Medium | This completes the cortical dynamics**

| Step | What | Files | Time |
|------|------|-------|------|
| I1 | Add attention/inhibition/curiosity/prediction fields | MemorySystems.kt | 30min |
| I2 | Implement FocusField computation | MemorySystems.kt | 45min |
| I3 | Replace getFocusNode() with FocusField selection | MemorySystems.kt | 30min |
| I4 | Implement attention movement logging | CognitiveEngine.kt | 30min |
| I5 | Display FocusField in observatory | LiveObservatoryUi.kt | 15min |

### Phase J: Episodic Reasoning Paths (2.5 hours)
**Impact: Medium | This enables "I solved something similar before"**

| Step | What | Files | Time |
|------|------|-------|------|
| J1 | Enhance EpisodicTrace with full session data | MemorySystems.kt | 30min |
| J2 | Record operator sequence + mistakes + corrections | CognitiveEngine.kt | 45min |
| J3 | Wire replaySimilar() into session start | CognitiveEngine.kt | 30min |
| J4 | Add "similar past session" to prompt | CognitiveEngine.kt | 30min |
| J5 | Display episodic recall in observatory | LiveObservatoryUi.kt | 15min |

---

## PART 4: TOTAL ESTIMATED EFFORT

| Phase | Hours | Impact | What It Enables |
|-------|-------|--------|-----------------|
| **F: Meta-Learning** | 3 | Engine learns which strategies work | Self-optimization |
| **G: Prediction Error** | 2 | Surprise drives learning | Adaptive attention |
| **H: Confidence** | 2 | Trustworthy confidence | Better decisions |
| **I: FocusField** | 2.5 | Full cortical dynamics | Brain-like processing |
| **J: Episodic Paths** | 2.5 | "I solved something similar" | Experience reuse |
| **TOTAL** | **12** | | |

**Minimum viable (F + G): 5 hours** — This alone would make the engine learn from experience and use surprise to drive attention.

---

## PART 5: THE FINAL ARCHITECTURE

After all phases, the engine operates as:

```
┌─────────────────────────────────────────────────────────┐
│                    COGNITIVE RUNTIME                      │
│                                                           │
│  ┌─────────────┐    ┌──────────────┐    ┌─────────────┐ │
│  │   Memory     │    │  Attention   │    │   Learning  │ │
│  │  (Activation │◄──►│  (FocusField │◄──►│  (Strategy  │ │
│  │   Network)   │    │   Dynamics)  │    │   Archive)  │ │
│  └──────┬──────┘    └──────┬───────┘    └──────┬──────┘ │
│         │                  │                    │         │
│  ┌──────▼──────────────────▼────────────────────▼──────┐ │
│  │              PHASE STATE MACHINE                     │ │
│  │  ORIENT → DECOMPOSE → SOLVE → PREDICT → VERIFY      │ │
│  │  (adapts based on strategy archive + episodic memory) │ │
│  └──────┬──────────────────┬────────────────────┬──────┘ │
│         │                  │                    │         │
│  ┌──────▼──────┐    ┌─────▼──────┐    ┌───────▼──────┐ │
│  │   LLM        │    │  Verifier  │    │   Episodic   │ │
│  │  (Generator) │    │  (Belief   │    │   Memory     │ │
│  │              │    │   Audit)   │    │  (Reasoning  │ │
│  │              │    │            │    │   Paths)     │ │
│  └──────────────┘    └────────────┘    └──────────────┘ │
│                                                           │
│  ┌──────────────────────────────────────────────────────┐ │
│  │              COGNITIVE ENERGY                         │ │
│  │  Depletes per operation │ Restores on surprise        │ │
│  │  Natural limit on recursion │ Allocates compute       │ │
│  └──────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

### The Core Invariant

> "You're no longer building a prompt around an LLM. You're building a cognitive runtime. The next leap isn't adding more cognitive modules—it's enabling the runtime itself to learn which strategies, memories, and reasoning patterns work best over repeated experience."

The LLM becomes one module in a larger adaptive system. The system learns from every session. Over time, it gets better at:
- Choosing which operators to use
- Allocating attention to surprising findings
- Recalling relevant past experiences
- Calibrating confidence from multiple signals
- Adapting its strategy to the problem type

**That is the transition from a sophisticated architecture to a genuinely adaptive one.**

---

*Blueprint v5.0 — Analysis + Implementation Plan*
*Total estimated effort: 12 hours for full implementation*
*Minimum viable (F + G): 5 hours*
