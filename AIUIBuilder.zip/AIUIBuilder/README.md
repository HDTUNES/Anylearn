# AI UI Builder Android GGUF Prototype

Kotlin + Jetpack Compose app that runs a local GGUF model through `llama.cpp`, asks it to output a safe JSON UI schema, then renders that JSON as native Android UI.

## Version 0.2.0

This version adds the simple local GGUF architecture:

```text
Local .gguf file from phone storage
  -> copied into app private storage
  -> llama.cpp Android native runtime
  -> model generates JSON only
  -> Kotlin parses JSON
  -> Jetpack Compose renders UI
```

## What the app can do

- Pick a `.gguf` model from your phone storage.
- Copy it into app storage so native llama.cpp can load it by file path.
- Load the model fully locally.
- Send a strict system prompt asking for JSON UI only.
- Generate UI JSON from your prompt.
- Parse/render supported elements:
  - `heading`
  - `text`
  - `input`
  - `button`
  - `checkbox`
  - `card`
  - `spacer`

## Build APK from phone using GitHub Actions

1. Upload all files from this folder to your GitHub repository root.
2. Go to **Actions**.
3. Run **Build Android APK**.
4. Wait. This version builds native `llama.cpp`, so it can take much longer than the previous app.
5. Download artifact named **AIUIBuilder-GGUF-debug-apk**.
6. Extract ZIP.
7. Install `app-debug.apk`.

## Important build note

The project does **not** store the huge `llama.cpp` source inside the ZIP. The GitHub workflow clones it automatically:

```text
external/llama.cpp
```

Then Gradle builds the official Android llama.cpp runtime as module `:llamaLib`.

## How to use on phone

1. Install the APK.
2. Download or copy a small GGUF model to your phone.
3. Open the app.
4. Tap **Pick GGUF**.
5. Select your `.gguf` file.
6. Tap **Load local model**.
7. Wait for loading to finish.
8. Type something like:

```text
Make a clean signup screen with name, email, password and register button
```

9. Tap **Generate JSON UI**.

## Recommended model size

For most phones, start smaller than DeepSeek 1.5B if possible. Good first tests:

- 0.5B to 1.5B model
- Q4 or Q3 quantization
- GGUF format
- ARM64 Android phone

DeepSeek-R1-Distill-Qwen-1.5B Q4 can work on many modern phones, but it may be slow and may need lots of free RAM.

## Safety design

The model does **not** run code. It only generates JSON. The Android app only renders known safe UI elements from a limited schema.

This is safer than allowing an AI model to generate and execute Kotlin/JavaScript code.
