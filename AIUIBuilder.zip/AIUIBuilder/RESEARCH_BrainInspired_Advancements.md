# Brain-Inspired Architecture Research — Next Advancements for MESA/AIUIBuilder

> Research date: 2026-06-26  
> Sources: arXiv (2024–2026), Hugging Face Papers, edge-AI/neuromorphic surveys.  
> Constraint: Android mobile, local GGUF via llama.cpp, no dedicated neuromorphic silicon. All proposals are therefore **algorithmic analogues** implementable in Kotlin/C++ on standard mobile hardware.

---

## 1. What the research actually says (with citations)

### 1.1 Active dendrites are the brain’s context-routing layer, not just wires
- **Biological fact:** Dendrites perform nonlinear, branch-local computation before signals reach the soma; they act as task/context gates that let the same neuron participate in different sub-networks for different tasks, mitigating catastrophic forgetting [1][2][3].
- **Transferable idea:** The current `domain_tag`/`lens` system is a coarse version of this. We can add a **context-gated activation mask** over the belief graph so that only nodes relevant to the current target cell are strongly active, suppressing others via lateral inhibition.

### 1.2 Predictive coding / Free Energy Principle (FEP) is the brain’s unified objective
- The brain minimizes *variational free energy* (prediction error), which decomposes into **accuracy** (fit observations) and **complexity** (stay close to prior beliefs) [4][5][6].
- **Transferable idea:** Every belief node should carry a *prediction* and a *prediction error*. High-surprise nodes get boosted activation and become targets for refinement. This replaces the current regex-based curiosity with a principled intrinsic-motivation signal.

### 1.3 Dual-memory systems (episodic + semantic) are required for continual learning
- Hippocampus-like fast episodic buffer stores recent traces; cortex-like slow semantic memory consolidates them during sleep [7][8].
- The current belief graph is purely semantic. Adding an **episodic replay buffer** and a **sleep consolidation** step that compresses traces into semantic nodes would make the system genuinely learn from its own trajectory rather than just append it.

### 1.4 Local synaptic plasticity (STDP) can learn structure from co-activation
- Biological synapses strengthen when pre- and post-synaptic neurons fire close in time; this is a **local, gradient-free** rule [9][10].
- **Transferable idea:** Update belief-graph edge weights based on co-activation timing in the working set. When two claims are repeatedly used together in the same iteration, strengthen their edge; when they contradict, weaken or flag it. This makes the graph *learn* instead of just recording.

### 1.5 Neuromorphic LLMs validate sparsity + MoE as the efficiency path
- SpikingBrain (7B/76B MoE) and Loihi-2 MatMul-free LLMs show that heavy activation sparsity and Mixture-of-Experts are the practical brain-inspired efficiency levers for modern LLMs, not hardware tricks [11][12].
- **Transferable idea:** Your Granite 1B MoE is already in this family. We should lean into **sparse activation** in the cognitive harness (small working set, top-k attention over nodes, skip irrelevant domains) rather than trying to force dense computation.

### 1.6 Self-evolving agents need a strong evaluator + open-ended archive
- Darwin Gödel Machine and the Self-Evolving Agents survey (2025) emphasize that evolution happens at four loci: model, context/memory, tools, and architecture. The engine of improvement is the **evaluator**; without it, the system games itself [13][14].
- **Transferable idea:** The current `ExecutionLayer` and `evaluateQualityScore` are a good start. The next step is to make the evaluator itself evolve: a small pool of evaluation lenses, updated by a meta-critic that detects which evaluators actually predict good outcomes.

---

## 2. Concrete, code-level improvements to add next

All of these are additions to the existing Kotlin harness; no neuromorphic hardware is required.

### A. Predictive Memory Layer (Free Energy Principle)
Add a `predictedOutcome` and `predictionError` field to `BeliefNode`. Before each iteration, the system predicts how the current target cell will evolve. After generation, it computes:

```kotlin
predictionError = 1 - wordOverlap(predictedOutcome, refinedText)
freeEnergy = accuracyTerm - complexityPenalty
```

High `predictionError` → boost node activation and mark the cell as high-priority for exploration. This is the **intrinsic motivation** signal.

### B. Dendritic Context Gating
Replace the current flat `assembleWorkingSetPrompt` with a **gated working set**:

```kotlin
fun assembleGatedWorkingSet(
    currentIter: Int,
    targetCell: ArchiveCell,
    maxChars: Int = 350
): String {
    val domainGate = MesaEngine.domainKeywords[targetCell.domainAxis] ?: emptySet()
    val abstractionGate = when (targetCell.abstractionAxis) {
        "concrete" -> setOf("mm", "ms", "watt", "nm", "voltage")
        "abstract" -> setOf("framework", "principle", "model")
        else -> emptySet()
    }
    return activeNodes.values
        .filter { it.status == "ACTIVE" }
        .map { node -> node to gatingScore(node, domainGate, abstractionGate) }
        .filter { it.second > 0.05f }
        .sortedByDescending { it.second * computeRetrievalScore(it.first, currentIter) }
        .take(5)
        .joinToString("\n") { "[${it.first.id}] ${it.first.claim}" }
}
```

This gives the same neuron (belief node) different effective weight depending on the active domain/context, exactly like active dendrites.

### C. Episodic Replay Buffer + Sleep Consolidation
Add a new class:

```kotlin
@Serializable
data class EpisodicTrace(
    val iter: Int,
    val targetCell: String,
    val refined: String,
    val verdict: String,        // survived or failed
    val surprise: Float
)

object EpisodicMemory {
    val buffer = ArrayDeque<EpisodicTrace>(maxSize = 32)
    
    fun replayHighSurpriseTraces(n: Int = 3): String {
        return buffer.sortedByDescending { it.surprise }
            .take(n)
            .joinToString("\n") { "[iter=${it.iter} ${it.targetCell}] ${it.refined}" }
    }
}
```

During the existing sleep pass (every 8 iterations), compress high-surprise traces into a new `BeliefNode` with `status = "CONSOLIDATED"` and add edges from the contributing traces.

### D. STDP-Style Edge Plasticity
Update `CognitiveOsMemory.registerDeltaUpdate` to strengthen/weaken edges based on temporal co-occurrence:

```kotlin
// After adding a new node, find recently active nodes (last 3 iterations)
val recentlyActive = activeNodes.values.filter { 
    it.id != newId && (currentStep - it.lastTouchIter) <= 3 
}
recentlyActive.forEach { recent ->
    val existing = beliefEdges.find { it.sourceId == recent.id && it.targetId == newId }
    if (existing != null) {
        // strengthen via co-activation
        existing.relation = "CO_ACTIVATED"
    } else if (recent.claim.lowercase().let { newClaim.lowercase().contains(it) || it.contains(newClaim.lowercase()) }) {
        beliefEdges.add(BeliefEdge(newId, recent.id, "RELATED"))
    }
}
```

### E. Adaptive Quality Threshold (Homeostasis)
In `MesaEngine.evaluateQualityScore`, make the threshold adaptive:

```kotlin
var homeostaticQualityThreshold = 0.45f

fun updateHomeostasis(successRate: Float) {
    // If succeeding too much, raise bar to force harder refinements
    // If failing, lower bar to escape local minima
    homeostaticQualityThreshold = when {
        successRate > 0.75f -> (homeostaticQualityThreshold + 0.02f).coerceAtMost(0.75f)
        successRate < 0.25f -> (homeostaticQualityThreshold - 0.03f).coerceAtLeast(0.25f)
        else -> homeostaticQualityThreshold
    }
}
```

### F. Meta-Critic Evaluation Pool
Instead of one fixed quality function, maintain a small pool of evaluation lenses (e.g., `specificity`, `cross_domain`, `falsifiability`, `simplicity`) and let a meta-critic update their weights based on which lens predicts later success:

```kotlin
data class EvaluatorLens(
    val name: String,
    val scoreFn: (String, String, ArchiveCell) -> Float,
    var weight: Float = 1.0f,
    var successes: Int = 0,
    var failures: Int = 0
)

object MetaCritic {
    val lenses = mutableListOf<EvaluatorLens>()
    
    fun combinedScore(refined: String, novelty: String, cell: ArchiveCell): Float {
        return lenses.sumOf { lens ->
            (lens.scoreFn(refined, novelty, cell) * lens.weight).toDouble()
        }.toFloat()
    }
    
    fun updateWeights(cell: ArchiveCell, becameElite: Boolean) {
        lenses.forEach { lens ->
            val score = lens.scoreFn(cell.bestHypothesis, "", cell)
            if (becameElite) lens.successes++ else lens.failures++
            // Thompson-style weight update
            lens.weight = (lens.successes + 1f) / (lens.successes + lens.failures + 2f)
        }
    }
}
```

---

## 3. Honest limits

1. **No actual SNN hardware on Android.** We cannot run Intel Loihi 2 or IBM TrueNorth on a phone. So all proposals are software-level analogues.
2. **Cannot update GGUF weights on-device.** The local model is frozen. Evolution is therefore limited to the **harness** (prompts, memory, evaluators, archive), not the model weights.
3. **Latency is real.** Adding predictive checks, episodic replay, and meta-critics costs native calls. Each must be conditionally fired (only when stuck, only every N iterations, or only on candidate elites) to keep the ~110–200s iteration time from ballooning.

---

## 4. Suggested implementation order

1. **Predictive Memory (A)** — highest leverage; changes the exploration signal from regex to principled surprise.
2. **Dendritic Context Gating (B)** — cheap, directly improves prompt quality and reduces token bloat.
3. **Adaptive Threshold (E)** — cheap, fixes the "first hypothesis locks the cell" problem.
4. **Episodic Replay + Sleep Consolidation (C)** — requires serialization changes; do after A/B/E are stable.
5. **STDP Edge Plasticity (D)** — adds real learning to the graph; do after C.
6. **Meta-Critic Pool (F)** — most advanced; do after the evaluator has a clean signal.

---

## 5. Citations

[1] Iyer et al., *Avoiding Catastrophe: Active Dendrites Enable Multi-Task Learning in Dynamic Environments*, arXiv:2201.00042, 2022.  
[2] Pes et al., *Active Dendrites Enable Efficient Continual Learning in Time-To-First-Spike Neural Networks*, arXiv:2404.19419, 2024.  
[3] DendSNN / *Scalable Dendritic Modeling Advances Expressive and Robust Deep SNNs*, arXiv:2412.06355, 2024/2025.  
[4] Friston, *The free-energy principle: a rough guide to the brain?*, Trends in Cognitive Sciences, 2009.  
[5] *A prescriptive theory for brain-like inference*, arXiv:2410.19315, 2024.  
[6] *Brain in the Dark: Design Principles for Neuromimetic Inference*, arXiv:2502.08860, 2025.  
[7] *Building Self-Evolving Agents via Experience-Driven Lifelong Learning*, arXiv:2508.19005, 2025.  
[8] AutoSkill, *Experience-Driven Lifelong Learning via Skill Memory*, arXiv:2603.01145, 2026.  
[9] *Neuromorphic Graph Anomaly Detection via Adaptive STDP and Spiking GNNs*, arXiv:2605.13863, 2026.  
[10] *Brain-inspired AI for Edge Intelligence: a systematic review*, arXiv:2603.26722, 2026.  
[11] *SpikingBrain: Spiking Brain-inspired Large Models*, arXiv:2509.05276, 2025.  
[12] *Neuromorphic Principles for Efficient LLMs on Intel Loihi 2*, arXiv:2503.18002, 2025.  
[13] *Darwin Gödel Machine: Open-Ended Evolution of Self-Improving Agents*, arXiv:2505.22954, 2025.  
[14] *A Survey of Self-Evolving Agents: What, When, How, and Where to Evolve*, arXiv:2507.21046, 2025/2026.  
[15] *Lessons from Neuroscience for AI: Actions, Predictions, and Multitimescale Processing*, arXiv:2512.22568, 2025.
