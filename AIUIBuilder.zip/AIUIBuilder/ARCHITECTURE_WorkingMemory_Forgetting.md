# Working Memory, Forgetting & Reinforcement Design

> Goal: Keep the LLM's active context at 500–1000 tokens while allowing effectively infinite reasoning, by mimicking the brain's bounded working memory + selective forgetting + reinforcement.

---

## 1. The problem with raw LLM context

A standard LLM chat loop does this:

```
User prompt
↓
Append to full history
↓
Send everything to model
↓
Model replies
↓
Repeat
```

This grows linearly. Eventually you hit the context limit (2K, 4K, 8K, whatever the model was loaded with). The model then either forgets the beginning or you have to truncate manually.

Your insight is correct: **humans don't do this**. We have a tiny working memory (~4 items or ~50 words) and a huge long-term memory. We retrieve only what is relevant, forget weak associations, and strengthen repeated ones.

---

## 2. The brain-like alternative

```
                    ┌────────────────────┐
                    │   LLM (frozen)     │
                    │ 500–1000 tokens   │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  Working Memory    │  ← max 5 items / ~800 chars
                    │  (active thoughts) │
                    └─────────┬──────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
   ┌────▼────┐          ┌────▼────┐          ┌────▼────┐
   │Retrieve │          │ Forget  │          │ Reinforce│
   │relevant │          │ weak   │          │ repeated │
   │memories │          │memories│          │ memories │
   └────┬────┘          └────────┘          └────────┘
        │
   ┌────▼────┐
   │ Long-Term│
   │ Memory  │
   │ (disk)  │
   └─────────┘
```

The LLM never sees the full history. It sees only the current goal + a tiny working-memory snippet. The Kotlin harness decides what goes in and what stays out.

---

## 3. Memory mechanics

### 3.1 Activation formula

Each memory node has:

- `importance` — how central it is to the topic (0..1)
- `recency` — time since last touch (decay curve)
- `frequency` — how often it has been touched
- `confidence` — how well it has been verified
- `relevance` — match to current goal

```
activation = importance × recency × (1 + ln(frequency)) × relevance × confidence
```

A node is **active** if activation > threshold (e.g., 0.25).  
A node is **archived** if activation drops below threshold.

### 3.2 Forgetting is interference-based, not time-based

We do not decay by wall-clock time. We decay by **interference**: every time a new memory is added, all existing memories receive a small penalty. The more new memories since the last touch, the more a node fades.

```
decay = base_decay ^ new_memory_count_since_last_touch
```

This means:

- If you stay focused on one topic, the memory stays strong.
- If you wander through 20 unrelated topics, old memories fade.

Exactly like human cognitive load.

### 3.3 Reinforcement by repetition

When a memory is retrieved or used in a successful reasoning step, its `frequency` and `lastTouch` update, boosting activation. Revisiting the same idea strengthens it, just like spaced repetition in the brain.

### 3.4 Working memory cap

Working memory holds at most:

- 5 semantic nodes, or
- ~800 characters of content, whichever is smaller.

Only the highest-activation nodes are loaded. Everything else stays in long-term memory on disk.

### 3.5 External notes

When the metacognitive monitor detects a high-value insight (high confidence + high surprise + memory load high), it writes a compact note to disk. This is the equivalent of a human writing in a notebook. Later, the retrieval pipeline can bring the note back if relevant.

---

## 4. Metacognitive decisions

The monitor asks three questions every cycle:

1. **Memory load?**  
   If > 80%, decide what to save to disk and what to evict from working memory.

2. **Relevant memory missing?**  
   If the current goal matches an archived or disk note, retrieve it.

3. **Worth reinforcing?**  
   If a memory was just used successfully, bump its strength.

---

## 5. Why this keeps the model fast

- Each LLM call sees only ~500–1000 tokens, always.
- The KV cache in the native runtime is reset per operator call, so no accumulated bloat.
- Long-term memory can grow to thousands of nodes without affecting prompt size.
- Forgetting naturally prunes noise.
- Reinforcement keeps the good ideas accessible.

The model does not need a larger context window. It needs a better memory system around it.

---

## 6. Implementation in AIUIBuilder

### New / updated files

- `MemorySystems.kt` — activation, interference decay, reinforcement, working-memory cap.
- `ExternalMemory.kt` — disk notes, save/retrieve based on relevance.
- `MetacognitiveMonitor.kt` — memory-load checks, save/retrieve triggers.
- `CognitiveEngine.kt` — assemble small working memory per operator, call save/retrieve.

### No new dependencies

WebView, JSON serialization, and coroutines are already present. The whole mechanism is Kotlin code in the harness.

---

## 7. Honest limits

- The local model is still frozen. We cannot make it "think faster" in a biological sense.
- The WebView JavaScript sandbox is not a full Python environment. Reality checks are limited to small numerical/logical scripts.
- Forgetting is a heuristic, not a biological process. We must tune the decay parameters for the user's device and use case.
- The quality of the system depends on the retrieval and evaluator quality. Bad retrieval = bad reasoning, no matter how clever the memory is.
