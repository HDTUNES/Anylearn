package com.arena.aiuibuilder

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/**
 * External Memory — the system's notebook.
 *
 * When the metacognitive monitor detects a high-value insight or high memory load,
 * it writes a compact note to disk. This is the equivalent of a human writing in a
 * notebook so they don't have to keep everything in their head.
 *
 * Notes are retrieved later when relevant to the current goal.
 */

@Serializable
data class ExternalNote(
    val id: String = UUID.randomUUID().toString(),
    val topic: String,
    val summary: String,
    val confidence: Float,
    val links: List<String>,
    val timestamp: Long = System.currentTimeMillis()
)

object ExternalMemory {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private const val STORE_FILE = "external_notes.json"
    private val notes = mutableListOf<ExternalNote>()

    fun load(context: Context) {
        val f = File(context.filesDir, STORE_FILE)
        if (!f.exists()) return
        runCatching {
            notes.clear()
            notes.addAll(json.decodeFromString<List<ExternalNote>>(f.readText()))
            AppLog.logStructured("INFO", "EXTERNAL", 0, "Loaded external notes", mapOf("count" to notes.size))
        }
    }

    fun save(context: Context) {
        runCatching {
            File(context.filesDir, STORE_FILE).writeText(json.encodeToString(notes.toList()))
        }
    }

    fun writeNote(context: Context, topic: String, summary: String, confidence: Float, links: List<String>) {
        load(context)
        val note = ExternalNote(topic = topic, summary = summary, confidence = confidence, links = links)
        notes.add(0, note)
        if (notes.size > 128) notes.removeLast()
        save(context)
        AppLog.logStructured("INFO", "EXTERNAL", SemanticMemory.getCurrentIter(), "Saved external note", mapOf("topic" to topic.take(30)))
    }

    fun retrieveRelevant(query: String, topK: Int = 3): List<ExternalNote> {
        val queryWords = query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        return notes.map { note ->
            val text = "${note.topic} ${note.summary} ${note.links.joinToString(" ")}".lowercase()
            val words = text.split(Regex("\\s+")).filter { it.length > 3 }.toSet()
            val overlap = if (words.isEmpty() || queryWords.isEmpty()) 0f else words.intersect(queryWords).size.toFloat() / words.union(queryWords).size.toFloat()
            note to overlap
        }
            .filter { it.second > 0.15f }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }

    fun allNotes(): List<ExternalNote> = notes.toList()
}
