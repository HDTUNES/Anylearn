package com.arena.aiuibuilder

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * App-level scopes for long local model work.
 *
 * Do not use rememberCoroutineScope for llama.cpp generation jobs: if the tab/screen
 * briefly leaves composition during a long native call, Compose cancels that scope and
 * the result is lost with "Coroutine scope left the composition".
 */
object AppScopes {
    val main: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
}
