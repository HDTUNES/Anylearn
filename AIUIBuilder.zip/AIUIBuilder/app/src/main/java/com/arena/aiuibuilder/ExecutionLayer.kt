package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

// =============================================================================
// STAGE 2 SELF-EVOLVING SCIENTIST: EXECUTION & HYPOTHESIS TESTING LAYER
// Implements 4 Modalities: Graph Traversal, Adversarial Challenge, Specificity, Coherence
// =============================================================================

@Serializable
data class EmpiricalTestReport(
    val survivedChallenge: Boolean,
    val fatalObjection: String,
    val empiricalSpecificityScore: Float,
    val finalRealityMultiplier: Float
)

object ExecutionLayer {
    private val json = Json { ignoreUnknownKeys = false }

    /**
     * Modality 3: Zero-token regex specificity gate.
     * Evaluates whether hypothesis contains falsifiable metrics, physical units, or named mechanisms.
     */
    fun evaluateSpecificityGate(claim: String): Float {
        var score = 0.50f
        if (claim.contains(Regex("\\d+"))) score += 0.20f
        if (claim.contains(Regex("%|kg|ms|ns|W|GHz|MHz|mm|nm|C|K|\\$"))) score += 0.20f
        if (claim.contains(Regex("(?i)holt-winters|stdp|memristor|lyapunov|bayes|markov|monte carlo|fdr"))) score += 0.10f
        return score.coerceIn(0.1f, 1.0f)
    }

    /**
     * Modality 1: Free instant graph consistency traversal ($O(E)$ cycles).
     * Checks whether candidate claim contradicts established verified active nodes.
     */
    fun verifyGraphConsistency(claimKey: String, contradictsId: String?): Boolean {
        if (contradictsId == null) return true
        val targetCount = CognitiveOsMemory.getEdgesCount()
        // If node has extensive downstream dependencies, block frivolous contradiction
        return targetCount < 100
    }

    /**
     * Modality 2 & 4: 50-Token Devil's Advocate Micro-Challenge & Reality Execution Gate.
     * Subjects hypothesis to rigorous adversarial scrutiny before allowing archive insertion.
     */
    fun executeRealityValidation(
        hypothesis: String,
        temperature: Float = 0.3f,
        topK: Int = 40,
        topP: Float = 0.9f,
        minP: Float = 0.05f,
        repeatPenalty: Float = 1.1f
    ): EmpiricalTestReport {
        val specificity = evaluateSpecificityGate(hypothesis)

        val challengePrompt = buildString {
            appendLine("You are an empirical reality scientific verifier.")
            appendLine("Hypothesis Candidate: \"${hypothesis.take(280)}\"")
            appendLine("Task: State the single strongest fatal physical or logical objection to this hypothesis in 1 sentence. Then state exactly SURVIVES or FAILS.")
            appendLine("Output JSON shape: {\"refined\": \"<objection>\", \"next_focus\": \"SURVIVES or FAILS\"}")
        }

        var survived = true
        var objection = "None"
        try {
            val raw = NativeRecursiveRefiner.refineOnce(challengePrompt, 70, temperature, topK, topP, minP, repeatPenalty)
            val parsed = runCatching { json.decodeFromString<StrictRefinerJson>(raw) }.getOrNull()
            val verdict = (parsed?.next_focus ?: raw).uppercase()
            objection = parsed?.refined?.take(100) ?: "Empirical challenge unparsed."
            survived = !verdict.contains("FAILS") && !verdict.contains("COLLAPSE")
            AppLog.append("ExecutionLayer Tester: objection=\"$objection\" verdict=$verdict survived=$survived")
        } catch (e: Exception) {
            AppLog.append("ExecutionLayer micro-call fallback: ${e.message}")
        }

        val realityMultiplier = if (survived) (1.0f + (specificity * 0.2f)).coerceAtMost(1.2f) else 0.30f

        return EmpiricalTestReport(
            survivedChallenge = survived,
            fatalObjection = objection,
            empiricalSpecificityScore = specificity,
            finalRealityMultiplier = realityMultiplier
        )
    }
}
