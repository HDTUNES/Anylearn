package com.arena.aiuibuilder

data class WorldModel(
  val concepts: List<GroundedConcept>,
  val relations: List<String>,
  val physicalAnalogues: List<String>,
  val equations: List<String>,
  val promptBlock: String,
  val tokenEstimate:Int
)
data class GroundedConcept(val name:String, val definition:String, val physicalBasis:String, val math:String?, val confidence:Float)

object WorldModelAssembler {
  private val kb = mapOf(
    "neuron" to GroundedConcept("neuron","excitable cell with dendrite/soma/axon","lipid bilayer + voltage-gated ion channels","V_m = Q/C_m",0.95f),
    "action potential" to GroundedConcept("action potential","all-or-nothing ~100mV spike, ~1-2ms","Na+ inrush then K+ efflux","Hodgkin-Huxley: C dV/dt = I - Σ g_i(V-E_i)",0.93f),
    "ion channel" to GroundedConcept("ion channel","voltage-gated conductance pore","protein conformation change","g = g_bar m^p h^q",0.9f),
    "memristor" to GroundedConcept("memristor","resistance depends on charge history","TiO2 oxygen vacancy drift","M(q)",0.88f),
    "lif model" to GroundedConcept("LIF neuron","leaky integrate-and-fire","RC circuit + comparator","tau dV/dt = -V + R I",0.92f),
    "izhikevich" to GroundedConcept("Izhikevich neuron","2D spiking, biologically plausible, cheap","v' = 0.04v^2+5v+140-u+I ; u' = a(bv-u)","v'=..., u'=...",0.9f),
    "neuromorphic" to GroundedConcept("neuromorphic chip","spiking event-driven hardware","async digital / mixed-signal SNN fabric","event-driven",0.88f),
    "loihi" to GroundedConcept("Loihi","Intel SNN research chip, 128 cores, ~130k neurons","async mesh, programmable LIF","—",0.84f),
    "transistor" to GroundedConcept("transistor","voltage-controlled switch / amplifier","MOSFET CMOS","I_D = ...",0.95f),
    "capacitor" to GroundedConcept("capacitor","stores charge Q=CV","parallel plates / MOS cap","Q=CV, I=C dV/dt",0.95f),
    "spiking neural network" to GroundedConcept("SNN","event-driven neural net with spikes","leaky integrators + thresholds","spike(t)",0.9f),
    "hodgkin" to GroundedConcept("Hodgkin-Huxley","biophysical neuron model","ion channel kinetics","C dV/dt = I - g_Na m^3 h (V-E_Na) ...",0.93f)
  )

  fun assemble(intent:BrainIntent, retrieved:List<SemanticNode>): WorldModel = PipelineTimer.measure("WORLD_MODEL_ASSEMBLY"){
    val seedNames = intent.entities.mapNotNull{ e -> kb.keys.find{ k -> e.contains(k) || k.contains(e) } }.distinct()
      .ifEmpty{
        when(intent.domain){
          "neuroscience_hardware" -> listOf("neuron","action potential","ion channel","memristor","lif model","neuromorphic")
          else -> listOf("transistor","capacitor")
        }
      }
    val concepts = seedNames.mapNotNull{ kb[it] }.take(8)
    val memConcepts = retrieved.take(3).map{
      GroundedConcept(it.label, it.content.take(160), "memory-derived", null, it.confidence)
    }
    val allConcepts = (concepts + memConcepts).distinctBy{it.name}.take(9)
    val relations = mutableListOf<String>()
    if(allConcepts.any{it.name=="neuron"} && allConcepts.any{it.name=="memristor"}) relations += "memristor --analog--> ion_channel"
    if(allConcepts.any{it.name.contains("LIF")}) relations += "LIF --implements--> neuron --on--> CMOS/analog"
    if(allConcepts.any{it.name=="action potential"}) relations += "action_potential --produced_by--> ion_channel"
    val analogues = buildList{
      if(allConcepts.any{it.name=="neuron"}) { add("RC + comparator = LIF"); add("memristor crossbar = synapse"); add("OpAmp integrator = soma") }
      add("FPGA SNN = digital spiking"); add("Loihi / TrueNorth = neuromorphic ASIC")
    }
    val equations = allConcepts.mapNotNull{it.math}.distinct().take(4)
    val conceptBlock = allConcepts.joinToString("\n"){ "- ${it.name}: ${it.definition} | phys: ${it.physicalBasis}" }
    val promptBlock = """
WORLD MODEL — grounded concepts:
$conceptBlock

Relations:
${relations.joinToString("\n")}

Physical analogues (nearest first):
${analogues.joinToString("\n- ", "- ")}

Equations:
${equations.joinToString("\n")}

RULE: Always start reasoning from these concrete physical concepts before abstract speculation. 
If proposing a hardware neuron: start LIF RC → add Na/K channel analogue → compare memristor / CMOS / FPGA / Loihi.
""".trimIndent().take(1900)
    WorldModel(allConcepts, relations, analogues, equations, promptBlock, promptBlock.length/4)
  }
}
