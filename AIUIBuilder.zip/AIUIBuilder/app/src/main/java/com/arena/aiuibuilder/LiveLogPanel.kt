package com.arena.aiuibuilder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LiveLogPanel() {
    val logs = ObservatoriumSession.liveTerminalLogs
    val clipboard = LocalClipboardManager.current

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("LIVE LOG", color = ObsColors.TextDim, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 1.5.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(
                    onClick = {
                        val all = logs.reversed().joinToString("\n") { entry ->
                            "[${entry.timestamp}][${entry.level}][${entry.stage}] iter=${entry.iteration} ${entry.message}"
                        }
                        clipboard.setText(AnnotatedString(all))
                    },
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Copy Log", color = ObsColors.AccentCyan, fontSize = 10.sp)
                }
                TextButton(
                    onClick = { ObservatoriumSession.liveTerminalLogs.clear() },
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Clear", color = ObsColors.TextDim, fontSize = 10.sp)
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(Color(0xFF000000), RoundedCornerShape(6.dp))
                .border(0.5.dp, ObsColors.Border, RoundedCornerShape(6.dp))
                .padding(8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                if (logs.isEmpty()) {
                    Text("No logs yet. Start a session.", color = ObsColors.TextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                logs.take(200).forEach { entry ->
                    val levelColor = when (entry.level) {
                        "ERROR" -> ObsColors.AccentRed
                        "WARN"  -> ObsColors.AccentAmber
                        "DEBUG" -> ObsColors.TextDim
                        else    -> ObsColors.TextMuted
                    }
                    val stageColor = when (entry.stage) {
                        "GENERATE", "HYPOTHESIS_GENERATION" -> Color(0xFF86EFAC)
                        "META"     -> ObsColors.AccentAmber
                        "EXTERNAL" -> ObsColors.AccentCyan
                        else       -> ObsColors.TextDim
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("[${entry.timestamp}]", color = ObsColors.TextDim,         fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(72.dp))
                        Text(entry.level.take(4).padEnd(4),  color = levelColor,         fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(28.dp))
                        Text(entry.stage.take(8).padEnd(8),  color = stageColor,         fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(56.dp))
                        Text(entry.message, color = ObsColors.TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}