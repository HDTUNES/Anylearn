package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

@Serializable
data class ArchiveCell(
    val domainAxis: String,       // "structural", "biological", "economic", "physical", "computational"
    val abstractionAxis: String,  // "concrete", "intermediate", "abstract"
    var bestHypothesis: String = "",
    var qualityScore: Float = 0f,
    var noveltyScore: Float = 0f,
    var visitCount: Int = 0
)

@Serializable
data class ReasoningPolicy(
    val name: String,
    val domain: String,
    val lens: String,
    var alpha: Float = 1f,
    var beta: Float = 1f
) {
    fun sampleBetaThompson(): Float {
        val mean = alpha / (alpha + beta)
        val varianceNoise = (Random.nextFloat() - 0.5f) * (1.0f / sqrt(alpha + beta))
        return (mean + varianceNoise).coerceIn(0.01f, 0.99f)
    }

    val successRate: Float get() = alpha / (alpha + beta)
}

@Serializable
data class FailurePostMortem(
    val stalledIter: Int,
    val stuckPhrase: String,
    val whyStuck: String,
    val pivotDirection: String
)

object MesaEngine {
    val domains = listOf("structural", "biological", "economic", "physical", "computational")
    val abstractions = listOf("concrete", "intermediate", "abstract")
    val archiveGrid = mutableMapOf<String, ArchiveCell>()
    val policyBandits = mutableListOf<ReasoningPolicy>()
    val failureMemoryStore = mutableListOf<FailurePostMortem>()
    var totalIterationsRun: Int = 0
    var currentWinningPolicy: ReasoningPolicy? = null
    var currentTargetCellKey: String? = null

    val domainKeywords = mapOf(
        "biological" to setOf("cell", "organism", "evolution", "immune", "neural", "metabolic", "gene", "adaptation", "ecosystem", "species", "dna", "rna", "neuron", "synaptic"),
        "economic" to setOf("cost", "incentive", "market", "budget", "roi", "price", "supply", "demand", "revenue", "subsidy", "capital", "utility", "scale"),
        "physical" to setOf("force", "energy", "mass", "velocity", "thermal", "pressure", "material", "circuit", "voltage", "silicon", "hardware", "semiconductor"),
        "computational" to setOf("algorithm", "latency", "cache", "query", "index", "compute", "parallel", "throughput", "api", "compiler", "gpus", "tpu", "fpga")
    )

    fun initMesa(grounding: String) {
        totalIterationsRun = 1
        archiveGrid.clear()
        policyBandits.clear()
        failureMemoryStore.clear()
        for (d in domains) {
            for (a in abstractions) {
                archiveGrid["$d/$a"] = ArchiveCell(d, a)
            }
        }
        for (d in domains) {
            for (lens in RefinerConfigDefaults.lenses.take(4)) {
                policyBandits.add(ReasoningPolicy("${d}_${lens.take(10).replace(" ", "_")}", d, lens))
            }
        }
        archiveGrid["structural/concrete"]?.let {
            it.bestHypothesis = grounding.trim()
            it.qualityScore = 0.45f
            it.visitCount = 1
        }
        currentTargetCellKey = "structural/concrete"

        // Register each policy bandit into the shared strategy archive (blueprint 5.4).
        // This makes Refiner-discovered strategies available to the Cognitive engine too.
        policyBandits.forEach { policy ->
            UnifiedStrategyArchive.register(
                StrategyArm(
                    id = "refiner_${policy.name}",
                    source = "refiner",
                    description = "${policy.domain} / ${policy.lens}",
                    tags = domainKeywords[policy.domain] ?: emptySet()
                )
            )
        }
    }

    fun selectExplorationTargetCell(explorationC: Float = 0.45f): ArchiveCell {
        val unvisited = archiveGrid.values.filter { it.visitCount == 0 }
        val chosen = if (unvisited.isNotEmpty()) {
            unvisited.random()
        } else {
            archiveGrid.values.maxByOrNull { cell ->
                val ucbBonus = explorationC * sqrt(ln(totalIterationsRun.coerceAtLeast(2).toFloat()) / cell.visitCount.coerceAtLeast(1))
                cell.qualityScore + ucbBonus
            } ?: archiveGrid.values.first()
        }
        currentTargetCellKey = "${chosen.domainAxis}/${chosen.abstractionAxis}"
        return chosen
    }

    fun selectWinningPolicy(): ReasoningPolicy {
        if (policyBandits.isEmpty()) return ReasoningPolicy("default", "structural", "structural improvement")
        val winning = policyBandits.maxByOrNull { it.sampleBetaThompson() } ?: policyBandits.first()
        currentWinningPolicy = winning
        return winning
    }

    fun verifyDomainTag(claimed: String, hypothesis: String): String {
        val normalized = claimed.trim().lowercase()
        val keywords = domainKeywords[normalized] ?: return "structural"
        val text = hypothesis.lowercase()
        return if (keywords.any { text.contains(it) }) normalized else "structural"
    }

    fun evaluateAdversarialRobustness(hypothesis: String, noveltyClaim: String): Float {
        var baseScore = 0.40f
        if (hypothesis.contains(Regex("\\d+"))) baseScore += 0.15f
        if (hypothesis.contains(Regex("%|kg|ms|ns|W|GHz|MHz|mm|nm|C|K|\\$"))) baseScore += 0.15f
        if (hypothesis.contains(Regex("(?i)synapse|memristor|neuromorphic|gate|plasticity|feedback|stability|quantum|probabilistic|fpga|silicon"))) {
            baseScore += 0.10f
        }
        val genericWords = setOf("iterative", "progression", "improvement", "structural", "version", "refinement")
        val noveltyWords = noveltyClaim.lowercase().split(" ").filter { it.length > 3 }.toSet()
        val isGeneric = noveltyWords.any { it in genericWords }
        if (noveltyClaim.length > 20 && !isGeneric) {
            baseScore += 0.20f
        } else {
            baseScore -= 0.10f
        }
        return baseScore.coerceIn(0.05f, 1.0f)
    }

    fun commitIterationResult(
        domainTag: String,
        abstractionLevel: String,
        refinedText: String,
        noveltyClaim: String,
        isDuplicate: Boolean,
        empiricalMultiplier: Float = 1.0f
    ): Boolean {
        totalIterationsRun += 1
        val policy = currentWinningPolicy ?: policyBandits.firstOrNull() ?: return false
        if (isDuplicate) {
            policy.beta += 1.0f
            // Also record in unified archive (blueprint 5.4)
            UnifiedStrategyArchive.recordOutcome("refiner_${policy.name}", success = false)
            AppLog.append("MESA Bandit: Penalized policy [${policy.name}] due to duplicate restatement.")
            return false
        }
        val normDomain = verifyDomainTag(domainTag, refinedText)
        val normAbs = if (abstractionLevel.lowercase() in abstractions) abstractionLevel.lowercase() else "intermediate"
        val coordKey = "$normDomain/$normAbs"
        val cell = archiveGrid[coordKey] ?: ArchiveCell(normDomain, normAbs)
        val computedQuality = evaluateAdversarialRobustness(refinedText, noveltyClaim) * empiricalMultiplier
        var becameElite = false
        if (computedQuality > cell.qualityScore) {
            cell.bestHypothesis = refinedText.trim()
            cell.qualityScore = computedQuality
            becameElite = true
            policy.alpha += 1.0f
            // Record success in unified archive (blueprint 5.4)
            UnifiedStrategyArchive.recordOutcome("refiner_${policy.name}", success = true)
            AppLog.append("MESA Elites: New elite established at [$coordKey] (Score: ${"%.2f".format(computedQuality)})")
        } else {
            policy.beta += 0.5f
            // Record partial failure in unified archive (blueprint 5.4)
            UnifiedStrategyArchive.recordOutcome("refiner_${policy.name}", success = false)
        }
        cell.visitCount += 1
        archiveGrid[coordKey] = cell
        return becameElite
    }

    fun recordReflexionFailure(stalledPhrase: String, why: String, pivot: String) {
        failureMemoryStore.add(0, FailurePostMortem(totalIterationsRun, stalledPhrase, why, pivot))
        if (failureMemoryStore.size > 3) failureMemoryStore.removeLast()
    }
}
