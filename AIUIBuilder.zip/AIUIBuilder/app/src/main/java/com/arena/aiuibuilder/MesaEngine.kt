package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

// =============================================================================
// MESA SELF-ADAPTING REASONING OS PRIMITIVES
// Research Synthesis: MAP-Elites + LATS (MCTS/UCB) + Thompson Bandits + Reflexion
// =============================================================================

@Serializable
data class ArchiveCell(
    val domainAxis: String,       // "structural", "biological", "economic", "physical", "computational"
    val abstractionAxis: String,  // "concrete", "intermediate", "abstract"
    var bestHypothesis: String = "",
    var qualityScore: Float = 0f,
    var noveltyScore: Float = 0f,
    var visitCount: Int = 0
)

@Serializable
data class ReasoningPolicy(
    val name: String,
    val domain: String,
    val lens: String,
    var alpha: Float = 1f, // Thompson prior successes + 1
    var beta: Float = 1f   // Thompson prior failures + 1
) {
    fun sampleBetaThompson(): Float {
        val mean = alpha / (alpha + beta)
        val varianceNoise = (Random.nextFloat() - 0.5f) * (1.0f / sqrt(alpha + beta))
        return (mean + varianceNoise).coerceIn(0.01f, 0.99f)
    }

    val successRate: Float get() = alpha / (alpha + beta)
}

@Serializable
data class FailurePostMortem(
    val stalledIter: Int,
    val stuckPhrase: String,
    val whyStuck: String,
    val pivotDirection: String
)

object MesaEngine {
    private val json = Json { ignoreUnknownKeys = false; prettyPrint = true }

    val domains = listOf("structural", "biological", "economic", "physical", "computational")
    val abstractions = listOf("concrete", "intermediate", "abstract")
    val archiveGrid = mutableMapOf<String, ArchiveCell>()

    val policyBandits = mutableListOf<ReasoningPolicy>()
    val failureMemoryStore = mutableListOf<FailurePostMortem>()

    var totalIterationsRun: Int = 0
    var currentWinningPolicy: ReasoningPolicy? = null
    var currentTargetCellKey: String? = null

    val domainKeywords = mapOf(
        "biological" to setOf("cell", "organism", "evolution", "immune", "neural", "metabolic", "gene", "adaptation", "ecosystem", "species"),
        "economic" to setOf("cost", "incentive", "market", "budget", "roi", "price", "supply", "demand", "revenue", "subsidy"),
        "physical" to setOf("force", "energy", "mass", "velocity", "thermal", "pressure", "material", "circuit", "voltage"),
        "computational" to setOf("algorithm", "latency", "cache", "query", "index", "compute", "parallel", "throughput", "api")
    )

    fun initMesa(grounding: String) {
        totalIterationsRun = 1
        archiveGrid.clear()
        policyBandits.clear()
        failureMemoryStore.clear()

        for (d in domains) {
            for (a in abstractions) {
                archiveGrid["$d/$a"] = ArchiveCell(d, a)
            }
        }

        for (d in domains) {
            for (lens in RefinerConfigDefaults.lenses.take(3)) {
                policyBandits.add(ReasoningPolicy("${d}_${lens.take(10)}", d, lens))
            }
        }

        archiveGrid["structural/concrete"]?.let {
            it.bestHypothesis = grounding.trim()
            it.qualityScore = 1.0f
            it.visitCount = 1
        }
        currentTargetCellKey = "structural/concrete"
    }

    fun selectExplorationTargetCell(explorationC: Float = 0.45f): ArchiveCell {
        val unvisited = archiveGrid.values.filter { it.visitCount == 0 }
        val chosen = if (unvisited.isNotEmpty()) unvisited.random() else {
            archiveGrid.values.maxByOrNull { cell ->
                val ucbBonus = explorationC * sqrt(ln(totalIterationsRun.coerceAtLeast(2).toFloat()) / cell.visitCount.coerceAtLeast(1))
                cell.qualityScore + ucbBonus
            } ?: archiveGrid.values.first()
        }
        currentTargetCellKey = "${chosen.domainAxis}/${chosen.abstractionAxis}"
        return chosen
    }

    fun selectWinningPolicy(): ReasoningPolicy {
        if (policyBandits.isEmpty()) return ReasoningPolicy("default", "structural", "structural improvement")
        val winning = policyBandits.maxByOrNull { it.sampleBetaThompson() } ?: policyBandits.first()
        currentWinningPolicy = winning
        return winning
    }

    fun verifyDomainTag(claimed: String, hypothesis: String): String {
        val keywords = domainKeywords[claimed] ?: return "structural"
        val text = hypothesis.lowercase()
        return if (keywords.any { text.contains(it) }) claimed else "structural"
    }

    fun evaluateAdversarialRobustness(hypothesis: String, noveltyClaim: String): Float {
        var baseScore = 0.70f
        if (hypothesis.contains(Regex("\\d+")) || hypothesis.contains("%") || hypothesis.contains("kg") || hypothesis.contains("W")) {
            baseScore += 0.20f
        }
        if (noveltyClaim.length > 25 && !hypothesis.lowercase().contains("sensitivity analysis")) {
            baseScore += 0.10f
        } else {
            baseScore *= 0.30f
        }
        return baseScore.coerceIn(0.05f, 1.0f)
    }

    fun commitIterationResult(
        domainTag: String,
        abstractionLevel: String,
        refinedText: String,
        noveltyClaim: String,
        isDuplicate: Boolean,
        empiricalMultiplier: Float = 1.0f
    ): Boolean {
        totalIterationsRun += 1
        val policy = currentWinningPolicy ?: policyBandits.firstOrNull() ?: return false

        if (isDuplicate) {
            policy.beta += 1.0f
            AppLog.append("MESA Bandit: Penalized policy [${policy.name}] due to duplicate restatement.")
            return false
        }

        val normDomain = verifyDomainTag(domainTag.lowercase(), refinedText)
        val normAbs = if (abstractionLevel.lowercase() in abstractions) abstractionLevel.lowercase() else "intermediate"
        val coordKey = "$normDomain/$normAbs"

        val cell = archiveGrid[coordKey] ?: ArchiveCell(normDomain, normAbs)
        val computedQuality = evaluateAdversarialRobustness(refinedText, noveltyClaim) * empiricalMultiplier

        var becameElite = false
        if (computedQuality > cell.qualityScore) {
            cell.bestHypothesis = refinedText.trim()
            cell.qualityScore = computedQuality
            becameElite = true
            policy.alpha += 1.0f
            AppLog.append("MESA Elites: New elite established at [$coordKey] (Score: ${"%.2f".format(computedQuality)})")
        } else {
            policy.beta += 0.5f
        }

        cell.visitCount += 1
        archiveGrid[coordKey] = cell
        return becameElite
    }

    fun recordReflexionFailure(stalledPhrase: String, why: String, pivot: String) {
        failureMemoryStore.add(0, FailurePostMortem(totalIterationsRun, stalledPhrase, why, pivot))
        if (failureMemoryStore.size > 3) failureMemoryStore.removeLast()
    }
}
