package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.LaunchedEffect

private val Panel = Color(0xFF111827)
private val Panel2 = Color(0xFF0F172A)
private val Stroke = Color(0xFF263244)
private val TextMain = Color(0xFFE5E7EB)
private val TextMuted = Color(0xFF94A3B8)
private val Accent = Color(0xFF7C3AED)


/**
 * Assembles a complete session dump for "Copy Full Session".
 * Captures everything: raw thinking stream, pipeline stage diagnostics,
 * reasoning trace, structured answer, and final answer.
 * Designed to be called at copy-time so it captures the live state
 * even while the model is still generating.
 */
private fun buildFullSessionDump(
    query: String,
    cumulativeThinking: String,
    liveTokenStream: String,
    rawTrace: String,
    result: CognitiveResult?,
    stageMap: Map<PipelineStage, StageDiagnostics>
): String {
    val sb = StringBuilder()
    val separator = "═".repeat(72)

    sb.appendLine(separator)
    sb.appendLine("  COGNITIVE ENGINE — FULL SESSION DUMP")
    sb.appendLine("  Generated: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
    sb.appendLine(separator)
    sb.appendLine()

    // ── Query ──
    sb.appendLine("┌─ QUERY ─────────────────────────────────────────")
    sb.appendLine(query)
    sb.appendLine("└─────────────────────────────────────────────────")
    sb.appendLine()

    // ── Raw Thinking / Token Stream ──
    // This is the complete, unfiltered model output across ALL operator calls:
    // JSON fragments, intermediate reasoning, partial structures, everything.
    val fullThinking = if (liveTokenStream.length > cumulativeThinking.length) liveTokenStream else cumulativeThinking
    if (fullThinking.isNotBlank()) {
        sb.appendLine("┌─ RAW THINKING STREAM (${fullThinking.length} chars) ──────────────")
        sb.appendLine(fullThinking)
        sb.appendLine("└─────────────────────────────────────────────────")
        sb.appendLine()
    }

    // ── Pipeline Stage Diagnostics ──
    if (stageMap.isNotEmpty()) {
        sb.appendLine("┌─ PIPELINE STAGE DIAGNOSTICS ────────────────────")
        PipelineStage.entries.forEach { stage ->
            val diag = stageMap[stage]
            if (diag != null) {
                val statusIcon = when (diag.status) {
                    StageStatus.COMPLETED -> "[✓]"
                    StageStatus.ACTIVE    -> "[⟳]"
                    StageStatus.FAILED    -> "[✗]"
                    StageStatus.SKIPPED   -> "[→]"
                    else                  -> "[ ]"
                }
                sb.appendLine("  $statusIcon ${stage.name}")
                if (diag.inputSummary.isNotBlank()) sb.appendLine("      Input:  ${diag.inputSummary}")
                if (diag.outputSummary.isNotBlank()) sb.appendLine("      Output: ${diag.outputSummary}")
                if (diag.outputSizeChars > 0) sb.appendLine("      Size:   ${diag.outputSizeChars} chars")
                if (diag.promptSizeChars > 0) sb.appendLine("      Prompt: ${diag.promptSizeChars} chars (~${diag.promptSizeTokensEstimate} tokens)")
                if (diag.readNodes.isNotEmpty()) sb.appendLine("      Memory reads: ${diag.readNodes.joinToString(", ")}")
                if (diag.writtenNodes.isNotEmpty()) sb.appendLine("      Memory writes: ${diag.writtenNodes.joinToString(", ")}")
                if (diag.selectedCell.isNotBlank()) sb.appendLine("      Cell: ${diag.selectedCell} | UCB: ${"%.3f".format(diag.ucbScore)}")
                if (diag.winningPolicy.isNotBlank()) sb.appendLine("      Policy: ${diag.winningPolicy} (${"%.0f".format(diag.policySuccessRate * 100)}% success)")
                if (diag.codeSnippet.isNotBlank()) sb.appendLine("      Code: ${diag.codeSnippet.take(200)}")
                if (diag.codeOutput.isNotBlank()) sb.appendLine("      Exec: ${diag.codeOutput.take(200)} (${diag.codeTimeMs}ms, ${if (diag.codeSuccess) "OK" else "FAIL"})")
                if (diag.jaccardScore > 0f) sb.appendLine("      Jaccard: ${"%.3f".format(diag.jaccardScore)} | Domain: ${diag.domainVerified} | Gate: ${diag.adversarialGate}")
                if (diag.repairLog.isNotBlank()) sb.appendLine("      Repair: ${diag.repairLog.take(200)} (${diag.repairAttempts} attempts)")
                if (diag.errorMessage != null) sb.appendLine("      ERROR: ${diag.errorMessage}")
                if (diag.rawJsonGenerated.isNotBlank()) sb.appendLine("      Raw JSON: ${diag.rawJsonGenerated.take(500)}")
                val elapsed = if (diag.completedAtMs > 0 && diag.startedAtMs > 0) diag.completedAtMs - diag.startedAtMs else 0
                if (elapsed > 0) sb.appendLine("      Time: ${elapsed}ms")
            }
        }
        sb.appendLine("└─────────────────────────────────────────────────")
        sb.appendLine()
    }

    // ── Reasoning Trace (operator-level) ──
    if (rawTrace.isNotBlank()) {
        sb.appendLine("┌─ REASONING TRACE ───────────────────────────────")
        sb.appendLine(rawTrace)
        sb.appendLine("└─────────────────────────────────────────────────")
        sb.appendLine()
    }

    // ── Final Result ──
    if (result != null) {
        sb.appendLine("┌─ FINAL RESULT ──────────────────────────────────")
        sb.appendLine("  Confidence: ${"%.1f".format(result.confidence * 100)}%")
        sb.appendLine()

        val narration = result.structuredAnswer["how_i_got_here"]
        if (!narration.isNullOrBlank()) {
            sb.appendLine("  How it got there:")
            sb.appendLine("  $narration")
            sb.appendLine()
        }

        val definition = result.structuredAnswer["definition"]
        if (!definition.isNullOrBlank()) {
            sb.appendLine("  Definition:")
            sb.appendLine("  $definition")
            sb.appendLine()
        }

        val stepsRaw = result.structuredAnswer["step_by_step"]
        if (!stepsRaw.isNullOrBlank()) {
            sb.appendLine("  Step-by-step:")
            sb.appendLine("  $stepsRaw")
            sb.appendLine()
        }

        val analogy = result.structuredAnswer["analogy"]
        if (!analogy.isNullOrBlank()) {
            sb.appendLine("  Analogy:")
            sb.appendLine("  $analogy")
            sb.appendLine()
        }

        sb.appendLine("  Final Answer:")
        sb.appendLine("  ${result.finalAnswer}")
        sb.appendLine()
        sb.appendLine("└─────────────────────────────────────────────────")
        sb.appendLine()

        // ── Full structured answer JSON ──
        if (result.structuredAnswer.isNotEmpty()) {
            sb.appendLine("┌─ STRUCTURED ANSWER (JSON) ──────────────────────")
            result.structuredAnswer.forEach { (k, v) ->
                sb.appendLine("  \u0022$k\u0022: $v")
            }
            sb.appendLine("└─────────────────────────────────────────────────")
            sb.appendLine()
        }

        // ── Memory snapshot ──
        if (result.memorySnapshot.isNotEmpty()) {
            sb.appendLine("┌─ MEMORY SNAPSHOT (${result.memorySnapshot.size} nodes) ─────────────────")
            result.memorySnapshot.forEach { node ->
                sb.appendLine("  [${node.nodeType}] ${node.label} (conf=${"%.2f".format(node.confidence)}, imp=${"%.2f".format(node.importance)})")
                sb.appendLine("    ${node.content.take(120)}")
            }
            sb.appendLine("└─────────────────────────────────────────────────")
            sb.appendLine()
        }
    } else {
        sb.appendLine("[Session still in progress — no final result yet]")
        sb.appendLine()
    }

    sb.appendLine(separator)
    sb.appendLine("  END OF SESSION DUMP")
    sb.appendLine(separator)

    return sb.toString()
}


/**
 * Strips prompt instruction echoes from the model's raw output.
 * Small models (1.5B-7B) often echo formatting instructions back:
 * "Do not output anything else.", "===JSON===", "Output ONLY the JSON...", etc.
 * These are not reasoning — they're prompt contamination. Filter them before
 * the text enters the thinking stream so the user sees actual reasoning.
 */
private fun stripPromptEchoes(raw: String): String {
    var cleaned = raw
    // Remove ===JSON=== markers
    cleaned = cleaned.replace(Regex("===JSON==="), "")
    // Remove common prompt instruction echoes
    cleaned = cleaned.replace(Regex("(?i)do not [aA]dd any other.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)do not output anything else.*?"), "")
    cleaned = cleaned.replace(Regex("(?i)output ONLY the JSON.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)you may reason freely.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)when you have reached your answer.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)everything before ===JSON===.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)everything from ===JSON=== onward.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)that thinking is valuable.*?\\."), "")
    cleaned = cleaned.replace(Regex("(?i)write the line ===JSON===.*?\\."), "")
    // Remove multiple blank lines
    cleaned = cleaned.replace(Regex("\n{3,}"), "\n\n")
    return cleaned.trim()
}

@Composable
fun CognitivePanel(
    engine: InferenceEngine,
    enabled: Boolean,
    maxTokens: Int,
    onStatus: (String) -> Unit,
    onError: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = AppScopes.main
    val clipboard = LocalClipboardManager.current

    // Log when this composable enters composition (helps diagnose tab-switch freezes)
    LaunchedEffect(Unit) { AppLog.logUi("CognitivePanel", "Entered composition") }

    var query by remember { mutableStateOf("") }
    var isRunning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CognitiveResult?>(null) }
    var rawTrace by remember { mutableStateOf("") }
    var cumulativeThinking by remember { mutableStateOf("") }

    // FIX (architecture blueprint Part 5.0): engine.sendUserPrompt() appends to the
    // shared native context on every call and never resets it -- across a 20-iteration
    // reason() loop, the native context (default 2048 tokens) fills up within the
    // first ~3 iterations, after which automatic context-shifting silently evicts
    // earlier iterations from the model's attention. NativeRecursiveRefiner's
    // beginSession()/generateGrounded() resets the context to a fixed checkpoint
    // before every call instead, so the loop stays bounded no matter how many
    // iterations run. generateGrounded() is the schema-free counterpart to
    // refineOnce() -- it does NOT force the Refiner's fixed JSON grammar, so each
    // operator's own JSON shape (DECOMPOSE's chunks array, VERIFY's confidence
    // float, etc.) is unaffected.
    //
    // Trade-off, by design: beginSession()/resetSession() clear the ENTIRE shared
    // llama.cpp context (there's only one), so the Chat tab's system-prompt framing
    // will be gone if you switch back to it after running the Cognitive engine.
    // That's a real cost of sharing one native context across tabs -- see Part 5.0
    // for the follow-up needed to close that gap (re-decoding the system prompt on
    // session end), not yet implemented here.
    val callModel: suspend (String, Int) -> String = { prompt, tokens ->
        // ALL native JNI calls (generateGrounded) MUST run on Dispatchers.IO.
        // Even though CognitiveEngine.reason() wraps itself in withContext(IO),
        // being explicit here guarantees it regardless of the calling context.
        withContext(Dispatchers.IO) {
            AppLog.logUi("CognitiveModel", "generateGrounded call starting, promptChars=${prompt.length}")
            val result = NativeRecursiveRefiner.generateGrounded(
                prompt = prompt,
                maxTokens = tokens,
                temperature = 0.4f,
                topK = 40,
                topP = 0.9f,
                minP = 0.05f,
                repeatPenalty = 1.1f
            )
            AppLog.logUi("CognitiveModel", "generateGrounded returned, resultChars=${result.length}")
            result
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, Stroke),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Cognitive Engine", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Systematic, human-brain-like reasoning: orient, decompose, analogize, verify, integrate, and learn.", color = TextMuted)

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Enter a complex question or topic") },
                minLines = 3
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    enabled = enabled && query.isNotBlank() && !isRunning,
                    onClick = {
                        scope.launch {
                            isRunning = true
                            result = null
                            rawTrace = ""
                            cumulativeThinking = ""
                            onStatus("Cognitive engine reasoning...")
                            try {
                                // Reset observatory for new cognitive session
                                ObservatoriumSession.resetForNewIteration(0)

                                // Bounded-context fix: ground the native session on a short,
                                // fixed framing + the user's question, NOT the evolving
                                // WorkingMemory. All native JNI calls (beginSession, generateGrounded,
                                // resetSession) MUST run on Dispatchers.IO, not the main thread.
                                // The previous code called beginSession directly on AppScopes.main
                                // (Dispatchers.Main.immediate), which is a blocking JNI call that
                                // froze the entire UI for seconds — exactly the "app becomes not
                                // responding" ANR the user reported.
                                withContext(Dispatchers.IO) {
                                    NativeRecursiveRefiner.setStrictKvMode(false)
                                }
                                val grounding = "You are a careful, systematic reasoner. " +
                                    "The question you are working through is:\n$query"
                                val sessionResult = withContext(Dispatchers.IO) {
                                    NativeRecursiveRefiner.beginSession(grounding)
                                }
                                if (sessionResult != 0) {
                                    onError("Could not start cognitive session (is a model loaded?)")
                                    onStatus("Cognitive engine failed.")
                                    return@launch
                                }

                                val cognitiveEngine = CognitiveEngine(context, callModel, onDiag = { diag -> ObservatoriumSession.updateStage(diag) })
                                // Launch a polling job that reads the native progress text
                                // and updates the observatory, so the user sees live generation.
                                // This runs on the Main thread (reading atomic C++ state is fast).
                                val pollJob = scope.launch {
                                    var lastSeenForThisCall = ""
                                    while (isActive) {
                                        val progressText = NativeRecursiveRefiner.getProgressText()
                                        if (progressText.isNotBlank()) {
                                            // getProgressText() only reflects the current/just-finished
                                            // call -- it resets (shrinks, or stops being an extension of
                                            // what we last saw) when a NEW operator call starts. When
                                            // that happens, snapshot the previous call's final text into
                                            // the cumulative log before continuing, so nothing the model
                                            // generated across the whole session is lost from view.
                                            val isNewCall = !progressText.startsWith(lastSeenForThisCall) || progressText.length < lastSeenForThisCall.length
                                            if (isNewCall && lastSeenForThisCall.isNotBlank()) {
                                                val cleaned = stripPromptEchoes(lastSeenForThisCall)
                                                if (cleaned.isNotBlank()) {
                                                    cumulativeThinking = if (cumulativeThinking.isBlank()) cleaned
                                                        else "$cumulativeThinking\n\n$cleaned"
                                                }
                                            }
                                            lastSeenForThisCall = progressText
                                            // Strip prompt echoes before displaying to user
                                            val cleanedStream = stripPromptEchoes(
                                                if (cumulativeThinking.isBlank()) progressText
                                                else "$cumulativeThinking\n\n$progressText"
                                            )
                                            ObservatoriumSession.liveTokenStream = cleanedStream
                                        }
                                        delay(150)
                                    }
                                }
                                val res = try {
                                    cognitiveEngine.reason(query)
                                } finally {
                                    pollJob.cancel()
                                }
                                result = res
                                rawTrace = res.trace.joinToString("\n")
                                onStatus("Cognitive reasoning complete. Confidence: ${"%.0f".format(res.confidence * 100)}%")
                            } catch (t: Throwable) {
                                AppLog.appendError("Cognitive engine failed", t)
                                onError(t.message ?: t.toString())
                                onStatus("Cognitive engine failed.")
                            } finally {
                                runCatching { withContext(Dispatchers.IO) { NativeRecursiveRefiner.resetSession() } }
                                isRunning = false
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Think")
                }
                if (isRunning) CircularProgressIndicator(modifier = Modifier.height(24.dp), color = Accent, strokeWidth = 2.dp)
            }

            // ── Live "Thinking…" — raw, unfiltered, exactly as the model generates it.
            // Shown whenever there's anything to show: during generation (isRunning) and
            // also after completion (so the full session's thinking stays inspectable,
            // just no longer breathing/pulsing since nothing is active anymore).
            if (isRunning || cumulativeThinking.isNotBlank()) {
                BreathingThinkingPanel(
                    isActive = isRunning,
                    liveText = ObservatoriumSession.liveTokenStream,
                    startExpanded = isRunning
                )
            }

            // ── Copy Full Session — captures everything, even while still running ──
            if (isRunning || cumulativeThinking.isNotBlank() || result != null) {
                val liveCopyClipboard = clipboard
                val liveQuery = query
                val liveCumulativeThinking = cumulativeThinking
                val liveResult = result
                val liveRawTrace = rawTrace
                TextButton(
                    onClick = {
                        val dump = buildFullSessionDump(
                            query = liveQuery,
                            cumulativeThinking = liveCumulativeThinking,
                            liveTokenStream = ObservatoriumSession.liveTokenStream,
                            rawTrace = liveRawTrace,
                            result = liveResult,
                            stageMap = ObservatoriumSession.stageMap.toMap()
                        )
                        liveCopyClipboard.setText(AnnotatedString(dump))
                        AppLog.logUi("CognitivePanel", "Full session copied (${dump.length} chars)")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isRunning) "Copy Full Session (live)" else "Copy Full Session",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Accent
                    )
                }
            }

            // ── Pipeline Observatory — the 9-stage technical view ──────────────
            LiveObservatoryPanel(
                iterationNumber = ObservatoriumSession.currentIterationNumber,
                stageMap = ObservatoriumSession.stageMap,
                liveTokenStream = ObservatoriumSession.liveTokenStream
            )

            result?.let { res ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel2),
                    border = BorderStroke(1.dp, Stroke),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

                        // ── Reasoning trace, cleaned, ABOVE the final answer ──────
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("How it got there", color = TextMuted, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(rawTrace)) }) { Text("Copy trace", fontSize = 12.sp) }
                        }
                        val narration = res.structuredAnswer["how_i_got_here"]
                        if (!narration.isNullOrBlank()) {
                            Text(narration, color = TextMuted, fontSize = 13.sp)
                        }
                        Text(
                            text = rawTrace,
                            color = TextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 160.dp)
                                .verticalScroll(rememberScrollState())
                        )

                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Stroke))

                        // ── Final answer, BELOW the trace, properly structured ────
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Final Answer", color = TextMain, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { clipboard.setText(AnnotatedString(res.finalAnswer)) }) { Text("Copy") }
                        }

                        val definition = res.structuredAnswer["definition"]
                        if (!definition.isNullOrBlank()) {
                            LatexAwareText(definition, color = TextMain)
                        }

                        val stepsRaw = res.structuredAnswer["step_by_step"]
                        val steps = stepsRaw?.let { ReasoningOperators.parseJsonArray(ReasoningOperators.extractJson(it)) } ?: emptyList()
                        steps.forEachIndexed { i, step ->
                            Text(
                                step["heading"] ?: "Step ${i + 1}",
                                color = TextMain,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            LatexAwareText(step["body"] ?: "", color = TextMain)
                        }

                        // Fallback: if structured fields didn't come through for some
                        // reason, show the flat formatted answer rather than nothing.
                        if (definition.isNullOrBlank() && steps.isEmpty()) {
                            LatexAwareText(res.finalAnswer, color = TextMain)
                        }

                        val analogy = res.structuredAnswer["analogy"]
                        if (!analogy.isNullOrBlank()) {
                            Text("Analogy", color = TextMuted, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            LatexAwareText(analogy, color = TextMuted)
                        }

                        Text("Confidence: ${"%.0f".format(res.confidence * 100)}%", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}