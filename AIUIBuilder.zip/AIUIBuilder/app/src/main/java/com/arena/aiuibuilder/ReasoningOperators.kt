package com.arena.aiuibuilder

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray

/**
 * Reasoning Operators — the atomic actions of the cognitive engine.
 *
 * Each operator builds a tight, structured prompt, calls the LLM once,
 * and parses the result into a structured OperatorResult.
 */

@Serializable
data class OperatorResult(
    val operator: String,
    val output: String,
    val structured: Map<String, String> = emptyMap(),
    val confidence: Float = 0.75f,
    val surprise: Float = 0.0f,
    val subgoals: List<String> = emptyList()
)

object ReasoningOperators {

    private val json = Json { ignoreUnknownKeys = true }

    // -----------------------------------------------------------------------
    // 1. ORIENT — parse the problem, extract unknowns, detect confusion
    // -----------------------------------------------------------------------
    fun buildOrientPrompt(query: String, relevantMemory: String): String = """
        |You are MESA, a systematic reasoning engine. Read the following question carefully.
        |
        |QUESTION: $query
        |
        |RELEVANT PRIOR KNOWLEDGE:
        |$relevantMemory
        |
        |Task: produce a JSON object with exactly these fields:
        |  "topic": the main topic in 3-6 words
        |  "unknowns": list of 1-3 specific things we need to figure out
        |  "confusion_level": "low" | "medium" | "high"
        |  "needed_knowledge": list of 1-3 concepts we should verify we understand
        |  "next_operator": "DECOMPOSE" | "FIRST_PRINCIPLES" | "RETRIEVE" | "ANALOGIZE"
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 2. DECOMPOSE — break complex problem into chunks
    // -----------------------------------------------------------------------
    fun buildDecomposePrompt(query: String, orientation: OperatorResult): String = """
        |You are MESA. Break the following question into 3-5 small, independent sub-problems.
        |
        |QUESTION: $query
        |TOPIC: ${orientation.structured["topic"] ?: "unknown"}
        |UNKNOWNS: ${orientation.structured["unknowns"] ?: ""}
        |
        |Rules:
        |  - Each sub-problem should be solvable in one short step.
        |  - Sub-problems should not overlap.
        |  - Order them logically (what must be solved first).
        |
        |Output ONLY a JSON array of objects with fields:
        |  "id": "c1", "c2", ...
        |  "question": the sub-question text
        |  "operator_hint": "SOLVE_CHUNK" | "VERIFY" | "EXECUTE"
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 3. FIRST_PRINCIPLES — reduce to foundational causes
    // -----------------------------------------------------------------------
    fun buildFirstPrinciplesPrompt(query: String): String = """
        |You are MESA. The user is lost on a complex topic. Help them ground it from first principles.
        |
        |TOPIC: $query
        |
        |Task: produce a JSON object with exactly these fields:
        |  "base_problem": what fundamental problem this topic was invented to solve
        |  "causal_chain": 2-4 sentences walking backward from the topic to its root cause
        |  "simplest_case": a concrete minimal example or base case
        |  "core_principle": one sentence summarizing the invariant/law/pattern involved
        |  "rebuild_step": the first small step toward reconstructing the topic from the base case
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 4. ANALOGIZE — cross-domain structure mapping
    // -----------------------------------------------------------------------
    fun buildAnalogizePrompt(query: String, sourceDomain: String, targetDomain: String): String = """
        |You are MESA. Find a useful analogy between two domains to understand the topic.
        |
        |TOPIC: $query
        |SOURCE DOMAIN: $sourceDomain
        |TARGET DOMAIN: $targetDomain
        |
        |Task: produce a JSON object with exactly these fields:
        |  "source_concept": concept in source domain
        |  "target_concept": analogous concept in target domain
        |  "mapping": list of 2-4 specific component mappings (e.g., "X in source is like Y in target")
        |  "insight": one sentence explaining what the analogy reveals about the topic
        |  "limit": one sentence explaining where the analogy breaks down
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 5. SOLVE_CHUNK — solve one small sub-problem
    // -----------------------------------------------------------------------
    fun buildSolveChunkPrompt(
        chunkQuestion: String,
        priorChunks: String,
        memory: String,
        constraints: List<String> = emptyList()
    ): String = buildString {
        appendLine("You are MESA, a scientific researcher. ANSWER the specific sub-problem below.")
        appendLine()
        appendLine("SUB-PROBLEM: $chunkQuestion")
        appendLine()

        // Constraints go FIRST and are marked as BINDING — can't be ignored.
        if (constraints.isNotEmpty()) {
            appendLine("⚡ BINDING CONSTRAINTS (your answer MUST respect all of these):")
            constraints.forEach { appendLine("  • $it") }
            appendLine()
        }

        if (priorChunks.isNotBlank() && priorChunks != "No prior chunks.") {
            appendLine("PRIOR DISCOVERIES (build directly on these):")
            appendLine(priorChunks)
            appendLine()
        }

        appendLine("YOUR MEMORY:")
        appendLine(memory)
        appendLine()
        appendLine("RULES:")
        appendLine("1. Give a concrete ANSWER. No more questions.")
        appendLine("2. Explicitly state how your answer follows from the binding constraints above.")
        appendLine("3. State any NEW constraints your answer creates for future steps.")
        appendLine()
        appendLine("""Output a JSON object with fields: "answer", "confidence" (high/medium/low),
            "new_constraints" (array of strings — new constraints for next steps),
            "falsifiable_claim" (one testable prediction)""".trimIndent())
    }

    // -----------------------------------------------------------------------
    // 6. VERIFY — internal consistency + external reality check prompt
    // -----------------------------------------------------------------------
    fun buildVerifyPrompt(claim: String, evidence: String): String = """
        |You are MESA. Verify the following claim against available evidence.
        |
        |CLAIM: $claim
        |
        |EVIDENCE / SEARCH RESULTS:
        |$evidence
        |
        |Task: produce a JSON object with exactly these fields:
        |  "verdict": "SUPPORTED" | "PARTIALLY_SUPPORTED" | "CONTRADICTED" | "UNCERTAIN"
        |  "objection": strongest objection if any (max 120 chars)
        |  "confidence": 0.0 to 1.0
        |  "suggested_operator": "EXECUTE" | "SEARCH" | "SOLVE_CHUNK" | "INTEGRATE"
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 7. EXECUTE — generate code to test a claim
    // -----------------------------------------------------------------------
    fun buildExecutePrompt(claim: String): String = """
        |You are MESA. Generate a tiny JavaScript snippet that tests this claim numerically or logically.
        |
        |CLAIM: $claim
        |
        |Rules:
        |  - Use only basic JS (no external libraries, no fetch, no DOM).
        |  - The script must return a single string or number result.
        |  - Keep it under 10 lines.
        |
        |Output ONLY the raw JavaScript code, nothing else.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 8. INTEGRATE — synthesize sub-problem answers into final answer
    // -----------------------------------------------------------------------
    fun buildIntegratePrompt(query: String, chunks: String, originalGoal: String, reasoningPath: String): String = """
        |You are MESA. Synthesize the following solved sub-problems into a complete final answer.
        |
        |ORIGINAL QUESTION: $query
        |
        |SOLVED SUB-PROBLEMS:
        |$chunks
        |
        |THE PATH YOU TOOK TO GET HERE (your own prior reasoning steps, in order):
        |$reasoningPath
        |
        |Write the final answer to actually teach the answer, not just gesture at it. Structure
        |matters: lead with a clear, complete, textbook-quality DEFINITION or explanation of the
        |core idea -- analogies and examples come AFTER the definition, as support, never as the
        |opening line. If the question warrants real depth (e.g. "how do I build X" or "explain Y
        |in detail"), the answer should be genuinely long and thorough, not a short paraphrase --
        |a one-paragraph answer to a request for deep understanding is a failure, not concision.
        |
        |Task: produce a JSON object with exactly these fields:
        |  "how_i_got_here": narrate the actual reasoning path above in plain language, as a short
        |    story of the questions you asked yourself and what each one revealed (e.g. "First I
        |    asked what a neuron actually does at the membrane level. That led me to ask whether
        |    transistors can reproduce that behavior, which raised..."). 2-5 sentences.
        |  "definition": a clear, complete, precise explanation of the core idea, in your own
        |    words, BEFORE any analogy. This is the foundation the rest of the answer builds on.
        |  "step_by_step": a JSON array of objects, each {"heading": "short heading", "body": "the
        |    explanation for this step"}. Break the full answer into as many steps as the topic
        |    actually needs -- a simple question might need 2-3, a request like "how do I build an
        |    artificial neuron on hardware" needs enough steps to actually be buildable from, not
        |    a token gesture at the idea.
        |  "analogy": one supporting analogy that reinforces the definition above (not a
        |    replacement for it).
        |  "key_insight": the single most important takeaway (1 sentence).
        |  "confidence": 0.0 to 1.0
        |  "importance": 0.0 to 1.0 -- how important is this integrated answer for future recall?
        |  "remaining_uncertainty": one remaining uncertainty or empty string
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 9. REFLECT — metacognitive pause
    // -----------------------------------------------------------------------
    fun buildReflectPrompt(query: String, history: String): String = """
        |You are MESA. You have been working on this problem and may be stuck. Reflect.
        |
        |QUESTION: $query
        |
        |RECENT HISTORY:
        |$history
        |
        |Task: produce a JSON object with exactly these fields:
        |  "diagnosis": why we are stuck (max 120 chars)
        |  "best_next_action": "DECOMPOSE" | "FIRST_PRINCIPLES" | "ANALOGIZE" | "VERIFY" | "STOP"
        |  "new_angle": one concrete, different angle to try (max 120 chars)
        |  "importance": 0.0 to 1.0 — how important is this reflection insight for future recall?
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // 10. CURIOSITY — generate alternative explanations
    // -----------------------------------------------------------------------
    fun buildCuriosityPrompt(belief: String, currentExplanation: String, query: String): String = """
        |You are MESA. You have a current belief about a topic. Now think creatively.
        |
        |TOPIC: $query
        |CURRENT BELIEF: $belief
        |CURRENT EXPLANATION: $currentExplanation
        |
        |Task: Generate 2-3 ALTERNATIVE explanations or hypotheses that could also explain
        |the same phenomenon. Think like a scientist who challenges their own assumptions.
        |
        |For each alternative:
        |1. State the alternative clearly
        |2. Explain why it might be better than the current belief
        |3. Identify what evidence would support or refute it
        |
        |produce a JSON object with exactly these fields:
        |  "alternatives": a JSON array of objects, each with:
        |    "hypothesis": the alternative explanation (1-2 sentences)
        |    "why_better": why this might be more correct (1 sentence)
        |    "test": what evidence would confirm or deny it
        |  "best_alternative": the index (0-based) of the most promising alternative
        |  "curiosity_score": 0.0 to 1.0 — how much information gain exploring this would provide
        |Output ONLY the JSON object.
    """.trimMargin()

    // -----------------------------------------------------------------------
    // Parsing helpers — fixed to handle non-string JSON values (blueprint 1.4)
    // Previously forced Map<String, String>, which threw SerializationException
    // on bare numbers/booleans like "confidence": 0.85 or "needs_code_test": true,
    // silently discarding the entire object. Now parses into a JsonElement tree
    // and stringifies each leaf regardless of its underlying type.
    // -----------------------------------------------------------------------
    fun parseJsonObject(raw: String): Map<String, String> {
        // Attempt 1: strict parse.
        try {
            return json.parseToJsonElement(raw)
                .jsonObject.mapValues { (_, v) -> jsonElementToPlainString(v) }
        } catch (_: Exception) { /* fall through */ }

        // Attempt 2: repair missing commas between adjacent JSON fields.
        // Covers: {"a":"b""c":"d"} → {"a":"b","c":"d"}
        val repaired1 = raw
            .replace(Regex("\"\s*\n(\s*)\"")) { "\",\n${it.groupValues[1]}\"" }
            .replace(Regex("(true|false|null|\d)\s*\n(\s*)\"")) { "${it.groupValues[1]},\n${it.groupValues[2]}\"" }
            .replace(Regex("(true|false|null|\d)\s*\}")) { "${it.groupValues[1]}\n}" }
        try {
            return json.parseToJsonElement(repaired1)
                .jsonObject.mapValues { (_, v) -> jsonElementToPlainString(v) }
        } catch (_: Exception) { /* fall through */ }

        // Attempt 3: regex key-value extraction as last resort.
        val result = mutableMapOf<String, String>()
        val stringFieldPattern = Regex("\"([^\"]+)\"\s*:\s*\"([^\"]*?)\"")
        val numBoolFieldPattern = Regex("\"([^\"]+)\"\s*:\s*(true|false|[0-9.]+)")
        stringFieldPattern.findAll(raw).forEach { m ->
            result[m.groupValues[1]] = m.groupValues[2]
        }
        numBoolFieldPattern.findAll(raw).forEach { m ->
            if (!result.containsKey(m.groupValues[1])) {
                result[m.groupValues[1]] = m.groupValues[2]
            }
        }
        return result
    }

    /**
     * v9 FIX: hardened to handle the common 1B-model habit of wrapping the requested
     * array in a named object key, e.g. {"sub_problems": [...]} instead of [...].
     * Small models frequently do this despite explicit "output ONLY a JSON array"
     * instructions (a habit from tool-calling training data where arguments are always
     * wrapped in an object).
     *
     * Attempt 1: raw is already a bare array — the happy path.
     * Attempt 2: raw is an object whose first array-valued field contains the items.
     * Both use the lenient JsonElement API, so partial/non-standard JSON is tolerated.
     */
    fun parseJsonArray(raw: String): List<Map<String, String>> {
        // Attempt 1: bare array
        try {
            return json.parseToJsonElement(raw).jsonArray.map { item ->
                item.jsonObject.mapValues { (_, v) -> jsonElementToPlainString(v) }
            }
        } catch (_: Exception) { /* fall through */ }

        // Attempt 2: object wrapping a single array field
        try {
            val obj = json.parseToJsonElement(raw).jsonObject
            val arrayField = obj.values.firstOrNull { it is JsonArray } as? JsonArray
            if (arrayField != null) {
                return arrayField.map { item ->
                    item.jsonObject.mapValues { (_, v) -> jsonElementToPlainString(v) }
                }
            }
        } catch (_: Exception) { /* fall through */ }

        return emptyList()
    }

    private fun jsonElementToPlainString(element: JsonElement): String =
        (element as? JsonPrimitive)?.content ?: element.toString()

    /**
     * Extract the JSON object/array from a response that's expected to contain
     * free-form reasoning BEFORE the JSON (see CognitiveEngine.buildPrompt's
     * "think freely, then ===JSON===" instruction). Looks for that marker first;
     * if present, only searches after it. Either way, chooses the FIRST balanced
     * top-level JSON structure after the marker. This is important for DECOMPOSE:
     * array output must stay an array even though it contains object elements.
     */
    /**
     * v9 FIX: multi-candidate quality scoring instead of "always take the first structure".
     *
     * 1B models often emit an empty draft template first, then write "Predicted output:"
     * followed by the real answer. Taking the first structure grabs the empty draft every
     * time, producing blank topic/confusion_level/etc. in ORIENT's results.
     *
     * This function finds every balanced top-level JSON block in the text and scores each
     * by how many non-empty fields it has. The highest-scoring candidate wins. On ties the
     * later occurrence wins (the model's last attempt is usually the considered one).
     */
    fun extractJson(raw: String): String {
        val marker = "===JSON==="
        val markerIdx = raw.indexOf(marker)
        val searchSpace = if (markerIdx >= 0) raw.substring(markerIdx + marker.length).trim() else raw

        val candidates = findAllJsonCandidates(searchSpace)
        if (candidates.isEmpty()) return searchSpace

        return candidates
            .withIndex()
            .maxWithOrNull(compareBy(
                { (_, c) -> scoreJsonCandidate(c.second) },   // primary: populated-ness
                { (i, _) -> i }                                 // tiebreak: prefer later
            ))
            ?.value?.second ?: candidates.last().second
    }

    /** Returns every top-level balanced JSON object or array found in [text]. */
    private fun findAllJsonCandidates(text: String): List<Pair<Char, String>> {
        val results = mutableListOf<Pair<Char, String>>()
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '{' || c == '[') {
                val close = if (c == '{') '}' else ']'
                val block = extractBalancedFromStart(text, i, c, close)
                if (block != null) {
                    results.add(c to block)
                    i += block.length
                    continue
                }
            }
            i++
        }
        return results
    }

    /**
     * Score a JSON candidate: higher = more likely to be the real answer, not a draft.
     * Counts non-empty string and array field values; penalises obvious empty placeholders.
     */
    private fun scoreJsonCandidate(text: String): Int {
        var score = 0
        // Non-empty string values: "key": "something"
        Regex(""""[^"]*"\s*:\s*"([^"]+)"""").findAll(text).forEach {
            if (it.groupValues[1].isNotBlank()) score += 2
        }
        // Non-empty array values: "key": [ ... ]
        Regex(""""[^"]*"\s*:\s*\[([^\]]+)\]""").findAll(text).forEach {
            if (it.groupValues[1].isNotBlank()) score += 2
        }
        // Penalise empty placeholders
        score -= Regex(""""[^"]*"\s*:\s*"\s*"""").findAll(text).count()
        score -= Regex(""""[^"]*"\s*:\s*\[\s*\]""").findAll(text).count()
        return score
    }

    private fun extractBalancedFromStart(text: String, startIdx: Int, open: Char, close: Char): String? {
        var depth = 0
        var inString = false
        var escape = false
        for (i in startIdx until text.length) {
            val c = text[i]
            if (escape) { escape = false; continue }
            if (c == '\\' && inString) { escape = true; continue }
            if (c == '"') { inString = !inString; continue }
            if (inString) continue
            when (c) {
                open -> depth++
                close -> {
                    depth--
                    if (depth == 0) return text.substring(startIdx, i + 1)
                }
            }
        }
        return null
    }

    /** Scans backward from the last [close] char to find the start of the last balanced top-level block. */
    private fun extractBalancedFromEnd(text: String, open: Char, close: Char): String? {
        val lastClose = text.lastIndexOf(close)
        if (lastClose < 0) return null
        var depth = 0
        for (i in lastClose downTo 0) {
            when (text[i]) {
                close -> depth++
                open -> {
                    depth--
                    if (depth == 0) return text.substring(i, lastClose + 1)
                }
            }
        }
        return null
    }

    /**
     * Simple regex salvage for critical fields when JSON is malformed.
     */
    fun salvageField(raw: String, key: String): String? {
        val pattern = Regex(""""$key"\s*:\s*"([^"]+)"""")
        return pattern.find(raw)?.groupValues?.get(1)
    }

    // -----------------------------------------------------------------------
    // Code execution helpers
    // These forward to CodeExecutionEngine to keep a single source of truth,
    // while preserving the ReasoningOperators.wrapTestCode API that
    // CognitiveEngine.kt expects (fixes Unresolved reference).
    // -----------------------------------------------------------------------

    /**
     * Wrap generated JavaScript code for safe execution in the WebView sandbox.
     */
    fun wrapTestCode(generatedCode: String): String =
        CodeExecutionEngine.wrapTestCode(generatedCode)

    /**
     * Generate a simple arithmetic test script for a claim like "2+2=4".
     */
    fun generateArithmeticTest(claim: String): String? =
        CodeExecutionEngine.generateArithmeticTest(claim)
}
