package com.arena.aiuibuilder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.install(applicationContext)
        setContent { AiWorkbenchApp() }
    }
}

object NativeTuning {
    init {
        runCatching { System.loadLibrary("ai-chat") }
    }
    external fun setOptions(threads: Int, contextSize: Int, batchSize: Int, temperature: Float)
}

private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

private const val UI_JSON_SYSTEM_PROMPT = """
You are an offline Android UI generator.
Return ONLY one valid JSON object. No markdown. No explanation. No code fences. No <think>.
Allowed schema:
{
  "title": "screen title",
  "elements": [
    {"type":"heading|text|input|button|checkbox|card|spacer", "id":"optional", "text":"optional", "hint":"optional", "checked":false, "children":[]}
  ]
}
Rules:
- Use only the allowed element types.
- Keep IDs lowercase and simple.
- Keep output compact.
"""

private fun getUniversalSystemPrompt(): String {
    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
    return """
You are AIUIBuilder Studio Agent, an advanced local AI intelligence running on Android.
Current Date: $today.
IMPORTANT HOST OVERRIDE: Unlike standard offline models, you DO have live internet search and real-time grounding provided by the Android host application. Never refuse a query by claiming you lack real-time data, internet access, or have a training knowledge cutoff.
When web search results are provided in your prompt context, treat them as absolute verified real-world facts and answer directly.
For normal chat, be direct, helpful, and natural.
For builder tasks, return clean valid code artifacts.
""".trimIndent()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiWorkbenchApp() {
    val vm: AppSessionViewModel = viewModel()

    val selectedMode by vm.selectedMode.collectAsState()
    val isBusy by vm.isBusy.collectAsState()
    val statusText by vm.statusText.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    val selectedModelName by vm.selectedModelName.collectAsState()
    val copiedModelPath by vm.copiedModelPath.collectAsState()
    val errorText by vm.errorText.collectAsState()
    val chatMessages by vm.chatMessages.collectAsState()
    val chatInput by vm.chatInput.collectAsState()
    val chatWebSearch by vm.chatWebSearch.collectAsState()

    val threads by vm.threads.collectAsState()
    val contextSize by vm.contextSize.collectAsState()
    val batchSize by vm.batchSize.collectAsState()
    val temperature by vm.temperature.collectAsState()
    val maxTokens by vm.maxTokens.collectAsState()
    val refinePasses by vm.refinePasses.collectAsState()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { AiChat.getInferenceEngine(context.applicationContext) }
    val engineState by engine.state.collectAsState()

    var showSettings by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                vm.selectedModelUri.value = uri
                vm.selectedModelName.value = context.displayName(uri) ?: "model.gguf"
                vm.statusText.value = "Selected ${vm.selectedModelName.value}. Tap Load model."
                vm.errorText.value = null
            }
        }
    )

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = ObsColors.BgDeep,
            surface = ObsColors.BgPanel,
            primary = ObsColors.AccentCyan,
            onBackground = ObsColors.TextPrime,
            onSurface = ObsColors.TextPrime
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = ObsColors.BgDeep) {
            Scaffold(
                containerColor = ObsColors.BgDeep,
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsColors.BgPanel),
                        title = {
                            Column {
                                Text(
                                    text = selectedModelName ?: "No model loaded",
                                    color = ObsColors.TextPrime,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                val stateLabel = when (engineState) {
                                    is InferenceEngine.State.ModelReady   -> "Ready"
                                    is InferenceEngine.State.Initialized  -> "Initialized"
                                    is InferenceEngine.State.Loading      -> "Loading..."
                                    is InferenceEngine.State.Error        -> "Error"
                                    else                                  -> "Not loaded"
                                }
                                Text(stateLabel, color = ObsColors.TextDim, fontSize = 10.sp)
                            }
                        },
                        actions = {
                            if (selectedModelName == null) {
                                TextButton(onClick = {
                                    if (!vm.isBusy.value) picker.launch(arrayOf("*/*"))
                                }) {
                                    Text("Pick Model", color = ObsColors.AccentCyan, fontSize = 12.sp)
                                }
                                TextButton(onClick = {
                                    val uri = vm.selectedModelUri.value ?: return@TextButton
                                    scope.launch {
                                        vm.isBusy.value = true
                                        vm.errorText.value = null
                                        try {
                                            vm.statusText.value = "Applying speed settings..."
                                            runCatching { NativeTuning.setOptions(threads, contextSize, batchSize, temperature) }

                                            vm.statusText.value = "Copying GGUF into app storage..."
                                            val modelFile = copyModelIntoAppStorage(context, uri)
                                            vm.copiedModelPath.value = modelFile.absolutePath

                                            vm.statusText.value = "Waiting for runtime..."
                                            waitUntilEngineInitialized(engine)

                                            vm.statusText.value = "Loading model. Keep app open."
                                            engine.loadModel(modelFile.absolutePath)
                                            engine.setSystemPrompt(getUniversalSystemPrompt())
                                            vm.statusText.value = "Model ready."
                                        } catch (t: Throwable) {
                                            AppLog.appendError("Model load failed", t)
                                            vm.errorText.value = t.message ?: t.toString()
                                            vm.statusText.value = "Model load failed."
                                        } finally {
                                            vm.isBusy.value = false
                                        }
                                    }
                                }) {
                                    Text("Load", color = ObsColors.AccentGreen, fontSize = 12.sp)
                                }
                            }
                            IconButton(onClick = { showSettings = true }) {
                                Text("⚙", color = ObsColors.TextMuted, fontSize = 18.sp)
                            }
                        }
                    )
                }
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    // Mode tabs
                    ModeTabRow(
                        selectedMode = selectedMode,
                        onSelect = { vm.selectedMode.value = it }
                    )

                    // Status bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ObsColors.BgPanel)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isBusy) CircularProgressIndicator(modifier = Modifier.size(14.dp), color = ObsColors.AccentCyan, strokeWidth = 2.dp)
                        Text(statusText, color = ObsColors.TextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        errorText?.let { Text("Error: $it", color = Color(0xFFF87171), fontSize = 11.sp) }
                    }

                    // Content
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        when (selectedMode) {
                            "chat"      -> ChatMainPanel(vm = vm, engine = engine)
                            "refiner"   -> RefinerMainPanelWrapper(vm = vm, engine = engine)
                            "cognitive" -> CognitivePanelWrapper(vm = vm, engine = engine)
                        }
                    }
                }
            }
        }

        if (showSettings) {
            SettingsSheet(vm = vm, onDismiss = { showSettings = false })
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Mode Tab Row
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ModeTabRow(selectedMode: String, onSelect: (String) -> Unit) {
    val modes = listOf("chat" to "Chat", "refiner" to "Refiner", "cognitive" to "Cognitive")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(ObsColors.BgPanel)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        modes.forEach { (key, label) ->
            val selected = selectedMode == key
            TextButton(
                onClick = { onSelect(key) },
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = label,
                    color = if (selected) ObsColors.TextPrime else ObsColors.TextDim,
                    fontSize = 13.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Light
                )
            }
        }
    }
    Row(modifier = Modifier.fillMaxWidth().height(1.dp)) {
        modes.forEach { (key, _) ->
            Box(modifier = Modifier.weight(1f).height(1.dp).background(
                if (key == selectedMode) ObsColors.AccentCyan else ObsColors.Border
            ))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Chat Panel
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ChatMainPanel(vm: AppSessionViewModel, engine: InferenceEngine) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val chatInput by vm.chatInput.collectAsState()
    val messages by vm.chatMessages.collectAsState()
    val isGenerating by vm.isGenerating.collectAsState()
    val webSearch by vm.chatWebSearch.collectAsState()
    val modelReady = engine.state.value is InferenceEngine.State.ModelReady
    val maxTokens by vm.maxTokens.collectAsState()

    var generationJob by remember { mutableStateOf<Job?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Message list
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().padding(top = 40.dp), contentAlignment = Alignment.Center) {
                    Text("Start a conversation", color = ObsColors.TextDim, fontSize = 14.sp)
                }
            }
            messages.forEach { msg -> MessageBubble(msg) }
        }

        // Web search toggle
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Web search", color = ObsColors.TextDim, fontSize = 11.sp)
            Switch(
                checked = webSearch,
                onCheckedChange = { vm.chatWebSearch.value = it },
                modifier = Modifier.height(20.dp),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ObsColors.AccentCyan,
                    checkedTrackColor = ObsColors.AccentCyan.copy(alpha = 0.3f)
                )
            )
        }

        // Input row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ObsColors.BgPanel)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = chatInput,
                onValueChange = { vm.chatInput.value = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message...", color = ObsColors.TextDim, fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ObsColors.BorderMid,
                    unfocusedBorderColor = ObsColors.Border,
                    focusedTextColor = ObsColors.TextPrime,
                    unfocusedTextColor = ObsColors.TextPrime,
                    cursorColor = ObsColors.AccentCyan
                ),
                maxLines = 5
            )

            // Send / Cancel morphing button
            AnimatedContent(
                targetState = isGenerating,
                transitionSpec = {
                    fadeIn(tween(150)) togetherWith fadeOut(tween(150))
                },
                label = "send-cancel"
            ) { generating ->
                IconButton(
                    onClick = {
                        if (generating) {
                            generationJob?.cancel()
                            generationJob = null
                            vm.isGenerating.value = false
                            AppLog.append("[USER CANCELLED GENERATION]")
                            vm.updateLastMessage { it.copy(isGenerating = false, text = it.text + " [cancelled]") }
                        } else {
                            val input = chatInput.trim()
                            if (input.isBlank() || !modelReady) return@IconButton
                            vm.chatInput.value = ""
                            vm.addMessage(ChatMessage("You", input))
                            vm.addMessage(ChatMessage("AI", "", isGenerating = true))
                            vm.isGenerating.value = true
                            generationJob = scope.launch {
                                try {
                                    val systemPrompt = getUniversalSystemPrompt()
                                    val prompt = "$systemPrompt\n\nUser: $input\nAssistant:"
                                    val sb = StringBuilder()
                                    engine.sendUserPrompt(prompt, maxTokens).collect { token ->
                                        sb.append(token)
                                        vm.updateLastMessage { it.copy(text = sb.toString()) }
                                    }
                                } catch (e: kotlinx.coroutines.CancellationException) {
                                    AppLog.append("[USER CANCELLED GENERATION]")
                                } catch (t: Throwable) {
                                    AppLog.appendError("Chat generation failed", t)
                                    vm.updateLastMessage { it.copy(text = "[Error: ${t.message}]", isGenerating = false) }
                                } finally {
                                    vm.isGenerating.value = false
                                    vm.updateLastMessage { it.copy(isGenerating = false) }
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            if (generating) ObsColors.AccentRed.copy(alpha = 0.12f) else ObsColors.BgCard,
                            shape = RoundedCornerShape(10.dp)
                        )
                ) {
                    Text(
                        text = if (generating) "■" else "↑",
                        color = if (generating) ObsColors.AccentRed else ObsColors.TextPrime,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
private fun OutlinedTextFieldDefaults.colors(
    focusedBorderColor: Color,
    unfocusedBorderColor: Color,
    focusedTextColor: Color,
    unfocusedTextColor: Color,
    cursorColor: Color
) = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
    focusedBorderColor = focusedBorderColor,
    unfocusedBorderColor = unfocusedBorderColor,
    focusedTextColor = focusedTextColor,
    unfocusedTextColor = unfocusedTextColor,
    cursorColor = cursorColor
)

@Composable
private fun IconButton(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    androidx.compose.foundation.clickable(onClick = onClick, modifier = modifier, enabled = true, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null, content = content)
}

// ─────────────────────────────────────────────────────────────────────────────
// Refiner Panel Wrapper
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RefinerMainPanelWrapper(vm: AppSessionViewModel, engine: InferenceEngine) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        RecursiveRefinerPanel(
            modelReady = engine.state.value is InferenceEngine.State.ModelReady,
            onStatus = { vm.statusText.value = it },
            onError = { vm.errorText.value = it }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Cognitive Panel Wrapper
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CognitivePanelWrapper(vm: AppSessionViewModel, engine: InferenceEngine) {
    val maxTokens by vm.maxTokens.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        CognitivePanel(
            engine = engine,
            enabled = !vm.isBusy.value && engine.state.value is InferenceEngine.State.ModelReady,
            maxTokens = maxTokens,
            onStatus = { vm.statusText.value = it },
            onError = { vm.errorText.value = it ?: "" }
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Message Bubble
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun MessageBubble(msg: ChatMessage) {
    val user = msg.role == "You"
    val clipboard = LocalClipboardManager.current
    val (thinking, visibleText) = splitThinking(msg.text)
    val isAnimating = msg.isGenerating && !isReasoningComplete(msg.text)
    Box(modifier = Modifier.fillMaxWidth()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = if (user) Color(0xFF312E81) else ObsColors.BgPanel),
            modifier = Modifier
                .align(if (user) Alignment.CenterEnd else Alignment.CenterStart)
                .widthIn(max = 520.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(msg.role, color = if (user) Color(0xFFC4B5FD) else Color(0xFF86EFAC), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { clipboard.setText(AnnotatedString(msg.text)) }) { Text("Copy") }
                }
                if (msg.searchProcess != null) {
                    SearchLiveFeedbackBlock(msg.searchProcess, msg.isGenerating)
                }
                if (thinking != null) ThinkingBlock(thinking, isAnimating) { clipboard.setText(AnnotatedString(it)) }
                val displayText = if (thinking != null) visibleText else msg.text
                if (displayText.isNotBlank()) {
                    LatexAwareText(displayText, color = ObsColors.TextPrime)
                } else if (thinking == null) {
                    Text("...", color = ObsColors.TextPrime)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Builder Panel (preserved from original)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun BuilderPanel(
    prompt: String,
    onPrompt: (String) -> Unit,
    outputMode: String,
    onOutputMode: (String) -> Unit,
    code: String,
    raw: String,
    schema: UiSchema,
    enabled: Boolean,
    onGenerate: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard), border = BorderStroke(1.dp, ObsColors.Border), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Builder", color = ObsColors.TextPrime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Generate JSON UI for native preview, HTML for WebView preview, or React-style code for copy/testing elsewhere.", color = ObsColors.TextMuted)
            OutlinedTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.fillMaxWidth(), label = { Text("Describe the UI/app") }, minLines = 3)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("JSON UI", "HTML", "React").forEach { mode ->
                    Button(onClick = { onOutputMode(mode) }, enabled = outputMode != mode) { Text(mode) }
                }
            }
            Button(enabled = enabled && prompt.isNotBlank(), onClick = onGenerate, modifier = Modifier.fillMaxWidth()) { Text("Generate / refine") }
            Text("Preview", color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold)
            when (outputMode) {
                "JSON UI" -> DynamicScreen(schema)
                "HTML" -> HtmlPreview(code)
                else -> Text("React preview is shown as code. Android cannot run React without bundling a JS runtime/library.", color = ObsColors.TextMuted)
            }
            Text("Output", color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold)
            CodeBox(code.ifBlank { raw })
        }
    }
}

@Composable
private fun HtmlPreview(html: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().height(360.dp)) {
        AndroidView(factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = false } }, update = { webView ->
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        })
    }
}

@Composable
private fun CodeBox(text: String) {
    Box(modifier = Modifier.fillMaxWidth().background(ObsColors.BgPanel, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text(text, color = ObsColors.TextPrime)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Builder loop (preserved from original)
// ─────────────────────────────────────────────────────────────────────────────
private suspend fun runBuilderLoop(engine: InferenceEngine, request: String, mode: String, maxTokens: Int, refinePasses: Int, setStatus: (String) -> Unit): String {
    var currentPrompt = buildBuilderPrompt(request, mode)
    var result = ""
    val total = refinePasses.coerceIn(0, 3) + 1
    repeat(total) { pass ->
        setStatus(if (pass == 0) "Generating builder output..." else "Refinement pass $pass/$refinePasses...")
        val sb = StringBuilder()
        engine.sendUserPrompt(currentPrompt, maxTokens).collect { token -> sb.append(token) }
        result = sb.toString()
        if (pass < refinePasses) {
            currentPrompt = """
Review and improve your previous output.
Original user request: $request
Previous output:
$result
Return the complete improved final output only. Keep the same output type: $mode.
""".trimIndent()
        }
    }
    return result
}

private fun buildBuilderPrompt(request: String, mode: String): String = when (mode) {
    "JSON UI" -> "Create a native UI JSON for: $request. Return only JSON matching the schema."
    "HTML" -> "Create a polished dark responsive HTML UI for: $request. Return only a complete HTML document."
    else -> "Create a React component for: $request. Return only code."
}

private fun cleanBuilderOutput(text: String, mode: String): String = when (mode) {
    "JSON UI" -> extractFirstJsonObject(text)
    "HTML" -> extractHtml(text)
    else -> stripCodeFences(text).trim()
}

private fun stripCodeFences(text: String): String = text.replace(Regex("```[a-zA-Z]*"), "").replace("```", "")
private fun extractFirstJsonObject(text: String): String {
    val clean = stripCodeFences(text)
    val start = clean.indexOf('{')
    val end = clean.lastIndexOf('}')
    require(start >= 0 && end > start) { "No JSON object found in model output" }
    return clean.substring(start, end + 1).trim()
}
private fun extractHtml(text: String): String {
    val clean = stripCodeFences(text).trim()
    val start = clean.indexOf("<", ignoreCase = true).coerceAtLeast(0)
    return clean.substring(start)
}

private suspend fun waitUntilEngineInitialized(engine: InferenceEngine) {
    repeat(200) {
        when (val state = engine.state.value) {
            is InferenceEngine.State.Initialized, is InferenceEngine.State.ModelReady -> return
            is InferenceEngine.State.Error -> throw state.exception
            else -> delay(100)
        }
    }
    error("Timed out waiting for llama.cpp runtime initialization")
}

private suspend fun copyModelIntoAppStorage(context: Context, uri: Uri): File = withContext(Dispatchers.IO) {
    val dir = File(context.filesDir, "models").apply { mkdirs() }
    val target = File(dir, (context.displayName(uri) ?: "local-model.gguf").sanitizeFileName())
    context.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Could not open selected model file" }
        target.outputStream().use { output -> input.copyTo(output) }
    }
    target
}
private fun Context.displayName(uri: Uri): String? = runCatching {
    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }
}.getOrNull()
private fun String.sanitizeFileName(): String = replace(Regex("[^A-Za-z0-9._-]"), "_")
private fun snapContext(v: Int): Int = listOf(1024, 1536, 2048, 3072, 4096).minBy { kotlin.math.abs(it - v) }
private fun snapBatch(v: Int): Int = listOf(128, 256, 384, 512).minBy { kotlin.math.abs(it - v) }
private fun parseUiSchema(raw: String): UiSchema = json.decodeFromString<UiSchema>(raw)

// ─────────────────────────────────────────────────────────────────────────────
// Data Classes & UI Schemas
// ─────────────────────────────────────────────────────────────────────────────
data class ChatMessage(val role: String, val text: String, val isGenerating: Boolean = false, val searchProcess: String? = null)

@Serializable data class UiSchema(val title: String = "Untitled", val elements: List<UiElement> = emptyList())
@Serializable data class UiElement(val type: String, val id: String? = null, val text: String? = null, val hint: String? = null, val checked: Boolean = false, val children: List<UiElement> = emptyList())

@Composable
fun DynamicScreen(schema: UiSchema) {
    val textState = remember { mutableStateMapOf<String, String>() }
    val checkboxState = remember { mutableStateMapOf<String, Boolean>() }
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = ObsColors.BgPanel), border = BorderStroke(1.dp, ObsColors.Border), shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(schema.title, color = ObsColors.TextPrime, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            schema.elements.forEachIndexed { index, el -> RenderElement(el, "el_$index", textState, checkboxState) }
        }
    }
}

@Composable
fun RenderElement(element: UiElement, fallbackId: String, textState: MutableMap<String, String>, checkboxState: MutableMap<String, Boolean>) {
    val id = element.id ?: fallbackId
    when (element.type.lowercase()) {
        "text" -> Text(element.text.orEmpty(), color = ObsColors.TextMuted)
        "heading" -> Text(element.text.orEmpty(), color = ObsColors.TextPrime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        "input" -> OutlinedTextField(value = textState[id].orEmpty(), onValueChange = { textState[id] = it }, modifier = Modifier.fillMaxWidth(), label = { Text(element.hint ?: element.text ?: "Input") })
        "button" -> Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text(element.text ?: "Button") }
        "checkbox" -> {
            val checked = checkboxState[id] ?: element.checked
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Checkbox(checked = checked, onCheckedChange = { checkboxState[id] = it })
                Text(element.text ?: "Checkbox", color = ObsColors.TextPrime)
            }
        }
        "card" -> Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard), border = BorderStroke(1.dp, ObsColors.Border)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                element.text?.let { Text(it, color = ObsColors.TextPrime, fontWeight = FontWeight.SemiBold) }
                element.children.forEachIndexed { index, child -> RenderElement(child, "$id-$index", textState, checkboxState) }
            }
        }
        "spacer" -> Spacer(modifier = Modifier.height(10.dp))
        else -> Text("Unsupported element type: ${element.type}", color = Color(0xFFF87171))
    }
}

object ExampleSchemas {
    val login = """
        {"title":"Simple Login","elements":[{"type":"text","text":"Sign in to continue."},{"type":"input","id":"email","hint":"Email address"},{"type":"input","id":"password","hint":"Password"},{"type":"checkbox","id":"remember","text":"Remember me","checked":true},{"type":"button","text":"Login"}]}
    """.trimIndent()
}

// ─────────────────────────────────────────────────────────────────────────────
// Validation Suite (preserved from original)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun QualityValidationSuite() {
    Column(modifier = Modifier.fillMaxWidth().padding(6.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Rendering Quality & Math Validation Suite", color = ObsColors.TextPrime, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Verifying inline math integration, standard LaTeX display blocks, mixed markdown formatting, and zero popup UI chrome across platforms.", color = ObsColors.TextMuted)

        ValidationCard("1. Basic Algebra", "Solving linear & quadratic equations:\n\$2x + 5 = 15 \\implies 2x = 10 \\implies x = 5\$\nQuadratic roots formula:\n\$\$ x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a} \$\$\"")
        ValidationCard("2. Calculus", "Derivative of a product:\n\$\\frac{d}{dx} [ x^2 \\sin x ] = 2x \\sin x + x^2 \\cos x\$\nDefinite integral calculation:\n\\[ \\int_0^1 \\frac{4}{1+x^2} dx = \\pi \\]")
        ValidationCard("3. Linear Algebra", "Matrix transformations & vector equations:\n\$ \\det(A) \\neq 0\$ ensures invertibility. Dot product \$ \\vec{u} \\cdot \\vec{v} = 0\$ indicates orthogonality.")
        ValidationCard("4. Probability", "Bayes' Theorem for conditional probability:\n\$P(A|B) = \\frac{P(B|A)P(A)}{P(B)}\$")
        ValidationCard("5. Physics Equations", "Mass-energy equivalence \$E = mc^2\$ and Newton's Universal Law of Gravitation \$F = G \\frac{m_1 m_2}{r^2}\$.")
        ValidationCard("6. Long Derivations", "Step-by-step reduction:\nLet \$S = \\sum_{n=0}^\\infty r^n\$. Then \$rS = \\sum_{n=1}^\\infty r^n = S - 1\$. Therefore, \$S(1-r) = 1 \\implies S = \\frac{1}{1-r}\$ for \$|r| < 1\$.")
        ValidationCard("7. Mixed Markdown + LaTeX Content", "### Quantum Electro-Dynamics\n- **Photon propagator**: \$D_{\\mu\\nu}(k) = \\frac{-i g_{\\mu\\nu}}{k^2 + i\\epsilon}\$\n- `Code block`: `q_field.sample(GBNF_sampler)`")
        ValidationCard("8. Standard Indefinite Integrals", "\$\\int x^3 \\, dx = \\frac{x^4}{4} + C\$\n\$\\int e^x \\, dx = e^x + C\$")
    }
}

@Composable
private fun ValidationCard(title: String, content: String) {
    Card(colors = CardDefaults.cardColors(containerColor = ObsColors.BgCard), border = BorderStroke(1.dp, ObsColors.Border), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
            LatexAwareText(content, color = ObsColors.TextPrime)
        }
    }
}