package com.arena.aiuibuilder

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AiWorkbenchApp() }
    }
}

/** Native tuning is added by the GitHub workflow patch to llama.cpp's ai_chat.cpp. */
object NativeTuning {
    init {
        runCatching { System.loadLibrary("ai-chat") }
    }
    external fun setOptions(threads: Int, contextSize: Int, batchSize: Int, temperature: Float)
}

private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

private val DarkBg = Color(0xFF080B12)
private val Panel = Color(0xFF111827)
private val Panel2 = Color(0xFF0F172A)
private val Stroke = Color(0xFF263244)
private val TextMain = Color(0xFFE5E7EB)
private val TextMuted = Color(0xFF94A3B8)
private val Accent = Color(0xFF7C3AED)
private val Accent2 = Color(0xFF22C55E)

private const val UI_JSON_SYSTEM_PROMPT = """
You are an offline Android UI generator.
Return ONLY one valid JSON object. No markdown. No explanation. No code fences. No <think>.
Allowed schema:
{
  "title": "screen title",
  "elements": [
    {"type":"heading|text|input|button|checkbox|card|spacer", "id":"optional", "text":"optional", "hint":"optional", "checked":false, "children":[]}
  ]
}
Rules:
- Use only the allowed element types.
- Keep IDs lowercase and simple.
- Keep output compact.
"""

private const val UNIVERSAL_SYSTEM_PROMPT = """
You are a helpful offline assistant and UI builder running locally on Android.
For normal chat, answer naturally and concisely.
For builder tasks, follow the user's requested output format exactly.
If asked for JSON, HTML, or code, return only that artifact with no markdown fences unless explicitly requested.
"""

@Composable
fun AiWorkbenchApp() {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = DarkBg) {
            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            // Keep one stable phone-style layout even when a tablet is rotated.
            // This avoids UI switching/recomposing into a different two-pane layout mid-generation.
            val wide = false
            val engine = remember { AiChat.getInferenceEngine(context.applicationContext) }
            val engineState by engine.state.collectAsState()

            var selectedMode by remember { mutableStateOf("chat") }
            var status by remember { mutableStateOf("Pick a local GGUF model, tune settings, then load.") }
            var error by remember { mutableStateOf<String?>(null) }
            var selectedModelUri by remember { mutableStateOf<Uri?>(null) }
            var selectedModelName by remember { mutableStateOf<String?>(null) }
            var copiedModelPath by remember { mutableStateOf<String?>(null) }
            var isBusy by remember { mutableStateOf(false) }
            var activeSystemMode by remember { mutableStateOf<String?>(null) }

            var threads by remember { mutableStateOf(4) }
            var contextSize by remember { mutableStateOf(2048) }
            var batchSize by remember { mutableStateOf(256) }
            var temperature by remember { mutableStateOf(0.25f) }
            var maxTokens by remember { mutableStateOf(700) }
            var refinePasses by remember { mutableStateOf(1) }

            var chatInput by remember { mutableStateOf("") }
            val chatMessages = remember { mutableStateListOf<ChatMessage>() }

            var builderPrompt by remember { mutableStateOf("Make a clean login screen with email, password, remember me, and submit button") }
            var outputMode by remember { mutableStateOf("JSON UI") }
            var generatedCode by remember { mutableStateOf(ExampleSchemas.login) }
            var rawOutput by remember { mutableStateOf("") }
            var uiSchema by remember { mutableStateOf(parseUiSchema(ExampleSchemas.login)) }

            val picker = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument(),
                onResult = { uri ->
                    if (uri != null) {
                        runCatching {
                            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        selectedModelUri = uri
                        selectedModelName = context.displayName(uri) ?: "model.gguf"
                        status = "Selected $selectedModelName. Tap Load model."
                        error = null
                    }
                }
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                HeaderBar(
                    engineState = engineState,
                    status = status,
                    error = error,
                    isBusy = isBusy,
                    modelName = selectedModelName,
                    onPick = { if (!isBusy) picker.launch(arrayOf("*/*")) },
                    onLoad = {
                        val uri = selectedModelUri ?: return@HeaderBar
                        scope.launch {
                            isBusy = true
                            error = null
                            try {
                                status = "Applying speed settings..."
                                runCatching { NativeTuning.setOptions(threads, contextSize, batchSize, temperature) }

                                status = "Copying GGUF into app storage..."
                                val modelFile = copyModelIntoAppStorage(context, uri)
                                copiedModelPath = modelFile.absolutePath

                                status = "Waiting for runtime..."
                                waitUntilEngineInitialized(engine)

                                status = "Loading model. Keep app open."
                                engine.loadModel(modelFile.absolutePath)
                                status = "Setting assistant mode..."
                                engine.setSystemPrompt(UNIVERSAL_SYSTEM_PROMPT.trimIndent())
                                activeSystemMode = "universal"
                                status = "Model ready."
                            } catch (t: Throwable) {
                                error = t.message ?: t.toString()
                                status = "Model load failed."
                            } finally {
                                isBusy = false
                            }
                        }
                    }
                )

                SpeedSettings(
                    threads = threads,
                    onThreads = { threads = it },
                    contextSize = contextSize,
                    onContext = { contextSize = it },
                    batchSize = batchSize,
                    onBatch = { batchSize = it },
                    temperature = temperature,
                    onTemp = { temperature = it },
                    maxTokens = maxTokens,
                    onMaxTokens = { maxTokens = it },
                    refinePasses = refinePasses,
                    onRefine = { refinePasses = it }
                )

                ModeTabs(selectedMode = selectedMode, onSelect = { selectedMode = it })

                if (wide) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            ChatPanel(
                                input = chatInput,
                                onInput = { chatInput = it },
                                messages = chatMessages,
                                enabled = !isBusy && engineState is InferenceEngine.State.ModelReady,
                                onSend = {
                                    val text = chatInput.trim()
                                    if (text.isBlank()) return@ChatPanel
                                    chatInput = ""
                                    scope.launch {
                                        isBusy = true
                                        error = null
                                        try {
                                            chatMessages += ChatMessage("You", text)
                                            val index = chatMessages.size
                                            chatMessages += ChatMessage("AI", "")
                                            engine.sendUserPrompt(text, maxTokens).collect { token ->
                                                chatMessages[index] = chatMessages[index].copy(text = chatMessages[index].text + token)
                                            }
                                            status = "Chat complete."
                                        } catch (t: Throwable) {
                                            error = t.message ?: t.toString()
                                        } finally { isBusy = false }
                                    }
                                }
                            )
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            BuilderPanel(
                                prompt = builderPrompt,
                                onPrompt = { builderPrompt = it },
                                outputMode = outputMode,
                                onOutputMode = { outputMode = it },
                                code = generatedCode,
                                raw = rawOutput,
                                schema = uiSchema,
                                enabled = !isBusy && engineState is InferenceEngine.State.ModelReady,
                                onGenerate = {
                                    scope.launch {
                                        isBusy = true
                                        error = null
                                        try {
                                            val result = runBuilderLoop(engine, builderPrompt, outputMode, maxTokens, refinePasses) { s -> status = s }
                                            rawOutput = result
                                            generatedCode = cleanBuilderOutput(result, outputMode)
                                            if (outputMode == "JSON UI") uiSchema = parseUiSchema(generatedCode)
                                            activeSystemMode = "builder"
                                            status = "Builder complete."
                                        } catch (t: Throwable) {
                                            error = t.message ?: t.toString()
                                            status = "Builder failed."
                                        } finally { isBusy = false }
                                    }
                                }
                            )
                        }
                    }
                } else {
                    if (selectedMode == "chat") {
                        ChatPanel(
                            input = chatInput,
                            onInput = { chatInput = it },
                            messages = chatMessages,
                            enabled = !isBusy && engineState is InferenceEngine.State.ModelReady,
                            onSend = {
                                val text = chatInput.trim()
                                if (text.isBlank()) return@ChatPanel
                                chatInput = ""
                                scope.launch {
                                    isBusy = true
                                    error = null
                                    try {
                                        chatMessages += ChatMessage("You", text)
                                        val index = chatMessages.size
                                        chatMessages += ChatMessage("AI", "")
                                        engine.sendUserPrompt(text, maxTokens).collect { token ->
                                            chatMessages[index] = chatMessages[index].copy(text = chatMessages[index].text + token)
                                        }
                                        status = "Chat complete."
                                    } catch (t: Throwable) { error = t.message ?: t.toString() }
                                    finally { isBusy = false }
                                }
                            }
                        )
                    } else if (selectedMode == "builder") {
                        BuilderPanel(
                            prompt = builderPrompt,
                            onPrompt = { builderPrompt = it },
                            outputMode = outputMode,
                            onOutputMode = { outputMode = it },
                            code = generatedCode,
                            raw = rawOutput,
                            schema = uiSchema,
                            enabled = !isBusy && engineState is InferenceEngine.State.ModelReady,
                            onGenerate = {
                                scope.launch {
                                    isBusy = true
                                    error = null
                                    try {
                                        val result = runBuilderLoop(engine, builderPrompt, outputMode, maxTokens, refinePasses) { s -> status = s }
                                        rawOutput = result
                                        generatedCode = cleanBuilderOutput(result, outputMode)
                                        if (outputMode == "JSON UI") uiSchema = parseUiSchema(generatedCode)
                                        activeSystemMode = "builder"
                                        status = "Builder complete."
                                    } catch (t: Throwable) {
                                        error = t.message ?: t.toString()
                                        status = "Builder failed."
                                    } finally { isBusy = false }
                                }
                            }
                        )
                    } else {
                        RecursiveRefinerPanel(
                            modelReady = engineState is InferenceEngine.State.ModelReady,
                            onStatus = { status = it },
                            onError = { error = it }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HeaderBar(engineState: InferenceEngine.State, status: String, error: String?, isBusy: Boolean, modelName: String?, onPick: () -> Unit, onLoad: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Stroke)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Local AI Studio", color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (isBusy) CircularProgressIndicator(modifier = Modifier.height(22.dp), color = Accent, strokeWidth = 2.dp)
            }
            Text(status, color = TextMuted)
            Text("Engine: ${engineState.javaClass.simpleName}${modelName?.let { " • $it" } ?: ""}", color = TextMuted)
            error?.let { Text("Error: $it", color = Color(0xFFF87171)) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(enabled = !isBusy, onClick = onPick) { Text("Pick GGUF") }
                Button(enabled = !isBusy, onClick = onLoad) { Text("Load model") }
            }
        }
    }
}

@Composable
private fun ModeTabs(selectedMode: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onSelect("chat") }, enabled = selectedMode != "chat") { Text("Chat") }
        Button(onClick = { onSelect("builder") }, enabled = selectedMode != "builder") { Text("Builder") }
        Button(onClick = { onSelect("refiner") }, enabled = selectedMode != "refiner") { Text("Refiner") }
    }
}

@Composable
private fun SpeedSettings(threads: Int, onThreads: (Int) -> Unit, contextSize: Int, onContext: (Int) -> Unit, batchSize: Int, onBatch: (Int) -> Unit, temperature: Float, onTemp: (Float) -> Unit, maxTokens: Int, onMaxTokens: (Int) -> Unit, refinePasses: Int, onRefine: (Int) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Stroke)) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Speed tuning", color = TextMain, fontWeight = FontWeight.SemiBold)
            Text("Best for 4GB RAM: Q4/Q5, 3–4 threads, context 1024–2048, batch 128–256. Changes apply before loading the model.", color = TextMuted)
            SettingSlider("Threads", threads.toFloat(), 1f, 6f, { onThreads(it.toInt()) }, threads.toString())
            SettingSlider("Context", contextSize.toFloat(), 1024f, 4096f, { onContext(snapContext(it.toInt())) }, contextSize.toString())
            SettingSlider("Batch", batchSize.toFloat(), 128f, 512f, { onBatch(snapBatch(it.toInt())) }, batchSize.toString())
            SettingSlider("Temperature", temperature, 0.05f, 1.0f, onTemp, "%.2f".format(temperature))
            SettingSlider("Max tokens", maxTokens.toFloat(), 128f, 1500f, { onMaxTokens(it.toInt()) }, maxTokens.toString())
            SettingSlider("Refine passes", refinePasses.toFloat(), 0f, 3f, { onRefine(it.toInt()) }, refinePasses.toString())
        }
    }
}

@Composable
private fun SettingSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit, shown: String) {
    Column {
        Row { Text(label, color = TextMuted, modifier = Modifier.weight(1f)); Text(shown, color = TextMain) }
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max)
    }
}

@Composable
private fun ChatPanel(input: String, onInput: (String) -> Unit, messages: List<ChatMessage>, enabled: Boolean, onSend: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Stroke), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Chat", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.height(360.dp).verticalScroll(rememberScrollState())) {
                if (messages.isEmpty()) Text("Ask anything. This is a simple local chat editor.", color = TextMuted)
                messages.forEach { msg -> MessageBubble(msg) }
            }
            OutlinedTextField(value = input, onValueChange = onInput, modifier = Modifier.fillMaxWidth(), label = { Text("Type message") }, minLines = 2)
            Button(enabled = enabled && input.isNotBlank(), onClick = onSend, modifier = Modifier.fillMaxWidth()) { Text("Send") }
        }
    }
}

@Composable
private fun MessageBubble(msg: ChatMessage) {
    val user = msg.role == "You"
    Box(modifier = Modifier.fillMaxWidth()) {
        Card(colors = CardDefaults.cardColors(containerColor = if (user) Color(0xFF312E81) else Panel2), modifier = Modifier.align(if (user) Alignment.CenterEnd else Alignment.CenterStart).widthIn(max = 520.dp)) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text(msg.role, color = if (user) Color(0xFFC4B5FD) else Color(0xFF86EFAC), fontWeight = FontWeight.Bold)
                Text(msg.text.ifBlank { "..." }, color = TextMain)
            }
        }
    }
}

@Composable
private fun BuilderPanel(prompt: String, onPrompt: (String) -> Unit, outputMode: String, onOutputMode: (String) -> Unit, code: String, raw: String, schema: UiSchema, enabled: Boolean, onGenerate: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Stroke), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Builder", color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Generate JSON UI for native preview, HTML for WebView preview, or React-style code for copy/testing elsewhere.", color = TextMuted)
            OutlinedTextField(value = prompt, onValueChange = onPrompt, modifier = Modifier.fillMaxWidth(), label = { Text("Describe the UI/app") }, minLines = 3)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("JSON UI", "HTML", "React").forEach { mode ->
                    Button(onClick = { onOutputMode(mode) }, enabled = outputMode != mode) { Text(mode) }
                }
            }
            Button(enabled = enabled && prompt.isNotBlank(), onClick = onGenerate, modifier = Modifier.fillMaxWidth()) { Text("Generate / refine") }
            Text("Preview", color = TextMain, fontWeight = FontWeight.SemiBold)
            when (outputMode) {
                "JSON UI" -> DynamicScreen(schema)
                "HTML" -> HtmlPreview(code)
                else -> Text("React preview is shown as code. Android cannot run React without bundling a JS runtime/library.", color = TextMuted)
            }
            Text("Output", color = TextMain, fontWeight = FontWeight.SemiBold)
            CodeBox(code.ifBlank { raw })
        }
    }
}

@Composable
private fun HtmlPreview(html: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().height(360.dp)) {
        AndroidView(factory = { ctx -> WebView(ctx).apply { settings.javaScriptEnabled = false } }, update = { webView ->
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        })
    }
}

@Composable
private fun CodeBox(text: String) {
    Box(modifier = Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(12.dp)).padding(12.dp)) {
        Text(text, color = TextMain)
    }
}

private suspend fun runBuilderLoop(engine: InferenceEngine, request: String, mode: String, maxTokens: Int, refinePasses: Int, setStatus: (String) -> Unit): String {
    var currentPrompt = buildBuilderPrompt(request, mode)
    var result = ""
    val total = refinePasses.coerceIn(0, 3) + 1
    repeat(total) { pass ->
        setStatus(if (pass == 0) "Generating builder output..." else "Refinement pass $pass/$refinePasses...")
        val sb = StringBuilder()
        engine.sendUserPrompt(currentPrompt, maxTokens).collect { token -> sb.append(token) }
        result = sb.toString()
        if (pass < refinePasses) {
            currentPrompt = """
Review and improve your previous output.
Original user request: $request
Previous output:
$result
Return the complete improved final output only. Keep the same output type: $mode.
""".trimIndent()
        }
    }
    return result
}

private fun buildBuilderPrompt(request: String, mode: String): String = when (mode) {
    "JSON UI" -> "Create a native UI JSON for: $request. Return only JSON matching the schema."
    "HTML" -> "Create a polished dark responsive HTML UI for: $request. Return only a complete HTML document."
    else -> "Create a React component for: $request. Return only code."
}

private fun cleanBuilderOutput(text: String, mode: String): String = when (mode) {
    "JSON UI" -> extractFirstJsonObject(text)
    "HTML" -> extractHtml(text)
    else -> stripCodeFences(text).trim()
}

private fun stripCodeFences(text: String): String = text.replace(Regex("```[a-zA-Z]*"), "").replace("```", "")
private fun extractFirstJsonObject(text: String): String {
    val clean = stripCodeFences(text)
    val start = clean.indexOf('{')
    val end = clean.lastIndexOf('}')
    require(start >= 0 && end > start) { "No JSON object found in model output" }
    return clean.substring(start, end + 1).trim()
}
private fun extractHtml(text: String): String {
    val clean = stripCodeFences(text).trim()
    val start = clean.indexOf("<", ignoreCase = true).coerceAtLeast(0)
    return clean.substring(start)
}

private suspend fun waitUntilEngineInitialized(engine: InferenceEngine) {
    repeat(200) {
        when (val state = engine.state.value) {
            is InferenceEngine.State.Initialized, is InferenceEngine.State.ModelReady -> return
            is InferenceEngine.State.Error -> throw state.exception
            else -> delay(100)
        }
    }
    error("Timed out waiting for llama.cpp runtime initialization")
}

private suspend fun copyModelIntoAppStorage(context: Context, uri: Uri): File = withContext(Dispatchers.IO) {
    val dir = File(context.filesDir, "models").apply { mkdirs() }
    val target = File(dir, (context.displayName(uri) ?: "local-model.gguf").sanitizeFileName())
    context.contentResolver.openInputStream(uri).use { input ->
        requireNotNull(input) { "Could not open selected model file" }
        target.outputStream().use { output -> input.copyTo(output) }
    }
    target
}
private fun Context.displayName(uri: Uri): String? = runCatching {
    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    }
}.getOrNull()
private fun String.sanitizeFileName(): String = replace(Regex("[^A-Za-z0-9._-]"), "_")
private fun snapContext(v: Int): Int = listOf(1024, 1536, 2048, 3072, 4096).minBy { kotlin.math.abs(it - v) }
private fun snapBatch(v: Int): Int = listOf(128, 256, 384, 512).minBy { kotlin.math.abs(it - v) }
private fun parseUiSchema(raw: String): UiSchema = json.decodeFromString<UiSchema>(raw)

data class ChatMessage(val role: String, val text: String)

@Serializable data class UiSchema(val title: String = "Untitled", val elements: List<UiElement> = emptyList())
@Serializable data class UiElement(val type: String, val id: String? = null, val text: String? = null, val hint: String? = null, val checked: Boolean = false, val children: List<UiElement> = emptyList())

@Composable
fun DynamicScreen(schema: UiSchema) {
    val textState = remember { mutableStateMapOf<String, String>() }
    val checkboxState = remember { mutableStateMapOf<String, Boolean>() }
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel2), border = BorderStroke(1.dp, Stroke), shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(schema.title, color = TextMain, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            schema.elements.forEachIndexed { index, el -> RenderElement(el, "el_$index", textState, checkboxState) }
        }
    }
}

@Composable
fun RenderElement(element: UiElement, fallbackId: String, textState: MutableMap<String, String>, checkboxState: MutableMap<String, Boolean>) {
    val id = element.id ?: fallbackId
    when (element.type.lowercase()) {
        "text" -> Text(element.text.orEmpty(), color = TextMuted)
        "heading" -> Text(element.text.orEmpty(), color = TextMain, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        "input" -> OutlinedTextField(value = textState[id].orEmpty(), onValueChange = { textState[id] = it }, modifier = Modifier.fillMaxWidth(), label = { Text(element.hint ?: element.text ?: "Input") })
        "button" -> Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text(element.text ?: "Button") }
        "checkbox" -> {
            val checked = checkboxState[id] ?: element.checked
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Checkbox(checked = checked, onCheckedChange = { checkboxState[id] = it })
                Text(element.text ?: "Checkbox", color = TextMain)
            }
        }
        "card" -> Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, Stroke)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                element.text?.let { Text(it, color = TextMain, fontWeight = FontWeight.SemiBold) }
                element.children.forEachIndexed { index, child -> RenderElement(child, "$id-$index", textState, checkboxState) }
            }
        }
        "spacer" -> Spacer(modifier = Modifier.height(10.dp))
        else -> Text("Unsupported element type: ${element.type}", color = Color(0xFFF87171))
    }
}

object ExampleSchemas {
    val login = """
        {"title":"Simple Login","elements":[{"type":"text","text":"Sign in to continue."},{"type":"input","id":"email","hint":"Email address"},{"type":"input","id":"password","hint":"Password"},{"type":"checkbox","id":"remember","text":"Remember me","checked":true},{"type":"button","text":"Login"}]}
    """.trimIndent()
}
