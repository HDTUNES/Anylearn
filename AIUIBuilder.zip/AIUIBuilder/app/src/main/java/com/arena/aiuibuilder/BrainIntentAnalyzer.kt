package com.arena.aiuibuilder

data class BrainIntent(
  val originalQuery:String,
  val normalizedProblem:String,
  val domain:String,
  val entities:List<String>,
  val intentType:String,
  val isValid:Boolean,
  val nullGuardReason:String? = null
)

object BrainIntentAnalyzer {
  fun analyze(query:String): BrainIntent {
    val q = query.trim()
    if(q.length < 6) return BrainIntent(query,q,"unknown",emptyList(),"unknown",false,"query too short")
    val lower=q.lowercase()
    val intentType = when {
      lower.startsWith("how to make")||lower.startsWith("how to build")||"artificially on hardware" in lower -> "how_build"
      lower.startsWith("what is")||lower.startsWith("explain") -> "explain_concept"
      " vs " in lower || "compare" in lower -> "compare"
      lower.contains("solve")||lower.contains("calculate") -> "solve"
      else -> "explore"
    }
    val domain = when {
      listOf("neuron","brain","synapse","axon","ion channel","memristor","neuromorphic","spiking").any{it in lower} -> "neuroscience_hardware"
      listOf("quantum","physics","thermodynamics").any{it in lower} -> "physics"
      else -> "general"
    }
    val vocab = listOf("neuron","brain","hardware","memristor","transistor","capacitor","ion channel","action potential","spiking neural network","neuromorphic","loihi","truenorth","lif model","hodgkin","huxley","izhikevich","fpga","cmos","analog")
    val entities = vocab.filter{ it in lower }.distinct()
    val normalized = q.replace(Regex("\\s+")," ").trim()
      .removeSuffix("?").trim().ifBlank{ "analyze: $q" }
    return BrainIntent(
      originalQuery=q,
      normalizedProblem=normalized,
      domain=domain,
      entities=entities,
      intentType=intentType,
      isValid=true,
      nullGuardReason=null
    )
  }
  fun safeProblemString(intent:BrainIntent, fallback:String): String {
    return intent.normalizedProblem.takeIf{it.isNotBlank() && it.lowercase()!="null"} ?: fallback.takeIf{it.isNotBlank()} ?: "analyze request"
  }
}
