package com.arena.aiuibuilder

/**
 * Abstraction over "how similar is this text to this query." Starts as the existing
 * word-overlap heuristic; EmbeddingRelevanceScorer (Stage B, future work) swaps the
 * implementation without any caller needing to change.
 *
 * (blueprint Part 5.2, Stage A)
 */
interface RelevanceScorer {
    suspend fun score(text: String, query: String): Float
}

object WordOverlapRelevanceScorer : RelevanceScorer {
    override suspend fun score(text: String, query: String): Float {
        val queryWords = query.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        val textWords = text.lowercase().split(Regex("\\s+")).filter { it.length > 3 }.toSet()
        if (textWords.isEmpty() || queryWords.isEmpty()) return 0f
        return textWords.intersect(queryWords).size.toFloat() / textWords.union(queryWords).size.toFloat()
    }
}

/**
 * Swap-in point: set this to an EmbeddingRelevanceScorer once Stage B is wired up.
 * Defaults to the existing word-overlap logic so nothing changes for callers.
 */
object RelevanceScorerProvider {
    var active: RelevanceScorer = WordOverlapRelevanceScorer
}
