package com.arena.aiuibuilder

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val TPanel = Color(0xFF111827)
private val TPanel2 = Color(0xFF0F172A)
private val TStroke = Color(0xFF263244)
private val TText = Color(0xFFE5E7EB)
private val TMuted = Color(0xFF94A3B8)

fun splitThinking(raw: String): Pair<String?, String> {
    val start = raw.indexOf("<think>", ignoreCase = true)
    if (start < 0) return null to raw
    val contentStart = start + "<think>".length
    val end = raw.indexOf("</think>", startIndex = contentStart, ignoreCase = true)
    return if (end >= 0) {
        val thinking = raw.substring(contentStart, end).trim()
        val after = raw.substring(end + "</think>".length).trim()
        thinking to after
    } else {
        val thinking = raw.substring(contentStart).trim()
        thinking to ""
    }
}

fun isReasoningComplete(raw: String): Boolean = raw.contains("</think>", ignoreCase = true)

@Composable
fun ThinkingGlareText(text: String = "Thinking", isAnimating: Boolean = true) {
    if (isAnimating) {
        ActiveGlareText(text)
    } else {
        Text(
            text = text,
            color = Color(0xFF94A3B8),
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ActiveGlareText(text: String) {
    val transition = rememberInfiniteTransition(label = "thinking-glare")
    val offset by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(1300, easing = LinearEasing), repeatMode = RepeatMode.Restart),
        label = "glare-offset"
    )
    val brush = Brush.linearGradient(
        colors = listOf(
            Color(0xFF64748B),
            Color(0xFFE5E7EB),
            Color(0xFFFFFFFF),
            Color(0xFFE5E7EB),
            Color(0xFF64748B)
        ),
        start = androidx.compose.ui.geometry.Offset(0f + offset * 700f, 0f),
        end = androidx.compose.ui.geometry.Offset(250f + offset * 700f, 0f)
    )
    Text(text = text, style = androidx.compose.ui.text.TextStyle(brush = brush, fontWeight = FontWeight.Bold))
}

@Composable
fun ThinkingBlock(thinking: String, isAnimating: Boolean = false, onCopy: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = TPanel2), border = BorderStroke(1.dp, TStroke)) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(1f).clickable { expanded = !expanded }) {
                    val label = when {
                        isAnimating && expanded -> "Thinking expanded..."
                        isAnimating -> "Thinking — tap to expand"
                        expanded -> "Thought process"
                        else -> "Thought process — tap to expand"
                    }
                    ThinkingGlareText(label, isAnimating)
                }
                Button(onClick = { onCopy(thinking) }) { Text("Copy") }
            }
            if (expanded) {
                Text(
                    thinking.ifBlank { "Thinking started..." },
                    color = TMuted,
                    modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState())
                )
            }
        }
    }
}

@Composable
fun ThinkingAwareLiveOutput(raw: String, showRaw: Boolean, latest: RefinerIteration?, isGenerating: Boolean = false, onCopy: (String) -> Unit) {
    val (thinking, afterThink) = splitThinking(raw)
    val isThinkingActive = isGenerating && !isReasoningComplete(raw)
    Card(colors = CardDefaults.cardColors(containerColor = TPanel), border = BorderStroke(1.dp, TStroke)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Live output", color = TText, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(onClick = { onCopy(raw) }) { Text("Copy") }
            }
            if (thinking != null) ThinkingBlock(thinking, isThinkingActive, onCopy)
            if (showRaw) {
                val visible = if (thinking != null) afterThink else raw
                Text(
                    visible.ifBlank { if (thinking != null) "Waiting for final output after thinking..." else "" },
                    color = TText,
                    modifier = Modifier.background(TPanel2, RoundedCornerShape(10.dp)).padding(10.dp).heightIn(max = 260.dp).verticalScroll(rememberScrollState())
                )
            } else {
                if (latest == null) {
                    Text("Rendered view appears when JSON is complete. Raw generation is still running.", color = TMuted)
                } else {
                    Text("Refined", color = Color(0xFF86EFAC), fontWeight = FontWeight.Bold)
                    LatexAwareText(latest.refined, color = TText)
                    Text("Next focus", color = Color(0xFFC4B5FD), fontWeight = FontWeight.Bold)
                    LatexAwareText(latest.nextFocus, color = TText)
                }
            }
        }
    }
}
