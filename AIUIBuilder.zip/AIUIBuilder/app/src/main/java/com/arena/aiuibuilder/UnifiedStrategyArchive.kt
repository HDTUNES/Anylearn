package com.arena.aiuibuilder

import kotlinx.serialization.Serializable
import kotlin.math.ln
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * One shared archive of "what works," fed by BOTH the Cognitive engine and the
 * Refiner. This is the missing "Optimizer" step in the self-evolving-agent loop
 * (System Inputs -> Agent System -> Environment -> Optimizer; see Fang et al. 2025).
 *
 * Deliberately modeled after MesaEngine's existing, already-correct pattern
 * (Beta-Thompson-sampling bandit arms over an open-ended archive), generalized
 * so a "strategy" can be either an operator-sequence (from Cognitive) or a
 * (domain, lens) pair (from Refiner) — both are just named, taggable arms.
 *
 * (blueprint Part 5.4)
 */
@Serializable
data class StrategyArm(
    val id: String,
    val source: String,          // "cognitive" | "refiner"
    val description: String,     // human-readable, shown in diagnostics
    val tags: Set<String>,       // e.g. domain keywords, operator names — used to match a new goal to a relevant arm
    var alpha: Float = 1f,
    var beta: Float = 1f
) {
    fun sampleBetaThompson(): Float {
        val mean = alpha / (alpha + beta)
        val noise = (Random.nextFloat() - 0.5f) * (1.0f / sqrt(alpha + beta))
        return (mean + noise).coerceIn(0.01f, 0.99f)
    }
    val successRate: Float get() = alpha / (alpha + beta)
}

object UnifiedStrategyArchive {
    private val arms = mutableListOf<StrategyArm>()

    fun register(arm: StrategyArm) {
        if (arms.none { it.id == arm.id }) arms.add(arm)
    }

    /**
     * Record an outcome — call this from BOTH MesaEngine.commitIterationResult and
     * CognitiveEngine.consolidateSkills so every success/failure updates the same pool.
     */
    fun recordOutcome(armId: String, success: Boolean) {
        arms.find { it.id == armId }?.let {
            if (success) it.alpha += 1f else it.beta += 1f
        }
    }

    /**
     * Pick the best-matching arm for a new goal, regardless of which tab discovered it.
     */
    fun selectForGoal(goalWords: Set<String>, topN: Int = 3): List<StrategyArm> {
        return arms
            .map { arm ->
                val tagOverlap = if (arm.tags.isEmpty()) 0f
                    else arm.tags.intersect(goalWords).size.toFloat() / arm.tags.size.toFloat()
                arm to (tagOverlap * 0.6f + arm.sampleBetaThompson() * 0.4f)
            }
            .sortedByDescending { it.second }
            .take(topN)
            .map { it.first }
    }

    fun allArms(): List<StrategyArm> = arms.toList()
}
