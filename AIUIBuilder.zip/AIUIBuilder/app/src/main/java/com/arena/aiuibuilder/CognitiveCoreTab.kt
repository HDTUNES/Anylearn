package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arm.aichat.InferenceEngine

/**
 * COGNITIVE CORE — the unified reasoning tab.
 *
 * UI/history additions in v10.1 are presentation-layer only. If any requested UI
 * feature conflicts with runtime behavior, the existing architecture wins.
 */
private val CorePanel  = Color(0xFF000000)   // v10: pure black (was 0xFF0B0F17 dark navy)
private val CoreStroke = Color(0xFF1A1A1A)   // v10: dark grey stroke (was 0xFF263244 navy)
private val CoreTextMain = Color(0xFFE5E7EB)
private val CoreTextMuted = Color(0xFF94A3B8)
private val CoreAccentNormal = Color(0xFF7C3AED)
private val CoreAccentMeta = Color(0xFFF59E0B)

enum class CognitiveCoreMode { NORMAL, META_COGNITIVE }

@Composable
fun CognitiveCoreTab(
    engine: InferenceEngine,
    modelReady: Boolean,
    maxTokens: Int,
    onStatus: (String) -> Unit,
    onError: (String) -> Unit,
    vm: AppSessionViewModel? = null
) {
    var mode by remember { mutableStateOf(CognitiveCoreMode.NORMAL) }
    val sidebarListState = rememberLazyListState()
    val sidebarOpenState = vm?.cognitiveSidebarOpen?.collectAsState() ?: remember { mutableStateOf(false) }
    val activeIdState = vm?.cognitiveConversationId?.collectAsState() ?: remember { mutableStateOf<String?>(null) }
    val historyVersionState = vm?.cognitiveHistoryVersion?.collectAsState() ?: remember { mutableStateOf(0) }
    val sidebarOpen by sidebarOpenState
    val activeId by activeIdState
    val historyVersion by historyVersionState

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
            Text(
                "Cognitive Core",
                color = CoreTextMain,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
            Text(
                "One reasoning mind, two operating conditions.",
                color = CoreTextMuted,
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 10.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = CorePanel),
                border = BorderStroke(1.dp, CoreStroke),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CoreModeChip(
                        label = "Normal",
                        sublabel = "Reach a confident final answer",
                        selected = mode == CognitiveCoreMode.NORMAL,
                        accent = CoreAccentNormal,
                        modifier = Modifier.weight(1f),
                        onClick = { mode = CognitiveCoreMode.NORMAL }
                    )
                    CoreModeChip(
                        label = "Meta-Cognitive",
                        sublabel = "Explore indefinitely, no final stop",
                        selected = mode == CognitiveCoreMode.META_COGNITIVE,
                        accent = CoreAccentMeta,
                        modifier = Modifier.weight(1f),
                        onClick = { mode = CognitiveCoreMode.META_COGNITIVE }
                    )
                }
            }

            when (mode) {
                CognitiveCoreMode.NORMAL -> {
                    CognitivePanel(
                        engine = engine,
                        enabled = modelReady,
                        maxTokens = maxTokens,
                        onStatus = onStatus,
                        onError = onError,
                        vm = vm
                    )
                }
                CognitiveCoreMode.META_COGNITIVE -> {
                    RecursiveRefinerPanel(
                        modelReady = modelReady,
                        onStatus = onStatus,
                        onError = { onError(it ?: "") },
                        vm = vm
                    )
                }
            }
        }

        vm?.let { realVm ->
            ConversationSidebar(
                open = sidebarOpen,
                tab = "cognitive_core",
                activeId = activeId,
                historyVersion = historyVersion,
                onClose = { realVm.cognitiveSidebarOpen.value = false },
                onSelect = { record ->
                    realVm.cognitiveConversationId.value = record.id
                    realVm.pendingCognitiveLoad.value = record
                    mode = if (record.cognitiveSubMode == "META_COGNITIVE") CognitiveCoreMode.META_COGNITIVE else CognitiveCoreMode.NORMAL
                },
                onNew = {
                    realVm.cognitiveConversationId.value = null
                    realVm.pendingCognitiveLoad.value = ConversationRecord(tab = "cognitive_core", title = "")
                },
                listState = sidebarListState
            )
        }
    }
}

@Composable
private fun CoreModeChip(
    label: String,
    sublabel: String,
    selected: Boolean,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = if (selected) accent.copy(alpha = 0.16f) else Color.Transparent),
        border = BorderStroke(1.dp, if (selected) accent.copy(alpha = 0.55f) else CoreStroke),
        shape = RoundedCornerShape(10.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(label, color = if (selected) accent else CoreTextMain, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.fillMaxWidth())
            Text(sublabel, color = CoreTextMuted, fontSize = 10.sp)
        }
    }
}
