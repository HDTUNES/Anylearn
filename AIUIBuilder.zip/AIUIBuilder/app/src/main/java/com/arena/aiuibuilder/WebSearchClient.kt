package com.arena.aiuibuilder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SearchResult(
    val id: Int,
    val title: String,
    val url: String,
    val snippet: String
)

object WebSearchClient {
    /**
     * Multi-Backend Cloudflare-Immune Web Scraper.
     * Queries Wikipedia Search REST API + DuckDuckGo Instant API + Host Clock Fallback.
     */
    suspend fun search(query: String, limit: Int = 3): List<SearchResult> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val results = mutableListOf<SearchResult>()

        // 1. Wikipedia Search REST API (100% free, zero Cloudflare block)
        try {
            val enc = URLEncoder.encode(query.trim(), "UTF-8")
            val wikiUrl = URL("https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=$enc&utf8=&format=json&srlimit=$limit")
            val conn = (wikiUrl.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 4000
                setRequestProperty("User-Agent", "AIUIBuilderStudio/1.0 (Android LocalAI)")
            }
            if (conn.responseCode == 200) {
                val jsonText = conn.inputStream.bufferedReader().use { it.readText() }
                val titleMatches = Regex("\"title\":\"([^\"]+)\"").findAll(jsonText)
                val snippetMatches = Regex("\"snippet\":\"([^\"]+)\"").findAll(jsonText)
                val titles = titleMatches.map { unescapeJson(it.groupValues[1]) }.toList()
                val snips = snippetMatches.map { stripHtml(unescapeJson(it.groupValues[1])) }.toList()

                val count = minOf(limit, titles.size, snips.size)
                for (i in 0 until count) {
                    val u = "https://en.wikipedia.org/wiki/" + URLEncoder.encode(titles[i].replace(" ", "_"), "UTF-8")
                    results.add(SearchResult(results.size + 1, "Wikipedia: ${titles[i]}", u, snips[i]))
                }
            }
            conn.disconnect()
        } catch (e: Exception) { AppLog.append("Wiki search error: ${e.message}") }

        // 2. DuckDuckGo Instant Answer API
        if (results.size < limit) {
            try {
                val enc = URLEncoder.encode(query.trim(), "UTF-8")
                val ddgUrl = URL("https://api.duckduckgo.com/?q=$enc&format=json&no_html=1")
                val conn = (ddgUrl.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4000
                    readTimeout = 4000
                    setRequestProperty("User-Agent", "AIUIBuilderStudio/1.0")
                }
                if (conn.responseCode == 200) {
                    val jsonText = conn.inputStream.bufferedReader().use { it.readText() }
                    val headingMatch = Regex("\"Heading\":\"([^\"]+)\"").find(jsonText)
                    val abstractMatch = Regex("\"AbstractText\":\"([^\"]+)\"").find(jsonText)
                    val urlMatch = Regex("\"AbstractURL\":\"([^\"]+)\"").find(jsonText)
                    if (headingMatch != null && abstractMatch != null && abstractMatch.groupValues[1].isNotBlank()) {
                        val h = unescapeJson(headingMatch.groupValues[1])
                        val abs = unescapeJson(abstractMatch.groupValues[1])
                        val u = urlMatch?.let { unescapeJson(it.groupValues[1]) } ?: "https://duckduckgo.com/?q=$enc"
                        results.add(SearchResult(results.size + 1, "DuckDuckGo: $h", u, abs))
                    }
                }
                conn.disconnect()
            } catch (e: Exception) { AppLog.append("DDG search error: ${e.message}") }
        }

        // 3. Guaranteed Authoritative Host Clock & Datetime Grounding
        val now = SimpleDateFormat("EEEE, MMMM dd, yyyy HH:mm:ss z", Locale.getDefault()).format(Date())
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        results.add(
            SearchResult(
                id = results.size + 1,
                title = "Verified Host Application System Clock & Location",
                url = "host://system-clock-authoritative",
                snippet = "Current Authoritative Today Date: $todayStr ($now). Location: India/Asia. Note: Ignore pre-trained training cutoff dates (e.g. 2023). Today is strictly $todayStr."
            )
        )

        results.take(limit)
    }

    private fun stripHtml(raw: String): String {
        return raw.replace(Regex("<[^>]*>"), "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun unescapeJson(raw: String): String {
        return raw.replace("\\\"", "\"")
            .replace("\\/", "/")
            .replace("\\n", " ")
            .replace("\\t", " ")
            .replace("\\\\", "\\")
    }

    fun formatGrounding(results: List<SearchResult>): String {
        if (results.isEmpty()) return ""
        return buildString {
            appendLine("[MANDATORY HARD CONTEXT INJECTION (Top ${results.size} Verified Sources)]:")
            results.forEach { r ->
                appendLine("[${r.id}] Title: ${r.title}")
                appendLine("URL: ${r.url}")
                appendLine("Content: ${r.snippet}")
                appendLine()
            }
            appendLine("CRITICAL RESTRICTION: You are strictly restricted to answering the user prompt using ONLY the verified facts above. Do NOT guess. Do NOT claim you lack real-time access or state your training cutoff date.")
        }.trim()
    }

    fun extractKeywords(text: String): String {
        val clean = text.replace(Regex("[^A-Za-z0-9\\s]"), " ")
            .split(" ")
            .filter { it.length > 3 }
            .filterNot { it.lowercase() in stopWords }
            .take(6)
            .joinToString(" ")
        return clean.ifBlank { text.take(40) }
    }

    private val stopWords = setOf(
        "this", "that", "with", "from", "have", "would", "should", "could", "there", "their",
        "about", "which", "when", "what", "where", "next", "focus", "refined", "idea", "improve",
        "make", "more", "better", "analysis", "structural", "feasibility", "practicality"
    )
}
