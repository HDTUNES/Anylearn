package com.arena.aiuibuilder

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ─────────────────────────────────────────────────────────────────────────────
// Stage enum — 9 stages for the full cognitive pipeline
// ─────────────────────────────────────────────────────────────────────────────
enum class PipelineStage {
    SYSTEM_PROMPT_ASSEMBLY,
    MEMORY_RETRIEVAL,
    GOAL_SELECTION,
    ARCHIVE_REVIEW,
    HYPOTHESIS_GENERATION,
    CODE_EXECUTION,
    VERIFICATION_TESTING,
    REPAIR_RETRY,
    PERSISTENCE_SNAPSHOT
}

enum class StageStatus {
    PENDING,    // not reached yet
    ACTIVE,     // currently running — shows spinner + shimmer
    COMPLETED,  // done — shows [✓]
    FAILED,     // error — shows [✗] in red
    SKIPPED     // bypassed this iteration
}

// Per-stage diagnostic payload — filled in by the engine callbacks
data class StageDiagnostics(
    val stage: PipelineStage,
    val status: StageStatus = StageStatus.PENDING,
    val startedAtMs: Long = 0L,
    val completedAtMs: Long = 0L,

    // What went in
    val inputSummary: String = "",
    val promptSizeChars: Int = 0,
    val promptSizeTokensEstimate: Int = 0,

    // What came out
    val outputSummary: String = "",
    val outputSizeChars: Int = 0,

    // Memory info
    val readNodes: List<String> = emptyList(),
    val writtenNodes: List<String> = emptyList(),
    val archivedNodes: List<String> = emptyList(),
    val confidenceDeltas: Map<String, Float> = emptyMap(),

    // Archive / goal info
    val selectedCell: String = "",
    val ucbScore: Float = 0f,
    val winningPolicy: String = "",
    val policySuccessRate: Float = 0f,

    // Code execution
    val codeSnippet: String = "",
    val codeOutput: String = "",
    val codeSuccess: Boolean = false,
    val codeTimeMs: Long = 0L,

    // Verification
    val jaccardScore: Float = 0f,
    val adversarialGate: String = "",
    val domainVerified: Boolean = false,

    // Repair
    val repairAttempts: Int = 0,
    val repairLog: String = "",
    val savedFromFallback: Boolean = false,

    // Persistence
    val snapshotSizeBytes: Long = 0L,
    val snapshotWriteMs: Long = 0L,
    val nodesConsolidated: Int = 0,

    // Meta
    val metacognitionTriggered: String? = null,
    val errorMessage: String? = null,
    val rawJsonGenerated: String = ""
)

// Full iteration snapshot — stored in history
@Serializable
data class IterationSnapshot(
    val iterNumber: Int,
    val startedAtMs: Long,
    val completedAtMs: Long,
    val targetCell: String,
    val winningPolicy: String,
    val rawJson: String,
    val refinedText: String,
    val nextFocus: String,
    val qualityScore: Float,
    val becameElite: Boolean,
    val isDuplicate: Boolean,
    val generationSecs: Float,
    val stuckCount: Int,
    val empiricalReport: String
)

// ─────────────────────────────────────────────────────────────────────────────
// Observable session state — updated by engine, read by UI
// ALL mutations MUST go through the Main thread. Use the enqueueXxx methods
// instead of directly mutating the lists/maps.
// ─────────────────────────────────────────────────────────────────────────────
object ObservatoriumSession {

    // All Compose SnapshotStateList / SnapshotStateMap mutations MUST happen on
    // the Main thread. Use mainHandler.post { } for any mutation from a background
    // thread (IO, native dispatcher, etc.).
    private val mainHandler = Handler(Looper.getMainLooper())

    // Current pipeline stage states (resets each iteration)
    val stageMap = mutableStateMapOf<PipelineStage, StageDiagnostics>()

    // Live token stream from HYPOTHESIS_GENERATION.
    // MUST be mutableStateOf so Compose recomposes when updated by the poll job.
    // mutableStateOf is thread-safe for writes (Compose 1.7+), so the IO-thread
    // callModel lambda can also write to it safely.
    var liveTokenStream by mutableStateOf("")

    // Prediction error tracking for observatory display
    var lastPredictionError by mutableStateOf(0f)
    var lastPeOperator by mutableStateOf("")
    var peHistory = mutableStateListOf<Float>()

    // Live log entries (rolling, last 500) — mutate ONLY via pushLog()
    private val _liveTerminalLogs = mutableStateListOf<StructuredLogEntry>()
    val liveTerminalLogs: List<StructuredLogEntry> get() = _liveTerminalLogs

    // Full iteration history (all iterations this session) — mutate ONLY via addIterationSnapshot()
    private val _iterationHistory = mutableStateListOf<IterationSnapshot>()
    val iterationHistory: List<IterationSnapshot> get() = _iterationHistory

    // Full raw JSON history (for export) — mutate ONLY via addIterationSnapshot()
    private val _rawJsonHistory = mutableStateListOf<String>()
    val rawJsonHistory: List<String> get() = _rawJsonHistory

    // Current iteration number
    var currentIterationNumber: Int = 0

    fun resetForNewIteration(iterNum: Int) {
        currentIterationNumber = iterNum
        // liveTokenStream is mutableStateOf — safe to set from any thread
        liveTokenStream = ""
        // stageMap is mutableStateMapOf — must be mutated on Main thread
        mainHandler.post {
            PipelineStage.entries.forEach { stage ->
                stageMap[stage] = StageDiagnostics(stage = stage, status = StageStatus.PENDING)
            }
        }
    }

    /**
     * Update a single stage's diagnostics. Thread-safe: dispatches to Main if called
     * from a background thread. In RefinerPanel, onDiag already uses
     * scope.launch(Dispatchers.Main) so this is called on Main — but the guard here
     * ensures correctness regardless of the calling thread.
     */
    fun updateStage(diag: StageDiagnostics) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            stageMap[diag.stage] = diag
        } else {
            mainHandler.post { stageMap[diag.stage] = diag }
        }
    }

    /**
     * Thread-safe log push. Can be called from ANY thread (IO, native dispatcher, Main).
     * Always dispatches the actual list mutation to the Main thread because
     * SnapshotStateList (mutableStateListOf) requires Main-thread mutation — using
     * synchronized() from an IO thread does NOT satisfy Compose's snapshot requirement
     * and causes silent log drops or IllegalStateException crashes.
     */
    fun pushLog(entry: StructuredLogEntry) {
        mainHandler.post {
            _liveTerminalLogs.add(0, entry)
            if (_liveTerminalLogs.size > 500) _liveTerminalLogs.removeAt(_liveTerminalLogs.lastIndex)
        }
    }

    fun addIterationSnapshot(snap: IterationSnapshot) {
        mainHandler.post {
            _iterationHistory.add(0, snap)
            _rawJsonHistory.add(0, snap.rawJson)
            if (_iterationHistory.size > 100) _iterationHistory.removeAt(_iterationHistory.lastIndex)
        }
    }

    fun clearLogs() {
        mainHandler.post {
            _liveTerminalLogs.clear()
        }
    }

    fun clearHistory() {
        mainHandler.post {
            _iterationHistory.clear()
            _rawJsonHistory.clear()
        }
    }

    fun exportSessionMarkdown(): String {
        val sb = StringBuilder()
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        sb.appendLine("# MESA COGNITIVE RUNTIME DUMP")
        sb.appendLine("Session exported: ${df.format(Date())}")
        sb.appendLine("Total iterations captured: ${_iterationHistory.size}")
        sb.appendLine()
        _iterationHistory.reversed().forEach { snap ->
            sb.appendLine("## Iteration ${snap.iterNumber}")
            sb.appendLine("- Target: ${snap.targetCell}")
            sb.appendLine("- Policy: ${snap.winningPolicy}")
            sb.appendLine("- Quality: ${"%.3f".format(snap.qualityScore)} | Elite: ${snap.becameElite} | Dup: ${snap.isDuplicate}")
            sb.appendLine("- Time: ${"%.1f".format(snap.generationSecs)}s | Stuck: ${snap.stuckCount}")
            sb.appendLine()
            sb.appendLine("### Refined Output")
            sb.appendLine(snap.refinedText)
            sb.appendLine()
            sb.appendLine("### Next Focus")
            sb.appendLine(snap.nextFocus)
            sb.appendLine()
            sb.appendLine("### Raw GBNF JSON")
            sb.appendLine("```json")
            sb.appendLine(snap.rawJson)
            sb.appendLine("```")
            sb.appendLine()
            sb.appendLine("### Empirical Report")
            sb.appendLine(snap.empiricalReport)
            sb.appendLine()
            sb.appendLine("---")
        }
        sb.appendLine()
        sb.appendLine("## Live Log (last 50 entries)")
        _liveTerminalLogs.take(50).reversed().forEach { entry ->
            sb.appendLine("[${entry.timestamp}] [${entry.level}] [${entry.stage}] iter=${entry.iteration} ${entry.message}")
        }
        return sb.toString()
    }
}

data class StructuredLogEntry(
    val timestamp: String,
    val level: String,
    val stage: String,
    val iteration: Int,
    val message: String,
    val extras: Map<String, Any> = emptyMap()
)
