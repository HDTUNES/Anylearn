package com.arena.aiuibuilder

import android.content.Context
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Code Execution Engine for reality-grounding on Android.
 *
 * Uses a lightweight WebView JavaScript sandbox to execute small generated scripts.
 * This lets the system verify quantitative/logical claims, run base-case simulations,
 * and compare predictions against actual outputs.
 *
 * FIX (blueprint 1.2): replaced CountDownLatch.await() on Main thread with
 * suspendCancellableCoroutine + withTimeoutOrNull. The old code deadlocked because
 * latch.await() blocked the Main thread, preventing the postDelayed Runnable that
 * would call latch.countDown() from ever executing. Now the coroutine suspends
 * without occupying the thread, so the WebView callback can actually fire.
 */

object CodeExecutionEngine {

    private const val TIMEOUT_MS = 5000L

    data class ExecutionResult(
        val success: Boolean,
        val output: String,
        val error: String?
    )

    /**
     * Execute a JavaScript snippet and return the result.
     *
     * Uses suspendCancellableCoroutine so the calling coroutine suspends (freeing
     * the Main thread) while waiting for the WebView callback, instead of blocking
     * the thread with CountDownLatch.await() which caused a structural deadlock.
     */
    suspend fun executeJavaScript(context: Context, script: String): ExecutionResult {
        val wrappedScript = buildString {
            append("(function() {")
            append("  try {")
            append("    var __result = (function(){\n")
            append(script)
            append("\n    })();")
            append("    if (typeof __result === 'object') { __result = JSON.stringify(__result); }")
            append("    else { __result = String(__result); }")
            append("    return 'MESA_EXEC_OK:' + __result;")
            append("  } catch (e) {")
            append("    return 'MESA_EXEC_ERR:' + e.message;")
            append("  }")
            append("})()")
        }

        val raw: String? = withTimeoutOrNull(TIMEOUT_MS) {
            withContext(Dispatchers.Main.immediate) {
                runWebViewScript(context, wrappedScript)
            }
        }

        if (raw == null) return ExecutionResult(false, "", "Execution timed out")
        return parseResult(raw)
    }

    /**
     * Suspends until the WebView delivers the script result.
     * The coroutine suspends without blocking the Main thread, so the WebView
     * callback can actually run on the Main thread's Looper as expected.
     */
    private suspend fun runWebViewScript(context: Context, wrappedScript: String): String? =
        suspendCancellableCoroutine { cont ->
            val webView = WebView(context.applicationContext)
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = false

            fun cleanup() = runCatching { webView.destroy() }
            cont.invokeOnCancellation { webView.post { cleanup() } }

            webView.webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    webView.evaluateJavascript(wrappedScript) { value ->
                        if (cont.isActive) cont.resume(value)
                        cleanup()
                    }
                }
            }
            webView.loadUrl("about:blank")
        }

    /**
     * Convenience: verify a simple arithmetic claim by generating a test script.
     */
    fun generateArithmeticTest(claim: String): String? {
        // Extract expressions like "2+2=4" or "3*5=15"
        val exprMatch = Regex("(\\d+\\s*[+\\-*/^]\\s*\\d+)\\s*=\\s*(\\d+)").find(claim)
        if (exprMatch != null) {
            val expr = exprMatch.groupValues[1].replace("^", "**")
            val expected = exprMatch.groupValues[2]
            return "return ($expr === $expected) ? 'TRUE' : 'FALSE: expected $expected, got ' + ($expr);"
        }
        return null
    }

    /**
     * Generate a JavaScript test for a generic falsifiable claim.
     * The LLM is asked to produce code; this function wraps it safely.
     */
    fun wrapTestCode(generatedCode: String): String {
        return """
            (function(){
                var console = { log: function(){} };
                ${generatedCode.trim()}
            })()
        """.trimIndent()
    }

    private fun parseResult(raw: String): ExecutionResult {
        return when {
            raw.startsWith("MESA_EXEC_OK:") -> ExecutionResult(true, raw.removePrefix("MESA_EXEC_OK:"), null)
            raw.startsWith("MESA_EXEC_ERR:") -> ExecutionResult(false, "", raw.removePrefix("MESA_EXEC_ERR:"))
            else -> ExecutionResult(false, "", "Unexpected execution format")
        }
    }
}
