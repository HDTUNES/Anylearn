package com.arena.aiuibuilder

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@Serializable
data class ConversationRecord(
    val id: String = UUID.randomUUID().toString(),
    val tab: String,
    var title: String,
    val createdAtMs: Long = System.currentTimeMillis(),
    var updatedAtMs: Long = System.currentTimeMillis(),
    var pinned: Boolean = false,
    var messages: List<ChatMessage> = emptyList(),
    var cognitiveSubMode: String = "NORMAL",
    var cognitiveQuery: String = "",
    var cognitiveResultSummary: String = "",
    var cognitiveFullDumpText: String = ""
)

object ConversationHistoryStore {
    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }
    private const val STORE_FILE = "conversation_history.json"
    private val records = mutableListOf<ConversationRecord>()
    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        val f = File(context.filesDir, STORE_FILE)
        if (f.exists()) {
            runCatching {
                records.clear()
                records.addAll(json.decodeFromString<List<ConversationRecord>>(f.readText()))
            }
        }
        loaded = true
    }

    private fun persist(context: Context) {
        runCatching { File(context.filesDir, STORE_FILE).writeText(json.encodeToString(records.toList())) }
    }

    suspend fun upsert(context: Context, record: ConversationRecord) = withContext(Dispatchers.IO) {
        load(context)
        val idx = records.indexOfFirst { it.id == record.id }
        val stamped = record.copy(updatedAtMs = System.currentTimeMillis())
        if (idx >= 0) records[idx] = stamped else records.add(0, stamped)
        persist(context)
    }

    fun delete(context: Context, id: String) { load(context); records.removeAll { it.id == id }; persist(context) }
    fun rename(context: Context, id: String, newTitle: String) { load(context); records.find { it.id == id }?.title = newTitle; persist(context) }
    fun setPinned(context: Context, id: String, pinned: Boolean) { load(context); records.find { it.id == id }?.pinned = pinned; persist(context) }

    fun listForTab(context: Context, tab: String): List<ConversationRecord> {
        load(context)
        return records.filter { it.tab == tab }
            .sortedWith(compareByDescending<ConversationRecord> { it.pinned }.thenByDescending { it.updatedAtMs })
    }

    fun deriveTitle(text: String): String {
        val trimmed = text.trim()
        val head = trimmed.take(40)
        return if (trimmed.length > 40) "$head…" else head.ifBlank { "Untitled" }
    }
}
