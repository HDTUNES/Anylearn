package com.arena.aiuibuilder

/**
 * JNI bridge for the strict recursive refiner.
 *
 * The implementation is appended to llama.cpp's Android ai_chat.cpp during GitHub Actions.
 * Strict behavior:
 * - grounding is evaluated once and cached
 * - each iteration erases KV/memory after grounding
 * - prompt/instruction evaluation runs with grammar OFF
 * - JSON generation runs with native llama.cpp GBNF grammar ON
 */
object NativeRecursiveRefiner {
    init {
        runCatching { System.loadLibrary("ai-chat") }
    }

    external fun beginSession(grounding: String): Int

    external fun refineOnce(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repeatPenalty: Float
    ): String

    external fun resetSession()
}
