package com.arena.aiuibuilder

/**
 * JNI bridge for the strict recursive refiner.
 *
 * The implementation is appended to llama.cpp's Android ai_chat.cpp during GitHub Actions.
 * Strict behavior:
 * - grounding is evaluated once and cached
 * - each iteration erases KV/memory after grounding
 * - prompt/instruction evaluation runs with grammar OFF
 * - JSON generation runs with native llama.cpp GBNF grammar ON
 */
object NativeRecursiveRefiner {
    init {
        runCatching { System.loadLibrary("ai-chat") }
    }

    external fun setStrictKvMode(strict: Boolean)
    external fun setThinkingMode(enabled: Boolean, maxThinkingTokens: Int)

    external fun beginSession(grounding: String): Int

    external fun refineOnce(
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        topK: Int,
        topP: Float,
        minP: Float,
        repeatPenalty: Float
    ): String

    external fun getProgressChars(): Int
    external fun getProgressTokens(): Int
    external fun getProgressText(): String
    external fun getTimingSummary(): String

    external fun resetSession()
}