package com.arena.aiuibuilder

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Production mixed Markdown + LaTeX renderer.
 *
 * v10.1 guarantee: all existing Markdown behavior remains compatible alongside
 * the new LaTeX path. Existing headings, lists, blockquotes/task-list text,
 * links/images-as-source text, inline code, bold spans, and table rows continue
 * through the same prose tokenizer unless a fenced code block or display math
 * delimiter explicitly promotes that region into a richer renderer.
 */
@Composable
fun LatexAwareText(text: String, color: Color = Color(0xFFE5E7EB)) {
    val blocks = remember(text) { splitContentBlocks(text) }
    SelectionContainer {
        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            blocks.forEach { block ->
                when (block) {
                    is ContentBlock.Code -> CodeBlockView(block.language, block.code)
                    is ContentBlock.DisplayMath -> {
                        KatexMath(
                            latex = block.text,
                            displayMode = true,
                            color = color,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp)
                        )
                    }
                    is ContentBlock.Prose -> RenderProse(block.text, color)
                }
            }
        }
    }
}

sealed class ContentBlock {
    data class Prose(val text: String) : ContentBlock()
    data class DisplayMath(val text: String) : ContentBlock()
    data class Code(val language: String, val code: String) : ContentBlock()
}

data class DisplayBlock(val text: String, val isDisplayMath: Boolean)

private val AMS_ENV_NAMES = setOf(
    "equation", "equation*", "align", "align*", "alignat", "alignat*",
    "gather", "gather*", "multline", "multline*", "cases", "split",
    "matrix", "pmatrix", "bmatrix", "vmatrix", "Vmatrix", "array",
    "aligned", "gathered", "subarray", "smallmatrix"
)

private fun looksLikeGenuineMath(candidate: String): Boolean {
    if (candidate.length > 600) return false
    if (candidate.contains("\n\n")) return false
    if (Regex("(?m)^#{1,6}\\s").containsMatchIn(candidate)) return false
    return true
}

private val fencePattern = Regex("```([a-zA-Z0-9_+-]*)\\n?")

fun splitContentBlocks(raw: String): List<ContentBlock> {
    val blocks = mutableListOf<ContentBlock>()
    val prose = StringBuilder()
    fun flushProse() {
        if (prose.isNotEmpty()) {
            blocks += ContentBlock.Prose(prose.toString())
            prose.clear()
        }
    }

    var i = 0
    while (i < raw.length) {
        if (raw.startsWith("```", i)) {
            val langEnd = raw.indexOf('\n', i + 3).let { if (it < 0) raw.length else it }
            val lang = raw.substring(i + 3, langEnd).trim().ifBlank { "text" }
            val codeStart = (langEnd + 1).coerceAtMost(raw.length)
            val closeIdx = raw.indexOf("```", codeStart)
            flushProse()
            if (closeIdx < 0) {
                blocks += ContentBlock.Code(lang, raw.substring(codeStart))
                return blocks
            }
            blocks += ContentBlock.Code(lang, raw.substring(codeStart, closeIdx))
            i = closeIdx + 3
            continue
        }
        if (raw.startsWith("$$", i)) {
            val closeIdx = raw.indexOf("$$", i + 2)
            if (closeIdx < 0) {
                flushProse()
                blocks += ContentBlock.DisplayMath(raw.substring(i + 2))
                return blocks
            }
            val candidate = raw.substring(i + 2, closeIdx)
            if (looksLikeGenuineMath(candidate)) {
                flushProse()
                blocks += ContentBlock.DisplayMath(candidate)
                i = closeIdx + 2
                continue
            }
            prose.append("$$")
            i += 2
            continue
        }
        if (raw.startsWith("\\[", i)) {
            val closeIdx = raw.indexOf("\\]", i + 2)
            flushProse()
            if (closeIdx < 0) {
                blocks += ContentBlock.DisplayMath(raw.substring(i + 2))
                return blocks
            }
            blocks += ContentBlock.DisplayMath(raw.substring(i + 2, closeIdx))
            i = closeIdx + 2
            continue
        }
        if (raw.startsWith("\\begin{", i)) {
            val nameEnd = raw.indexOf('}', i + 7)
            val envName = if (nameEnd > 0) raw.substring(i + 7, nameEnd) else ""
            if (envName in AMS_ENV_NAMES) {
                val closeTag = "\\end{$envName}"
                val closeIdx = raw.indexOf(closeTag, nameEnd)
                flushProse()
                if (closeIdx < 0) {
                    blocks += ContentBlock.DisplayMath(raw.substring(i))
                    return blocks
                }
                val envEnd = closeIdx + closeTag.length
                blocks += ContentBlock.DisplayMath(raw.substring(i, envEnd))
                i = envEnd
                continue
            }
        }
        prose.append(raw[i])
        i++
    }
    flushProse()
    return blocks
}
fun splitDisplayBlocks(raw: String): List<DisplayBlock> {
    if (raw.isBlank()) return listOf(DisplayBlock(raw, false))
    val result = mutableListOf<DisplayBlock>()
    var cursor = 0
    while (cursor < raw.length) {
        val candidates = listOf("$$", "\\[").mapNotNull { open ->
            val idx = raw.indexOf(open, cursor)
            if (idx >= 0) open to idx else null
        }.sortedBy { it.second }
        if (candidates.isEmpty()) {
            result += DisplayBlock(raw.substring(cursor), false)
            break
        }
        val (open, idx) = candidates.first()
        val close = if (open == "$$") "$$" else "\\]"
        if (idx > cursor) result += DisplayBlock(raw.substring(cursor, idx), false)
        val start = idx + open.length
        val end = raw.indexOf(close, start)
        if (end < 0) {
            result += DisplayBlock(raw.substring(idx), false)
            break
        }
        result += DisplayBlock(raw.substring(start, end).trim(), true)
        cursor = end + close.length
    }
    return result
}

sealed class InlineSpan(val text: String) {
    class Plain(text: String) : InlineSpan(text)
    class Math(text: String) : InlineSpan(text)
    class Bold(text: String) : InlineSpan(text)
    class Code(text: String) : InlineSpan(text)
}

fun tokenizeInline(line: String): List<InlineSpan> {
    val spans = mutableListOf<InlineSpan>()
    var cursor = 0
    val n = line.length
    while (cursor < n) {
        val cands = listOf("$", "\\(", "`", "**").mapNotNull { open ->
            val idx = line.indexOf(open, cursor)
            if (idx < 0) return@mapNotNull null
            if (open == "$" && idx + 1 < n && line[idx + 1] == '$') return@mapNotNull null
            Triple(idx, open, when (open) { "$" -> "$"; "\\(" -> "\\)"; "`" -> "`"; else -> "**" })
        }.sortedBy { it.first }
        if (cands.isEmpty()) {
            spans += InlineSpan.Plain(line.substring(cursor))
            break
        }
        val (idx, open, close) = cands.first()
        if (idx > cursor) spans += InlineSpan.Plain(line.substring(cursor, idx))
        val start = idx + open.length
        val end = line.indexOf(close, start)
        if (end < 0) {
            spans += InlineSpan.Plain(line.substring(idx))
            break
        }
        val inner = line.substring(start, end)
        when (open) {
            "$" -> spans += InlineSpan.Math(inner)
            "\\(" -> spans += InlineSpan.Math(inner)
            "`" -> spans += InlineSpan.Code(inner)
            else -> spans += InlineSpan.Bold(inner)
        }
        cursor = end + close.length
    }
    return spans
}

@Composable
private fun RenderProse(text: String, color: Color) {
    if (text.isBlank()) return
    val lines = remember(text) { text.split("\n") }
    lines.forEach { line ->
        if (line.isNotBlank()) {
            val spans = remember(line) { tokenizeInline(stripMarkdownPrefixForProbe(line)) }
            val complexMath = spans.filterIsInstance<InlineSpan.Math>().filter { needsKatexEngine(it.text) }
            if (complexMath.isNotEmpty()) {
                val annotated = remember(line, color) { buildParagraphAnnotatedString(line, color) }
                Text(text = annotated, modifier = Modifier.fillMaxWidth(), lineHeight = 22.sp)
                complexMath.forEach { KatexMath(it.text, displayMode = false, color = color) }
            } else {
                val annotated = remember(line, color) { buildParagraphAnnotatedString(line, color) }
                Text(text = annotated, modifier = Modifier.fillMaxWidth(), lineHeight = 22.sp)
            }
        }
    }
}

private fun stripMarkdownPrefixForProbe(line: String): String = when {
    line.startsWith("### ") -> line.removePrefix("### ")
    line.startsWith("## ") -> line.removePrefix("## ")
    line.startsWith("# ") -> line.removePrefix("# ")
    line.startsWith("- ") -> line.removePrefix("- ")
    line.startsWith("* ") -> line.removePrefix("* ")
    else -> line
}

private fun needsKatexEngine(latex: String): Boolean {
    val markers = listOf("\\begin{", "\\\\", "\\ce{", "\\overset", "\\underset", "\\substack")
    return markers.any { latex.contains(it) }
}

fun buildParagraphAnnotatedString(line: String, baseColor: Color): AnnotatedString {
    var textToParse = line
    var prefix = ""
    var isHeader = false
    when {
        line.startsWith("### ") -> { isHeader = true; textToParse = line.removePrefix("### ") }
        line.startsWith("## ") -> { isHeader = true; textToParse = line.removePrefix("## ") }
        line.startsWith("# ") -> { isHeader = true; textToParse = line.removePrefix("# ") }
        line.startsWith("- [ ] ") -> { prefix = "☐  "; textToParse = line.removePrefix("- [ ] ") }
        line.startsWith("- [x] ", ignoreCase = true) -> { prefix = "☑  "; textToParse = line.substring(6) }
        line.startsWith("> ") -> { prefix = "▌  "; textToParse = line.removePrefix("> ") }
        line.startsWith("- ") -> { prefix = "•  "; textToParse = line.removePrefix("- ") }
        line.startsWith("* ") -> { prefix = "•  "; textToParse = line.removePrefix("* ") }
    }

    val spans = tokenizeInline(textToParse)
    return buildAnnotatedString {
        if (prefix.isNotEmpty()) {
            withStyle(SpanStyle(color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)) { append(prefix) }
        }
        spans.forEach { span ->
            when (span) {
                is InlineSpan.Plain -> {
                    withStyle(SpanStyle(color = baseColor, fontWeight = if (isHeader) AppTypography.HeadingWeight else AppTypography.ProseWeight, fontSize = if (isHeader) 16.sp else 14.sp)) {
                        append(span.text)
                    }
                }
                is InlineSpan.Bold -> {
                    withStyle(SpanStyle(color = baseColor, fontWeight = FontWeight.Bold)) { append(span.text) }
                }
                is InlineSpan.Code -> {
                    withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = Color(0xFFF8FAFC), background = Color(0xFF161616), fontWeight = AppTypography.CodeWeight)) {
                        append(" ${span.text} ")
                    }
                }
                is InlineSpan.Math -> {
                    val beautified = beautifyLatex(span.text)
                    withStyle(SpanStyle(fontFamily = FontFamily.Serif, fontStyle = FontStyle.Italic, color = baseColor, fontSize = if (isHeader) 18.sp else 16.sp, fontWeight = FontWeight.SemiBold)) {
                        append(beautified)
                    }
                }
            }
        }
    }
}

fun beautifyLatex(src: String): String {
    var s = src.trim()
    s = s.replace(Regex("\\\\begin\\{[pbbv]?matrix\\}"), "[ ")
    s = s.replace(Regex("\\\\end\\{[pbbv]?matrix\\}"), " ]")
    s = s.replace(Regex("\\\\begin\\{cases\\}"), "{ ")
    s = s.replace(Regex("\\\\end\\{cases\\}"), "")
    s = s.replace("\\\\", "\n  ")

    val symbols = mapOf(
        "\\alpha" to "α", "\\beta" to "β", "\\gamma" to "γ", "\\Gamma" to "Γ",
        "\\delta" to "δ", "\\Delta" to "Δ", "\\epsilon" to "ε", "\\varepsilon" to "ε",
        "\\zeta" to "ζ", "\\eta" to "η", "\\theta" to "θ", "\\Theta" to "Θ",
        "\\iota" to "ι", "\\kappa" to "κ", "\\lambda" to "λ", "\\Lambda" to "Λ",
        "\\mu" to "μ", "\\nu" to "ν", "\\xi" to "ξ", "\\Xi" to "Ξ",
        "\\pi" to "π", "\\Pi" to "Π", "\\rho" to "ρ", "\\sigma" to "σ",
        "\\Sigma" to "Σ", "\\tau" to "τ", "\\upsilon" to "υ", "\\phi" to "φ",
        "\\Phi" to "Φ", "\\varphi" to "φ", "\\chi" to "χ", "\\psi" to "ψ",
        "\\Psi" to "Ψ", "\\omega" to "ω", "\\Omega" to "Ω",
        "\\int" to "∫", "\\iint" to "∬", "\\iiint" to "∭", "\\oint" to "∮",
        "\\sum" to "∑", "\\prod" to "∏", "\\lim" to "lim", "\\partial" to "∂",
        "\\nabla" to "∇", "\\infty" to "∞", "\\times" to "×", "\\cdot" to "·",
        "\\pm" to "±", "\\mp" to "∓", "\\leq" to "≤", "\\le" to "≤",
        "\\geq" to "≥", "\\ge" to "≥", "\\neq" to "≠", "\\ne" to "≠",
        "\\approx" to "≈", "\\equiv" to "≡", "\\to" to "→", "\\rightarrow" to "→",
        "\\leftarrow" to "←", "\\leftrightarrow" to "↔", "\\implies" to "⟹",
        "\\iff" to "⟺", "\\forall" to "∀", "\\exists" to "∃", "\\in" to "∈",
        "\\notin" to "∉", "\\subset" to "⊂", "\\subseteq" to "⊆", "\\dots" to "…",
        "\\cdots" to "…", "\\sin" to "sin", "\\cos" to "cos", "\\tan" to "tan", "\\ln" to "ln",
        "\\log" to "log", "\\exp" to "exp", "\\sec" to "sec", "\\csc" to "csc",
        "\\cot" to "cot"
    )
    symbols.forEach { (k, v) -> s = s.replace(k, v) }
    s = s.replace(Regex("\\\\frac\\{([^{}]+)\\}\\{([^{}]+)\\}"), "($1)/($2)")
    s = s.replace(Regex("\\\\sqrt\\{([^{}]+)\\}"), "√($1)")
    s = s.replace(Regex("\\^\\{([^{}]+)\\}"), "^$1")
    s = s.replace(Regex("_\\{([^{}]+)\\}"), "_$1")
    s = s.replace("\\left", "").replace("\\right", "")
    return s
}

@Composable
fun ValidationCard(title: String, body: String, color: Color) {
    Box(modifier = Modifier.fillMaxWidth().background(color.copy(alpha = 0.12f), RoundedCornerShape(12.dp)).padding(12.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            LatexAwareText(body, color = Color(0xFFE5E7EB))
        }
    }
}
