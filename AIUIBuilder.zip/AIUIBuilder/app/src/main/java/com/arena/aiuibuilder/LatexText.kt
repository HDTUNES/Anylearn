package com.arena.aiuibuilder

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Lightweight, stable math rendering level 1.
 * Detects common LaTeX delimiters and displays formulas as styled math blocks.
 * This does not fully typeset LaTeX like KaTeX/MathJax; it makes formulas readable
 * without adding heavy WebView/JS dependencies.
 */
@Composable
fun LatexAwareText(text: String, color: Color = Color(0xFFE5E7EB)) {
    val parts = splitLatexParts(text)
    Column {
        parts.forEach { part ->
            if (part.isFormula) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                    border = BorderStroke(1.dp, Color(0xFF334155)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Text(
                        text = part.content,
                        color = Color(0xFFBAE6FD),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            } else if (part.content.isNotBlank()) {
                Text(part.content, color = color)
            }
        }
    }
}

data class LatexPart(val content: String, val isFormula: Boolean)

fun splitLatexParts(input: String): List<LatexPart> {
    if (input.isBlank()) return listOf(LatexPart(input, false))
    val result = mutableListOf<LatexPart>()
    var i = 0
    fun addText(end: Int) {
        if (end > i) result += LatexPart(input.substring(i, end), false)
    }
    while (i < input.length) {
        val starts = listOf(
            "$$" to "$$",
            "\\[" to "\\]",
            "\\(" to "\\)",
            "$" to "$"
        )
        var matched = false
        for ((open, close) in starts) {
            if (input.startsWith(open, i)) {
                val before = i
                val startContent = i + open.length
                val end = input.indexOf(close, startContent)
                if (end >= 0) {
                    addText(before)
                    result += LatexPart(input.substring(startContent, end).trim(), true)
                    i = end + close.length
                    matched = true
                    break
                }
            }
        }
        if (!matched) i++
    }
    if (i <= input.length) {
        val lastFormulaEnd = result.sumOf { it.content.length } // not reliable for position; fallback below
    }
    // Simpler final pass if no formulas found
    if (result.isEmpty()) return listOf(LatexPart(input, false))

    // The loop above advances i past formulas but skips trailing text due to position mutation.
    // Re-run with explicit cursor for robust trailing text.
    result.clear()
    var cursor = 0
    while (cursor < input.length) {
        val candidates = listOf("$$", "\\[", "\\(", "$").mapNotNull { open ->
            val idx = input.indexOf(open, cursor)
            if (idx >= 0) open to idx else null
        }.sortedBy { it.second }
        if (candidates.isEmpty()) {
            result += LatexPart(input.substring(cursor), false)
            break
        }
        val (open, idx) = candidates.first()
        val close = when (open) { "$$" -> "$$"; "\\[" -> "\\]"; "\\(" -> "\\)"; else -> "$" }
        if (idx > cursor) result += LatexPart(input.substring(cursor, idx), false)
        val start = idx + open.length
        val end = input.indexOf(close, start)
        if (end < 0) {
            result += LatexPart(input.substring(idx), false)
            break
        }
        result += LatexPart(input.substring(start, end).trim(), true)
        cursor = end + close.length
    }
    return result
}
