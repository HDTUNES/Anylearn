package com.arena.aiuibuilder

import kotlin.math.max

/**
 * Metacognitive Monitor: the "System 2" oversight layer.
 *
 * Tracks:
 *   - progress toward the active goal
 *   - stuckness / repetition
 *   - confidence calibration
 *   - compute budget
 *   - which reasoning strategy to use next
 */

enum class StrategySignal {
    CONTINUE,           // keep going with current operator
    DECOMPOSE,          // problem is too big; break it down
    FIRST_PRINCIPLES,   // reduce to foundational causes
    ANALOGIZE,          // switch to cross-domain analogy
    VERIFY,             // pause and reality-check
    REFLECT,            // explicit metacognitive pause
    SAVE_NOTE,          // memory load high; externalize insight to disk
    RETRIEVE_NOTE,      // relevant archived/disk note may exist
    INTEGRATE,          // enough chunks exist; synthesize answer
    STOP                // budget exhausted or answer complete
}

data class MonitorState(
    val iteration: Int,
    val goalStackDepth: Int,
    val recentOperators: List<String>,
    val recentSurprises: List<Float>,
    val averageConfidence: Float,
    val budgetRemaining: Float // 0..1
)

object MetacognitiveMonitor {

    private const val STUCK_WINDOW = 4
    private const val STUCK_THRESHOLD = 0.72f // Jaccard overlap
    private const val SURPRISE_FLOOR = 0.15f
    private const val MAX_ITERATIONS = 20

    private var totalIterations = 0
    private var consecutiveStuck = 0
    private val operatorHistory = ArrayDeque<String>(STUCK_WINDOW * 2)
    private val surpriseHistory = ArrayDeque<Float>(STUCK_WINDOW)

    fun reset() {
        totalIterations = 0
        consecutiveStuck = 0
        operatorHistory.clear()
        surpriseHistory.clear()
    }

    /**
     * Decide what to do next given the current cycle state.
     */
    fun decideNext(
        goalStackDepth: Int,
        lastOperator: String,
        lastOutput: String,
        lastSurprise: Float,
        confidence: Float,
        chunkCount: Int,
        solvedChunks: Int
    ): StrategySignal {
        totalIterations += 1
        operatorHistory.addLast(lastOperator)
        if (operatorHistory.size > STUCK_WINDOW * 2) operatorHistory.removeFirst()
        surpriseHistory.addLast(lastSurprise)
        if (surpriseHistory.size > STUCK_WINDOW) surpriseHistory.removeFirst()

        AppLog.logStructured(
            "INFO", "META", totalIterations,
            "Metacognitive assessment",
            mapOf("depth" to goalStackDepth, "confidence" to "%.2f".format(confidence), "surprise" to "%.2f".format(lastSurprise), "chunks" to "$solvedChunks/$chunkCount")
        )

        // Budget exhaustion
        if (totalIterations >= MAX_ITERATIONS) {
            AppLog.logStructured("WARN", "META", totalIterations, "Budget exhausted; forcing integration or stop")
            return if (solvedChunks > 0) StrategySignal.INTEGRATE else StrategySignal.STOP
        }

        // Detect repetition / stuckness
        if (isStuck(lastOutput)) {
            consecutiveStuck += 1
            AppLog.logStructured("WARN", "META", totalIterations, "Stuck detected", mapOf("consecutiveStuck" to consecutiveStuck))
            return when {
                consecutiveStuck >= 3 -> StrategySignal.FIRST_PRINCIPLES
                consecutiveStuck == 2 -> StrategySignal.ANALOGIZE
                else -> StrategySignal.DECOMPOSE
            }
        } else {
            consecutiveStuck = 0
        }

        // Low confidence on a falsifiable claim → verify
        if (confidence < 0.6f && lastSurprise > SURPRISE_FLOOR && isVerifiable(lastOutput)) {
            return StrategySignal.VERIFY
        }

        // If all chunks are solved, integrate
        if (chunkCount > 0 && solvedChunks >= chunkCount) {
            return StrategySignal.INTEGRATE
        }

        // If problem is broad and not yet decomposed, decompose
        if (goalStackDepth == 1 && chunkCount == 0 && totalIterations >= 2) {
            return StrategySignal.DECOMPOSE
        }

        // High surprise with no progress → reflect and switch strategy
        if (lastSurprise > 0.6f && consecutiveStuck > 0) {
            return StrategySignal.REFLECT
        }

        return StrategySignal.CONTINUE
    }

    private fun isStuck(lastOutput: String): Boolean {
        if (operatorHistory.size < STUCK_WINDOW) return false
        val recent = operatorHistory.takeLast(STUCK_WINDOW).map { it.lowercase() }
        // Stuck if same operator repeats or outputs repeat words
        val sameOperator = recent.distinct().size == 1
        if (sameOperator) return true

        val recentOutputs = EpisodicMemory.all().takeLast(STUCK_WINDOW).map { it.output }
        if (recentOutputs.size < 3) return false
        val overlaps = mutableListOf<Float>()
        for (i in 1 until recentOutputs.size) {
            overlaps.add(wordOverlap(recentOutputs[i - 1], recentOutputs[i]))
        }
        return overlaps.average() > STUCK_THRESHOLD
    }

    private fun isVerifiable(text: String): Boolean {
        val verifiableMarkers = setOf("%", "=", "<", ">", "+", "-", "*", "/", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9")
        return verifiableMarkers.any { text.contains(it) } || text.contains(Regex("\\d"))
    }

    private fun wordOverlap(a: String, b: String): Float {
        val wordsA = a.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() && it.length > 3 }.toSet()
        val wordsB = b.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() && it.length > 3 }.toSet()
        if (wordsA.isEmpty() || wordsB.isEmpty()) return 0f
        return wordsA.intersect(wordsB).size.toFloat() / wordsA.union(wordsB).size.toFloat()
    }

    /**
     * Decide whether to externalize a note to disk based on memory load and insight value.
     */
    fun shouldExternalize(memoryLoad: Float, confidence: Float, surprise: Float): Boolean {
        return memoryLoad > 0.8f && (confidence > 0.75f || surprise > 0.5f)
    }

    /**
     * Decide whether to retrieve disk notes based on a detected knowledge gap.
     */
    fun shouldRetrieveDiskNotes(query: String, retrievedCount: Int, hasDiskNotes: Boolean): Boolean {
        return hasDiskNotes && retrievedCount < 2 && query.length > 10
    }

    fun estimateConfidence(output: String, verificationResult: Boolean?): Float {
        var score = 0.75f
        if (verificationResult == true) score += 0.15f
        if (verificationResult == false) score -= 0.30f
        if (output.contains("uncertain") || output.contains("maybe") || output.contains("possibly")) score -= 0.10f
        if (output.contains(Regex("\\d"))) score += 0.05f
        return score.coerceIn(0.05f, 1.0f)
    }
}
