package com.arena.aiuibuilder

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

object ThinkingStream {
    private const val CAP = 24 * 1024
    private val _live = MutableStateFlow("")
    val live: StateFlow<String> = _live
    private val _expanded = MutableStateFlow(true)
    val expanded: StateFlow<Boolean> = _expanded

    private val buffer = StringBuilder()

    fun append(token: String) {
        if (token.isBlank()) return
        synchronized(buffer) {
            buffer.append(token)
            if (buffer.length > CAP) buffer.delete(0, buffer.length - CAP)
            _live.value = buffer.toString()
        }
        try { AppLog.log("THINK", token.take(120)) } catch(_:Throwable){}
    }
    fun appendLine(tag: String, content: String) {
        append("\n[$tag] $content\n")
    }
    fun clear() { synchronized(buffer) { buffer.setLength(0); _live.value = "" } }
    fun toggleExpand() { _expanded.update { !it } }
    fun setExpanded(v: Boolean) { _expanded.value = v }
}

@Composable
fun ThinkingBlock(isActive: Boolean) {
    val text by ThinkingStream.live.collectAsState()
    val expanded by ThinkingStream.expanded.collectAsState()
    val infinite = rememberInfiniteTransition(label = "thinkGlow")
    val glow by infinite.animateFloat(
        initialValue = if (isActive) 0.45f else 0.85f,
        targetValue = if (isActive) 1.0f else 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isActive) 1100 else 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "glow"
    )
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF0B0F1A), RoundedCornerShape(14.dp))
            .clickable { ThinkingStream.toggleExpand() }
            .padding(14.dp)
    ) {
        Text(
            if (isActive) "Thinking…" else "Thinking trace",
            color = Color.White.copy(alpha = glow),
            fontSize = 15.sp,
            fontWeight = FontWeight.Light
        )
        if (expanded) {
            Spacer(Modifier.height(8.dp))
            val scroll = rememberScrollState()
            LaunchedEffect(text.length) { scroll.animateScrollTo(scroll.maxValue) }
            Text(
                text.ifBlank { if (isActive) "warming up cognitive loop…" else "no trace yet" },
                color = Color(0xFFCBD5E1),
                fontSize = 13.sp,
                fontWeight = FontWeight.Normal,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 120.dp, max = 360.dp)
                    .verticalScroll(scroll)
            )
        } else {
            Text("tap to expand — ${text.length} chars captured", color = Color(0xFF64748B), fontSize = 11.sp)
        }
    }
}
